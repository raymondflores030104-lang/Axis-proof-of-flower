import React from 'react';
import { Smartphone, Download, CheckCircle2, ShieldCheck } from 'lucide-react';

interface ApkInstallGuideModalProps {
  onClose: () => void;
  isOpen?: boolean;
  onToast?: (msg: string, type?: 'good' | 'err') => void;
}

export const ApkInstallGuideModal: React.FC<ApkInstallGuideModalProps> = ({ onClose }) => {
  return (
    <div className="space-y-4 select-none">
      <div className="p-4 rounded-2xl neu-flat text-center space-y-2">
        <div className="w-12 h-12 mx-auto rounded-2xl neu-inset flex items-center justify-center text-emerald-600">
          <Smartphone className="w-6 h-6" />
        </div>
        <h3 className="font-extrabold text-sm text-[var(--ink)]">
          Install Axis on Android or iOS
        </h3>
        <p className="text-xs text-[var(--ink2)]">
          Install directly as a standalone mobile application with full offline caching and camera acceleration.
        </p>
      </div>

      <div className="space-y-2.5 text-xs text-[var(--ink)]">
        <div className="p-3 rounded-2xl neu-inset space-y-1">
          <b>Option 1: Add to Home Screen (PWA)</b>
          <p className="text-[11px] text-[var(--ink2)]">
            Tap browser menu (⋮ on Chrome, Share on Safari) &gt; Select &quot;Add to Home Screen&quot;.
          </p>
        </div>

        <div className="p-3 rounded-2xl neu-inset space-y-1">
          <b>Option 2: Standalone APK Packaging</b>
          <p className="text-[11px] text-[var(--ink2)]">
            Pre-packaged debug signed APKs can be built directly using Android Studio or Capacitor wrapper.
          </p>
        </div>
      </div>

      <button
        onClick={onClose}
        className="w-full py-2.5 rounded-xl neu-tab-active font-extrabold text-xs cursor-pointer"
      >
        Got It
      </button>
    </div>
  );
};
