import React from 'react';

export interface BackgroundOperation {
  id: string;
  label: string;
  progress: number; // 0 to 100
  status: 'processing' | 'completed' | 'failed';
}

interface InstantResponseBannerProps {
  operations: BackgroundOperation[];
}

export const InstantResponseBanner: React.FC<InstantResponseBannerProps> = ({ operations }) => {
  if (!operations || operations.length === 0) return null;

  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 w-full max-w-sm px-3 pointer-events-none space-y-2">
      {operations.map((op) => (
        <div
          key={op.id}
          className="p-3 rounded-2xl neu-flat bg-[var(--neu-bg)] border border-emerald-600/30 shadow-lg pointer-events-auto transition-all duration-300 transform animate-slide-down"
        >
          <div className="flex items-center justify-between text-xs font-bold mb-1.5">
            <span className="flex items-center gap-1.5 text-[var(--ink)]">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping inline-block" />
              <span>{op.label}</span>
            </span>
            <span className="text-[10px] font-mono text-[var(--accent)] font-extrabold">
              {Math.round(op.progress)}%
            </span>
          </div>

          {/* Animated Micro Progress Bar */}
          <div className="w-full h-1.5 rounded-full neu-inset overflow-hidden bg-black/10">
            <div
              className="h-full bg-emerald-600 rounded-full transition-all duration-200 ease-out"
              style={{ width: `${Math.min(100, Math.max(8, op.progress))}%` }}
            />
          </div>
          <div className="flex justify-between items-center mt-1">
            <span className="text-[9px] text-[var(--ink2)] font-mono">
              ✓ UI Updated instantly · Processing on chain
            </span>
            <span className="text-[9px] text-emerald-700 dark:text-emerald-400 font-bold">
              Background task
            </span>
          </div>
        </div>
      ))}
    </div>
  );
};
