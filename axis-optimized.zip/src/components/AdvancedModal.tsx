import React from 'react';
import { AxisState } from '../types';
import { Cpu, Bot, Lock, FileText, Sparkles } from 'lucide-react';

interface AdvancedModalProps {
  state: AxisState;
  onToggleAutoMining: (on: boolean) => void;
  onConfigureBot: (amt: number, iv: number, mx: number, on: boolean) => void;
  onOpenStaking: () => void;
  onOpenGoals: () => void;
  onOpenWhitepaper: () => void;
  onOpenArchitecture?: () => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const AdvancedModal: React.FC<AdvancedModalProps> = ({
  state,
  onToggleAutoMining,
  onOpenStaking,
  onOpenWhitepaper,
  onOpenArchitecture
}) => {
  return (
    <div className="space-y-4 select-none">
      {/* 3D Corporate Architecture Hub Banner */}
      <div className="p-4 rounded-2xl neu-flat bg-gradient-to-br from-emerald-950/20 via-zinc-900/30 to-teal-950/20 border border-emerald-500/30 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400">
            Interactive Graphics Engine
          </span>
          <span className="text-[10px] font-mono font-bold text-emerald-400">
            ● 3D WebGL / Canvas
          </span>
        </div>
        <b className="block text-sm font-extrabold text-[var(--ink)]">
          Naturans Executive Architecture &amp; Chess Ledger Hub
        </b>
        <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
          Explore the real-time 3D chess visualization, bold 400-move kinematic vectors, dynamic-scaled DCA candlesticks, and B2B replenishment workflow.
        </p>
        {onOpenArchitecture && (
          <button
            onClick={onOpenArchitecture}
            className="w-full py-2.5 rounded-xl neu-btn-accent font-extrabold text-xs flex items-center justify-center gap-1.5 cursor-pointer mt-1"
          >
            <Sparkles className="w-4 h-4" />
            <span>Launch 3D Architecture Hub</span>
          </button>
        )}
      </div>

      {/* Background Auto-Mining Bridge Card */}
      <div className="p-4 rounded-2xl neu-flat space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-600" />
            <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink)]">
              Background Auto-Scan Sync
            </h4>
          </div>
          <button
            onClick={() => onToggleAutoMining(!state.auto?.on)}
            className={`neu-toggle cursor-pointer transition ${
              state.auto?.on ? 'bg-emerald-600' : 'bg-zinc-300 dark:bg-zinc-700'
            }`}
          >
            <span
              className={`w-4 h-4 rounded-full bg-white shadow-xs transition-transform duration-200 block ${
                state.auto?.on ? 'translate-x-5' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>
        <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
          Allows verified background beacon pings when entering participating retail partner stores (7-Eleven, Puregold, Robinsons).
        </p>
      </div>

      {/* Protocol Whitepaper & Staking Shortcuts */}
      <div className="grid grid-cols-2 gap-2.5">
        <button
          onClick={onOpenStaking}
          className="p-3.5 rounded-2xl neu-flat text-left space-y-1.5 cursor-pointer hover:neu-flat-lg transition"
        >
          <Lock className="w-5 h-5 text-emerald-600" />
          <b className="text-xs font-bold block text-[var(--ink)]">FLWRX Vault Staking</b>
          <span className="text-[10px] text-[var(--ink2)] block">
            Lock tokens for up to 20% protocol APY.
          </span>
        </button>

        <button
          onClick={onOpenWhitepaper}
          className="p-3.5 rounded-2xl neu-flat text-left space-y-1.5 cursor-pointer hover:neu-flat-lg transition"
        >
          <FileText className="w-5 h-5 text-teal-600" />
          <b className="text-xs font-bold block text-[var(--ink)]">Full Whitepaper</b>
          <span className="text-[10px] text-[var(--ink2)] block">
            Read cryptographic proof &amp; tokenomics.
          </span>
        </button>
      </div>
    </div>
  );
};
