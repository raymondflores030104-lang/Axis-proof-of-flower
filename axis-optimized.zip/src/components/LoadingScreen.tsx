import React, { useState, useEffect, useLayoutEffect, useRef } from 'react';
import {
  LEAVES,
  STEM,
  leafShape,
  leafTransform,
  applyLogoProgress,
  computeLockup,
  canvasMeasure,
  SCAN_WEIGHT,
  STACK_WEIGHT,
  LockupMetrics
} from './loadingLogo';

/** Duration of the growing tree & progress bar timeline (ms). */
const DURATION = 2600;
/** Hold at 100% completion before fading out (ms). */
const HOLD = 300;
/** Fade-out transition duration (ms). */
const FADE = 600;

interface LoadingScreenProps {
  onComplete: () => void;
  isCosmic?: boolean;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete, isCosmic }) => {
  const stemRef = useRef<SVGPathElement | null>(null);
  const leafRefs = useRef<(SVGGElement | null)[]>([]);
  const fillRef = useRef<HTMLDivElement | null>(null);
  const pctRef = useRef<HTMLSpanElement | null>(null);
  const [leaving, setLeaving] = useState(false);
  const [lockup, setLockup] = useState<LockupMetrics | null>(null);

  // Detect cosmic black hole environment if not passed explicitly
  const cosmicActive = isCosmic ?? (
    typeof document !== 'undefined' &&
    (document.documentElement.classList.contains('theme-blackhole') ||
     document.documentElement.getAttribute('data-weather') === 'blackhole' ||
     document.body.classList.contains('theme-blackhole') ||
     document.querySelector('.theme-blackhole') !== null ||
     document.querySelector('[data-weather="blackhole"]') !== null)
  );

  // Size "SCAN FOR" so it is optically aligned with the stacked "World / Reward".
  useLayoutEffect(() => {
    const measure = () => {
      const family =
        (typeof window !== 'undefined' && getComputedStyle(document.body).fontFamily) ||
        'Plus Jakarta Sans, system-ui, sans-serif';
      setLockup(computeLockup(canvasMeasure(family)));
    };
    measure();

    let cancelled = false;
    if (typeof document !== 'undefined' && document.fonts?.ready) {
      document.fonts.ready.then(() => {
        if (!cancelled) measure();
      });
    }

    return () => {
      cancelled = true;
    };
  }, []);

  // One synchronized timeline drives the bar, % text, and growing plant: 0 -> 100 together.
  useEffect(() => {
    const reduce =
      typeof window !== 'undefined' &&
      typeof window.matchMedia === 'function' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const total = reduce ? 500 : DURATION;
    const t0 = performance.now();
    let raf = 0;
    let finished = false;
    const timers: number[] = [];

    const paint = (p: number) => {
      if (fillRef.current) fillRef.current.style.width = `${p.toFixed(1)}%`;
      if (pctRef.current) pctRef.current.textContent = `${Math.floor(p)}%`;
      applyLogoProgress(stemRef.current, leafRefs.current, reduce ? 100 : p);
    };

    const finish = () => {
      if (finished) return;
      finished = true;
      cancelAnimationFrame(raf);
      paint(100);
      timers.push(
        window.setTimeout(() => {
          setLeaving(true);
          timers.push(window.setTimeout(onComplete, FADE));
        }, HOLD)
      );
    };

    const frame = (now: number) => {
      const x = Math.max(0, Math.min(1, (now - t0) / total));
      paint(x * 100);
      if (x < 1) {
        raf = requestAnimationFrame(frame);
      } else {
        finish();
      }
    };

    paint(0);
    raf = requestAnimationFrame(frame);

    // Safety net in case the tab is in background and requestAnimationFrame pauses.
    timers.push(window.setTimeout(finish, total + 2500));

    return () => {
      finished = true;
      cancelAnimationFrame(raf);
      timers.forEach((id) => window.clearTimeout(id));
    };
  }, [onComplete]);

  return (
    <div
      role="status"
      aria-label="Loading Axis"
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center gap-2.5 ${
        cosmicActive ? 'bg-black text-white' : 'bg-[var(--bg)]'
      } select-none transition-opacity duration-600 ease-out will-change-[opacity] ${
        leaving ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Growing Tree Emblem SVG */}
      <svg
        viewBox="0 0 200 200"
        className="w-[130px] h-[130px] overflow-visible"
        aria-hidden="true"
      >
        {/* Concentric Halo Circles */}
        <circle
          cx="100"
          cy="100"
          r="95"
          fill="none"
          stroke={cosmicActive ? '#ffffff' : 'var(--accent)'}
          strokeWidth="3.5"
          opacity={cosmicActive ? '0.35' : '0.22'}
        />
        <circle
          cx="100"
          cy="100"
          r="80"
          fill="none"
          stroke={cosmicActive ? '#ffffff' : 'var(--accent)'}
          strokeWidth="2.5"
          opacity={cosmicActive ? '0.55' : '0.40'}
        />

        {/* Soil Base Shadow */}
        <ellipse
          cx="100"
          cy="168"
          rx="30"
          ry="5"
          fill={cosmicActive ? '#ffffff' : 'var(--accent)'}
          opacity={cosmicActive ? '0.25' : '0.20'}
        />

        {/* Sprouting Main Stem */}
        <path
          ref={stemRef}
          d={`M100 ${STEM.y0} L100 ${STEM.y1}`}
          fill="none"
          stroke={cosmicActive ? '#ffffff' : 'var(--accent)'}
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={STEM.len}
          strokeDashoffset={STEM.len}
          strokeOpacity="0"
        />

        {/* Budding Leaves Hierarchy */}
        {LEAVES.map((leaf, i) => {
          const sh = leafShape(leaf);
          return (
            <g
              key={i}
              ref={(el) => {
                leafRefs.current[i] = el;
              }}
              transform={leafTransform(leaf, 0)}
            >
              <ellipse
                cx={sh.cx.toFixed(2)}
                cy={sh.cy.toFixed(2)}
                rx={leaf.rx}
                ry={leaf.ry}
                transform={`rotate(${sh.rotate.toFixed(2)} ${sh.cx.toFixed(2)} ${sh.cy.toFixed(2)})`}
                fill={cosmicActive ? '#ffffff' : 'var(--accent)'}
              />
              <line
                x1="100"
                y1={leaf.ay}
                x2={sh.tipX.toFixed(2)}
                y2={sh.tipY.toFixed(2)}
                stroke={cosmicActive ? '#000000' : 'var(--c-border-focus)'}
                strokeWidth={cosmicActive ? '1.5' : '1.2'}
                strokeLinecap="round"
              />
            </g>
          );
        })}
      </svg>

      {/* Axis Brand Headline */}
      <h2
        className={`font-brand text-3xl font-extrabold tracking-tight leading-none mt-1 ${
          cosmicActive
            ? 'text-white drop-shadow-[0_0_12px_rgba(255,255,255,0.45)]'
            : 'text-[var(--accent)]'
        }`}
      >
        Axis
      </h2>

      {/* Dynamic Measured "SCAN FOR World Reward" Lockup */}
      <div className="flex justify-center w-full" aria-label="Scan for World Reward">
        {lockup && (
          <svg
            viewBox={`0 0 ${lockup.width} ${lockup.height}`}
            width={lockup.width}
            height={lockup.height}
            style={{ maxWidth: '92vw', height: 'auto', overflow: 'visible' }}
            role="img"
            aria-label="Scan for World Reward"
          >
            <text
              x={0}
              y={lockup.base}
              fontSize={lockup.scanSize.toFixed(2)}
              fontWeight={SCAN_WEIGHT}
              style={{
                fill: cosmicActive ? '#ffffff' : 'var(--accent)',
                letterSpacing: `${lockup.scanSpacing.toFixed(2)}px`
              }}
            >
              SCAN FOR
            </text>
            <text
              x={lockup.stackX.toFixed(2)}
              y={lockup.worldY.toFixed(2)}
              fontSize={lockup.stackSize}
              fontWeight={STACK_WEIGHT}
              style={{ fill: cosmicActive ? '#ffffff' : 'var(--accent)' }}
            >
              World
            </text>
            <text
              x={lockup.stackX.toFixed(2)}
              y={lockup.rewardY}
              fontSize={lockup.stackSize}
              fontWeight={STACK_WEIGHT}
              style={{ fill: cosmicActive ? '#ffffff' : 'var(--accent)' }}
            >
              Reward
            </text>
          </svg>
        )}
      </div>

      {/* Progress Track & Gradient Fill matching semantic green scale or monochrome starlight */}
      <div
        className={`w-[180px] h-1.5 rounded-full overflow-hidden mt-1.5 ${
          cosmicActive
            ? 'bg-zinc-900 border border-white/20'
            : 'bg-[var(--line)]'
        }`}
      >
        <div
          ref={fillRef}
          className={`h-full w-0 rounded-full transition-[width] duration-75 ${
            cosmicActive
              ? 'bg-white shadow-[0_0_10px_rgba(255,255,255,0.9)]'
              : 'bg-gradient-to-r from-[var(--accent)] to-[var(--c-border-focus)]'
          }`}
        />
      </div>

      {/* Percentage Indicator */}
      <span
        ref={pctRef}
        className={`text-xs font-bold font-mono tabular-nums ${
          cosmicActive ? 'text-zinc-300' : 'text-[var(--ink2)]'
        }`}
      >
        0%
      </span>

      {/* Bottom Teraxiom Ecosystem Watermark - Positioned in the middle below */}
      <div
        className={`absolute left-1/2 -translate-x-1/2 bottom-[calc(1.25rem+env(safe-area-inset-bottom,0px))] text-[26px] font-normal tracking-wider opacity-85 pointer-events-none text-center whitespace-nowrap ${
          cosmicActive ? 'text-white' : 'text-[var(--ink2)]'
        }`}
      >
        Teraxiom
      </div>
    </div>
  );
};
