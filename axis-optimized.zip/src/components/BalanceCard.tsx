import React from 'react';
import { AxisState } from '../types';
import { curInfo, peso, fmtF, flwrxEquivalent } from '../utils';
import { Coins, CircleDollarSign } from 'lucide-react';

interface BalanceCardProps {
  state: AxisState;
  pricePHP: number;
  isLandscape?: boolean;
}

export const BalanceCard: React.FC<BalanceCardProps> = ({ state, pricePHP, isLandscape = false }) => {
  const currentCur = curInfo(state.settings.currency);

  if (isLandscape) {
    return (
      <div data-zone="balance" className="select-none w-full h-full flex flex-col min-h-0">
        <div className="rounded-2xl neu-flat p-[clamp(0.35rem,1.1dvh,0.6rem)] flex flex-col justify-between gap-[clamp(0.25rem,0.9dvh,0.5rem)] h-full w-full min-h-0">
          {/* 1. Philippine Liquid Fiat (Clean, single-layer, fully readable) */}
          <div className="flex-1 p-[clamp(0.3rem,1dvh,0.55rem)] text-left rounded-xl neu-inset relative flex flex-col justify-between overflow-hidden w-full min-h-0">
            {/* Header: Icon + Clean Label */}
            <div className="flex items-center gap-1.5 min-w-0">
              <CircleDollarSign className="w-[clamp(12px,2.8dvh,16px)] h-[clamp(12px,2.8dvh,16px)] text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span className="text-[clamp(8px,1.9dvh,10px)] font-bold tracking-tight text-[var(--ink2)] whitespace-nowrap leading-tight truncate">
                Philippine Peso (PHP)
              </span>
            </div>

            {/* Hero Currency Value */}
            <div className="my-auto py-0.5 min-h-0 overflow-hidden">
              <b
                title={peso(state.php, state.settings.currency)}
                className="text-[clamp(13px,3.3dvh,19px)] font-black tracking-tight font-mono text-[var(--ink)] block leading-tight whitespace-nowrap truncate"
              >
                {peso(state.php, state.settings.currency)}
              </b>
            </div>

            {/* Subline */}
            <div className="text-[clamp(8px,1.7dvh,9.5px)] text-[var(--ink2)] font-mono leading-none flex items-center justify-between gap-1 overflow-hidden shrink-0">
              <span className="text-emerald-600 dark:text-emerald-400 font-semibold truncate">Liquid Fiat</span>
              <span className="text-[clamp(7.5px,1.6dvh,8.5px)] opacity-75 shrink-0">Available</span>
            </div>
          </div>

          {/* 2. FlowerXcoin (FLWRX) (Clean, single-layer, fully readable) */}
          <div className="flex-1 p-[clamp(0.3rem,1dvh,0.55rem)] text-left rounded-xl neu-inset relative flex flex-col justify-between overflow-hidden w-full min-h-0">
            {/* Header: Icon + Clean Label */}
            <div className="flex items-center gap-1.5 min-w-0">
              <Coins className="w-[clamp(12px,2.8dvh,16px)] h-[clamp(12px,2.8dvh,16px)] text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span className="text-[clamp(8px,1.9dvh,10px)] font-bold tracking-tight text-[var(--ink2)] whitespace-nowrap leading-tight truncate">
                FlowerXcoin (FLWRX)
              </span>
            </div>

            {/* Hero Currency Value */}
            <div className="my-auto py-0.5 min-h-0 overflow-hidden">
              <b
                title={`${fmtF(state.flrx)} FLWRX`}
                className="text-[clamp(13px,3.3dvh,19px)] font-black tracking-tight font-mono text-emerald-600 dark:text-emerald-400 block leading-tight whitespace-nowrap truncate"
              >
                {state.flrx >= 1000
                  ? state.flrx.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                  : state.flrx >= 1
                  ? state.flrx.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })
                  : fmtF(state.flrx)}
              </b>
            </div>

            {/* Live Fiat Conversion */}
            <div className="text-[clamp(8px,1.7dvh,9.5px)] text-[var(--ink2)] font-mono leading-none flex items-center justify-between gap-1 overflow-hidden shrink-0">
              <span className="font-semibold text-[var(--ink)] truncate">
                ≈ {flwrxEquivalent(state.flrx, state.price, state.settings?.currency)}
              </span>
              <span className="text-[clamp(7.5px,1.6dvh,8.5px)] opacity-75 shrink-0">PoF Token</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Portrait Layout
  return (
    <div data-zone="balance" className="mb-2.5 sm:mb-3.5 select-none w-full">
      <div className="rounded-2xl neu-flat p-2 sm:p-2.5 md:p-3 flex flex-row gap-2 sm:gap-3 h-[90px] items-center">
        {/* Fiat Section */}
        <div className="flex-1 py-2 px-2.5 sm:px-3 md:px-4 text-left rounded-xl neu-inset relative flex flex-row items-center justify-between overflow-hidden w-full h-full">
          <div className="flex items-center justify-start gap-1.5 sm:gap-2 min-w-0">
            <CircleDollarSign className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <div className="min-w-0 text-left">
              <small className="text-[10px] sm:text-[11px] font-extrabold tracking-wider uppercase text-[var(--ink2)] block truncate leading-tight">
                {currentCur[2]}
              </small>
              <span className="text-[8.5px] sm:text-[9.5px] text-[var(--ink2)] font-mono truncate leading-tight block">
                Liquid Fiat
              </span>
            </div>
          </div>
          <b
            title={peso(state.php, state.settings.currency)}
            className="text-lg sm:text-2xl md:text-3xl font-black tracking-tight font-mono text-[var(--ink)] whitespace-nowrap shrink-0 pl-1.5 sm:pl-2 leading-none"
          >
            {peso(state.php, state.settings.currency)}
          </b>
        </div>

        {/* FLWRX Crypto Section */}
        <div className="flex-1 py-2 px-2.5 sm:px-3 md:px-4 text-left rounded-xl neu-inset relative flex flex-row items-center justify-between overflow-hidden w-full h-full">
          <div className="flex items-center justify-start gap-1.5 sm:gap-2 min-w-0">
            <Coins className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <div className="min-w-0 text-left">
              <small className="text-[10px] sm:text-[11px] font-extrabold text-[var(--ink2)] tracking-wider uppercase block truncate leading-tight">
                FlowerXcoin (FLWRX)
              </small>
              <span className="text-[8.5px] sm:text-[9.5px] text-[var(--ink2)] font-mono truncate leading-tight block">
                ≈ {flwrxEquivalent(state.flrx, state.price, state.settings?.currency)}
              </span>
            </div>
          </div>
          <b
            title={`${fmtF(state.flrx)} FLWRX`}
            className="text-lg sm:text-2xl md:text-3xl font-black tracking-tight font-mono text-emerald-600 dark:text-emerald-400 whitespace-nowrap shrink-0 pl-1.5 sm:pl-2 leading-none"
          >
            {state.flrx >= 1000
              ? state.flrx.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
              : state.flrx >= 1
              ? state.flrx.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })
              : fmtF(state.flrx)}
          </b>
        </div>
      </div>
    </div>
  );
};

