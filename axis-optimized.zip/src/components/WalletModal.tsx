import React, { useState } from 'react';
import { AxisState } from '../types';
import { DEP, WFEE } from '../constants';
import { peso, fmtF, r2 } from '../utils';
import { Wallet, ArrowDownLeft, ArrowUpRight, History, QrCode } from 'lucide-react';

interface WalletModalProps {
  state: AxisState;
  onDeposit: any;
  onWithdraw: any;
  onSendCrypto?: any;
  onSend?: any;
  onSendFlrx?: any;
  onToast: (msg: string, type?: 'good' | 'err') => void;
  onRequestPin?: (title: string, onVerified: () => void) => void;
}

export const WalletModal: React.FC<WalletModalProps> = ({
  state,
  onDeposit,
  onWithdraw,
  onSendCrypto,
  onSend,
  onToast,
  onRequestPin
}) => {
  const [activeTab, setActiveTab] = useState<'fiat' | 'crypto' | 'history'>('fiat');
  const [fiatMode, setFiatMode] = useState<'deposit' | 'withdraw'>('deposit');
  const [fiatAmount, setFiatAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('ewallet');
  const [phoneOrSim, setPhoneOrSim] = useState('');
  const [bankName, setBankName] = useState('BDO Unibank');
  const [bankAccount, setBankAccount] = useState('');
  const [bankHolder, setBankHolder] = useState(state.profile.name || '');

  const [cryptoMode, setCryptoMode] = useState<'send' | 'receive'>('send');
  const [cryptoAmount, setCryptoAmount] = useState('');
  const [recipient, setRecipient] = useState('');

  const getSimBadge = (val: string) => {
    const clean = val.replace(/\D/g, '');
    if (clean.startsWith('0917') || clean.startsWith('0927') || clean.startsWith('0905') || clean.startsWith('0906') || clean.startsWith('0915') || clean.startsWith('0916') || clean.startsWith('0926') || clean.startsWith('0935') || clean.startsWith('0936') || clean.startsWith('0945') || clean.startsWith('0955') || clean.startsWith('0956') || clean.startsWith('0965') || clean.startsWith('0966') || clean.startsWith('0967') || clean.startsWith('0975') || clean.startsWith('0976') || clean.startsWith('0977') || clean.startsWith('0995') || clean.startsWith('0997')) {
      return 'Globe / TM';
    }
    if (clean.startsWith('0918') || clean.startsWith('0919') || clean.startsWith('0920') || clean.startsWith('0921') || clean.startsWith('0928') || clean.startsWith('0929') || clean.startsWith('0939') || clean.startsWith('0946') || clean.startsWith('0947') || clean.startsWith('0948') || clean.startsWith('0949') || clean.startsWith('0951') || clean.startsWith('0961') || clean.startsWith('0963') || clean.startsWith('0968') || clean.startsWith('0969') || clean.startsWith('0970') || clean.startsWith('0971') || clean.startsWith('0981') || clean.startsWith('0989') || clean.startsWith('0992') || clean.startsWith('0998') || clean.startsWith('0999')) {
      return 'Smart / TNT';
    }
    if (clean.startsWith('0991') || clean.startsWith('0992') || clean.startsWith('0993') || clean.startsWith('0994')) {
      return 'DITO Telecommunity';
    }
    return clean.length >= 4 ? 'PH Mobile' : '';
  };

  const handleFiatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(fiatAmount) || 0;
    if (val <= 0) {
      onToast('Enter a valid amount', 'err');
      return;
    }

    if (fiatMode === 'deposit') {
      if (typeof onDeposit === 'function') {
        if (onDeposit.length >= 3) {
          onDeposit('fiat', selectedMethod, val);
        } else {
          onDeposit(val);
        }
      }
      setFiatAmount('');
    } else {
      const fee = WFEE[selectedMethod] || 15;
      if (state.php < val + fee) {
        onToast('Insufficient PHP balance to cover amount and withdrawal fee', 'err');
        return;
      }

      // Specific validation for GCash/Maya vs Bank Card
      let destinationLabel = '';
      if (selectedMethod === 'ewallet') {
        const cleanPhone = phoneOrSim.replace(/\D/g, '');
        if (!cleanPhone || cleanPhone.length < 10 || cleanPhone.length > 12) {
          onToast('Please enter a valid 11-digit mobile number (e.g. 09171234567) registered to GCash/Maya', 'err');
          return;
        }
        const masked = cleanPhone.slice(0, 4) + '***' + cleanPhone.slice(-4);
        destinationLabel = `GCash/Maya (${masked})`;
      } else if (selectedMethod === 'bank') {
        const cleanAcct = bankAccount.replace(/\D/g, '');
        if (!cleanAcct || cleanAcct.length < 8) {
          onToast('Please enter a valid Bank/ATM Account Number', 'err');
          return;
        }
        if (!bankHolder || bankHolder.trim().length < 3) {
          onToast('Please enter the Account Holder Name on card/account', 'err');
          return;
        }
        const masked = '****' + cleanAcct.slice(-4);
        destinationLabel = `${bankName} (${masked} · ${bankHolder.trim()})`;
      } else {
        destinationLabel = `OTC 7-Eleven Cliqq / Palawan`;
      }

      const doWithdraw = () => {
        if (typeof onWithdraw === 'function') {
          if (onWithdraw.length >= 4) {
            onWithdraw('fiat', selectedMethod, val, fee, destinationLabel);
          } else {
            onWithdraw(val, fee, destinationLabel);
          }
        }
        setFiatAmount('');
        onToast(`Withdrawal of ₱${val.toFixed(2)} dispatched to ${destinationLabel}`, 'good');
      };
      if (onRequestPin) {
        onRequestPin('Confirm Fiat Withdrawal', doWithdraw);
      } else {
        doWithdraw();
      }
    }
  };

  const handleCryptoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(cryptoAmount) || 0;
    if (val <= 0 || !recipient) {
      onToast('Enter recipient address and valid amount', 'err');
      return;
    }
    if (state.flrx < val) {
      onToast('Insufficient FLWRX balance', 'err');
      return;
    }

    const doSend = () => {
      const sendFn = onSend || onSendCrypto;
      if (typeof sendFn === 'function') {
        if (sendFn.length >= 3) {
          sendFn(recipient, val, 0.001, '');
        } else {
          sendFn(recipient, val);
        }
      }
      setCryptoAmount('');
      setRecipient('');
    };

    if (onRequestPin) {
      onRequestPin('Authorize FLWRX Transfer', doSend);
    } else {
      doSend();
    }
  };

  const cur = state.settings?.currency || 'PHP';

  return (
    <div className="space-y-4 select-none">
      {/* Custody Architecture & Environment Delineation Banner */}
      <div className="flex items-center justify-between p-2.5 rounded-xl neu-flat text-[11px] border border-[var(--glass-border-card)]">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-bold text-[var(--ink)] truncate">
            {state.custodyMode === 'AXIS_MANAGED' ? 'AXIS-Managed Custody (Segregated MPC)' : 'Self-Custody (Device Keystore)'}
          </span>
        </div>
        <span className="text-[9px] font-extrabold px-2 py-0.5 rounded-md uppercase tracking-wider shrink-0 bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          FLRXCORE NETWORK
        </span>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex rounded-2xl neu-tab-bar p-1.5 text-xs font-bold gap-1.5">
        <button
          onClick={() => setActiveTab('fiat')}
          className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
            activeTab === 'fiat' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          Fiat Balance ({cur})
        </button>
        <button
          onClick={() => setActiveTab('crypto')}
          className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
            activeTab === 'crypto' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          FLWRX Vault
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
            activeTab === 'history' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          Activity
        </button>
      </div>

      {/* 1. FIAT TAB */}
      {activeTab === 'fiat' && (
        <div className="space-y-4">
          <div className="flex rounded-2xl neu-tab-bar p-1.5 gap-1.5 text-xs font-bold">
            <button
              onClick={() => setFiatMode('deposit')}
              className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
                fiatMode === 'deposit' ? 'neu-tab-active' : 'neu-tab-item'
              }`}
            >
              Deposit (Cash In)
            </button>
            <button
              onClick={() => setFiatMode('withdraw')}
              className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
                fiatMode === 'withdraw' ? 'neu-tab-active' : 'neu-tab-item'
              }`}
            >
              Withdraw (Cash Out)
            </button>
          </div>

          <form onSubmit={handleFiatSubmit} className="p-4 rounded-2xl neu-flat space-y-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-[var(--ink)] block">
                Channel / Provider
              </label>
              <div className="flex gap-2">
                {Object.entries(DEP).map(([k, d]) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setSelectedMethod(k)}
                    className={`flex-1 py-2 rounded-xl text-[11px] font-bold cursor-pointer transition ${
                      selectedMethod === k ? 'neu-tab-active' : 'neu-tab-item'
                    }`}
                  >
                    <span>{d.icon}</span> <span>{d.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-[var(--ink)] block">
                Amount ({cur})
              </label>
              <input
                type="number"
                min="1"
                step="any"
                required
                value={fiatAmount}
                onChange={(e) => setFiatAmount(e.target.value)}
                placeholder="0.00"
                className="w-full px-3.5 py-2.5 rounded-xl neu-input text-sm font-bold font-mono text-[var(--ink)]"
              />
            </div>

            {/* Dynamic Withdrawal Destination Details */}
            {fiatMode === 'withdraw' && selectedMethod === 'ewallet' && (
              <div className="p-3 rounded-xl neu-inset-sm space-y-2 border border-emerald-500/20">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-[var(--ink)]">
                    GCash / Maya Phone Number (SIM Card)
                  </label>
                  {getSimBadge(phoneOrSim) && (
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-mono">
                      {getSimBadge(phoneOrSim)}
                    </span>
                  )}
                </div>
                <input
                  type="tel"
                  required
                  maxLength={13}
                  value={phoneOrSim}
                  onChange={(e) => setPhoneOrSim(e.target.value)}
                  placeholder="0917 123 4567 or +639..."
                  className="w-full px-3 py-2 rounded-lg neu-input text-xs font-bold font-mono text-[var(--ink)] focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
                <span className="text-[10px] text-[var(--ink2)] block">
                  Enter registered SIM mobile number linked to your GCash or Maya account.
                </span>
              </div>
            )}

            {fiatMode === 'withdraw' && selectedMethod === 'bank' && (
              <div className="p-3 rounded-xl neu-inset-sm space-y-2.5 border border-emerald-500/20 text-xs">
                <div>
                  <label className="font-bold text-[var(--ink)] block mb-1">
                    Bank / Institution
                  </label>
                  <select
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg neu-input text-xs font-bold text-[var(--ink)] cursor-pointer"
                  >
                    <option value="BDO Unibank">BDO Unibank</option>
                    <option value="Bank of the Philippine Islands (BPI)">Bank of the Philippine Islands (BPI)</option>
                    <option value="UnionBank of the Philippines">UnionBank of the Philippines</option>
                    <option value="Metrobank">Metrobank</option>
                    <option value="Landbank of the Philippines">Landbank</option>
                    <option value="RCBC">RCBC</option>
                    <option value="Security Bank">Security Bank</option>
                    <option value="GCash Visa / Maya Mastercard">GCash Visa / Maya Card</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-[var(--ink)] block mb-1">
                    ATM / Savings Account Number
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={20}
                    value={bankAccount}
                    onChange={(e) => setBankAccount(e.target.value)}
                    placeholder="e.g. 001234567890"
                    className="w-full px-3 py-2 rounded-lg neu-input text-xs font-bold font-mono text-[var(--ink)]"
                  />
                </div>

                <div>
                  <label className="font-bold text-[var(--ink)] block mb-1">
                    Account Holder Name
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={40}
                    value={bankHolder}
                    onChange={(e) => setBankHolder(e.target.value)}
                    placeholder="Full name as printed on card/account"
                    className="w-full px-3 py-2 rounded-lg neu-input text-xs font-bold text-[var(--ink)]"
                  />
                </div>
              </div>
            )}

            {fiatMode === 'withdraw' && selectedMethod === 'otc' && (
              <div className="p-3 rounded-xl neu-inset-sm space-y-2 border border-emerald-500/20 text-xs">
                <label className="font-bold text-[var(--ink)] block">
                  7-Eleven Cliqq / Palawan Express Recipient Number
                </label>
                <input
                  type="tel"
                  required
                  value={phoneOrSim}
                  onChange={(e) => setPhoneOrSim(e.target.value)}
                  placeholder="0917 123 4567"
                  className="w-full px-3 py-2 rounded-lg neu-input text-xs font-bold font-mono text-[var(--ink)]"
                />
                <span className="text-[10px] text-[var(--ink2)] block">
                  SMS claim reference bar-code will be dispatched instantly upon authorization.
                </span>
              </div>
            )}

            <span className="text-[10px] text-[var(--ink2)] block">
              {fiatMode === 'withdraw'
                ? `Withdrawal fee: ₱${WFEE[selectedMethod]} · Instant automated clearing via Teraxiom Treasury`
                : 'Instant automated cash-in credited directly to your Axis account'}
            </span>

            <button
              type="submit"
              className="w-full py-3 rounded-xl neu-btn-accent font-extrabold text-sm cursor-pointer shadow-xs"
            >
              Confirm {fiatMode === 'deposit' ? 'Cash In' : 'Cash Out'}
            </button>
          </form>
        </div>
      )}

      {/* 2. CRYPTO TAB */}
      {activeTab === 'crypto' && (
        <div className="space-y-4">
          <div className="flex rounded-2xl neu-tab-bar p-1.5 gap-1.5 text-xs font-bold">
            <button
              onClick={() => setCryptoMode('send')}
              className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
                cryptoMode === 'send' ? 'neu-tab-active' : 'neu-tab-item'
              }`}
            >
              Send FLWRX
            </button>
            <button
              onClick={() => setCryptoMode('receive')}
              className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
                cryptoMode === 'receive' ? 'neu-tab-active' : 'neu-tab-item'
              }`}
            >
              Receive QR
            </button>
          </div>

          {cryptoMode === 'send' ? (
            <form onSubmit={handleCryptoSubmit} className="p-4 rounded-2xl neu-flat space-y-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-[var(--ink)] block">
                  Recipient Hex Address
                </label>
                <input
                  type="text"
                  required
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  placeholder="0x..."
                  className="w-full px-3.5 py-2.5 rounded-xl neu-input text-xs font-mono text-[var(--ink)]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-[var(--ink)] block">
                  Amount (FLWRX)
                </label>
                <input
                  type="number"
                  min="0.1"
                  step="any"
                  required
                  value={cryptoAmount}
                  onChange={(e) => setCryptoAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3.5 py-2.5 rounded-xl neu-input text-sm font-bold font-mono text-[var(--ink)]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl neu-btn-accent font-extrabold text-sm cursor-pointer shadow-xs"
              >
                Broadcast Transfer
              </button>
            </form>
          ) : (
            <div className="p-6 rounded-2xl neu-flat text-center space-y-3">
              <div className="w-36 h-36 mx-auto rounded-2xl neu-inset p-3 bg-white flex items-center justify-center">
                <QrCode className="w-28 h-28 text-emerald-900" />
              </div>
              <div>
                <b className="text-xs font-mono block text-[var(--ink)] break-all">
                  {state.address}
                </b>
                <span className="text-[10px] text-[var(--ink2)]">
                  Your Axis decentralized wallet address
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. HISTORY TAB */}
      {activeTab === 'history' && (
        <div className="p-4 rounded-2xl neu-flat space-y-2">
          {(!state.tx || state.tx.length === 0) ? (
            <p className="text-xs text-[var(--ink2)] text-center py-6">
              No transactions on record yet.
            </p>
          ) : (
            state.tx.slice(0, 15).map((t) => (
              <div key={t.id} className="p-2.5 rounded-xl neu-inset flex items-center justify-between text-xs">
                <div>
                  <b className="block text-[var(--ink)]">{t.label}</b>
                  <span className="text-[10px] text-[var(--ink2)] font-mono">
                    {new Date(t.ts).toLocaleDateString()} · {t.type}
                  </span>
                </div>
                <span className={`font-bold font-mono ${t.flrx > 0 || t.php > 0 ? 'text-emerald-600' : 'text-zinc-600'}`}>
                  {t.flrx !== 0 ? `${t.flrx > 0 ? '+' : ''}${fmtF(t.flrx)} FLWRX` : `${t.php > 0 ? '+' : ''}${peso(t.php, cur)}`}
                </span>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
