import React, { useEffect, useState } from 'react';
import { Activity, ShieldCheck, Flame } from 'lucide-react';

interface FeedItem {
  id: string;
  user: string;
  action: string;
  reward: string;
  time: string;
}

const INITIAL_FEED: FeedItem[] = [
  { id: '1', user: 'User #842', action: 'Verified Nestlé Coffee barcode', reward: '+12.5 FLRX', time: '1m ago' },
  { id: '2', user: 'Alex_PH', action: 'Bought 200 FLRX on Spot', reward: 'Filled', time: '2m ago' },
  { id: '3', user: 'Maria_99', action: 'Completed Daily Scan Streak', reward: '7-Day 🔥', time: '3m ago' },
  { id: '4', user: 'NexusNode_4', action: 'Verified San Miguel product', reward: '+15.0 FLRX', time: '4m ago' },
  { id: '5', user: 'CryptoRider', action: 'Staked 1,500 FLRX in Vault', reward: '14.2% APY', time: '6m ago' }
];

export const SocialTicker: React.FC = () => {
  const [items, setItems] = useState<FeedItem[]>(INITIAL_FEED);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % items.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [items.length]);

  const current = items[index] || items[0];

  return (
    <div className="w-full my-3 p-3 rounded-xl neu-card select-none" aria-label="Live Network Activity">
      <div className="flex items-center justify-between gap-3 text-xs text-[var(--ink2)] font-mono">
        <div className="flex items-center gap-2 min-w-0 truncate">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
          <span className="font-bold text-[var(--ink)]">{current.user}</span>
          <span aria-hidden="true" className="opacity-40">·</span>
          <span className="truncate">{current.action.replace('barcode', 'QR code')}</span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="font-bold text-emerald-700 dark:text-emerald-400">
            {current.reward}
          </span>
          <span aria-hidden="true" className="opacity-40">·</span>
          <span className="text-[11px] opacity-75">{current.time}</span>
        </div>
      </div>
    </div>
  );
};
