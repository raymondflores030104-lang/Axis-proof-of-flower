import React, { useState } from 'react';
import { AxisState } from '../types';
import { MISSIONS } from '../constants';
import { Target, CheckCircle2 } from 'lucide-react';

interface MissionsModalProps {
  state: AxisState;
  onClaimMission: (m: typeof MISSIONS[0]) => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const MissionsModal: React.FC<MissionsModalProps> = ({
  state,
  onClaimMission
}) => {
  const [tab, setTab] = useState<'d' | 'w'>('d');
  const filtered = MISSIONS.filter((m) => m.t === tab);

  return (
    <div className="space-y-4 select-none">
      <div className="flex rounded-2xl neu-tab-bar p-1.5 text-xs font-bold gap-1.5">
        <button
          onClick={() => setTab('d')}
          className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
            tab === 'd' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          Daily Tasks
        </button>
        <button
          onClick={() => setTab('w')}
          className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
            tab === 'w' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          Weekly Goals
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 landscape:grid-cols-2 gap-2.5">
        {filtered.map((m) => {
          const claimedList = m.t === 'd' ? (state.day?.missions || []) : (state.week?.missions || []);
          const isClaimed = claimedList.includes(m.id);
          const currentProg = m.prog(state);
          const cappedProg = Math.min(m.goal, currentProg);
          const isDone = cappedProg >= m.goal;

          return (
            <div key={m.id} className="p-3.5 rounded-2xl neu-flat space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <b className="text-xs font-bold block text-[var(--ink)]">{m.title}</b>
                  <p className="text-[11px] text-[var(--ink2)]">{m.desc}</p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-xs font-black font-mono text-emerald-600 dark:text-emerald-400 block">
                    +{m.reward} FLWRX
                  </span>
                  <span className="text-[10px] text-[var(--ink2)] font-mono">
                    +{m.xp} XP
                  </span>
                </div>
              </div>

              {/* Progress Bar & Claim Button */}
              <div className="flex items-center justify-between gap-3 pt-1 border-t border-[var(--neu-border-dark)]">
                <div className="flex-1">
                  <div className="flex justify-between text-[10px] font-mono text-[var(--ink2)] mb-1">
                    <span>Progress:</span>
                    <span>{cappedProg} / {m.goal}</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full neu-inset overflow-hidden">
                    <div
                      className="h-full bg-emerald-600 rounded-full transition-all duration-300"
                      style={{ width: `${(cappedProg / m.goal) * 100}%` }}
                    />
                  </div>
                </div>

                <button
                  onClick={() => onClaimMission(m)}
                  disabled={!isDone || isClaimed}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs shrink-0 cursor-pointer transition ${
                    isClaimed
                      ? 'neu-inset opacity-50 cursor-not-allowed text-[var(--ink2)]'
                      : isDone
                      ? 'neu-tab-active font-extrabold'
                      : 'neu-tab-item opacity-60 cursor-not-allowed'
                  }`}
                >
                  {isClaimed ? 'Claimed ✓' : isDone ? 'Claim Reward' : 'In Progress'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
