import React from 'react';
import { AxisState } from '../types';
import { Trophy, Gift, Cpu, User, Users, Building2 } from 'lucide-react';

interface HeaderProps {
  state: AxisState;
  onOpenScreen: (screen: string) => void;
  isLandscape?: boolean;
  pricePHP?: number;
  chg24?: number;
}

export const Header: React.FC<HeaderProps> = ({
  state,
  onOpenScreen,
  isLandscape = false,
  pricePHP,
  chg24 = 2.45
}) => {
  const claimedToday = Boolean(state?.claim?.last && state?.claim?.last === state?.day?.key);

  const activeCur = state.settings?.currency || 'PHP';
  const pairLabel = `FLWRX/${activeCur}:`;
  const displayPrice = activeCur === 'USD'
    ? `$${state.price.toFixed(4)}`
    : `₱${(state.price * 58).toFixed(2)}`;

  return (
    <div
      data-zone="header"
      className={`header-shell flex items-center justify-between gap-[clamp(0.5rem,1.5vw,1rem)] select-none w-full ${
        isLandscape
          ? 'py-[clamp(0.2rem,0.6vh,0.4rem)] px-1 mb-[clamp(0.25rem,0.9vh,0.6rem)] max-w-[1320px] mx-auto'
          : 'mb-[clamp(0.35rem,1.1vh,0.75rem)] px-0.5'
      }`}
    >
      {/* Lobby Navigation Buttons - 3 Core Gamified Rewards */}
      <div data-zone="actions" className="flex items-center gap-[clamp(0.35rem,1vw,0.5rem)] shrink-0">
        <button
          onClick={() => onOpenScreen('achievements')}
          aria-label="Achievements & Leaderboard"
          title="Achievements & Leaderboard"
          className="w-[clamp(32px,4.5vh,40px)] h-[clamp(32px,4.5vh,40px)] min-w-[32px] min-h-[32px] rounded-xl neu-btn text-amber-600 dark:text-amber-400 flex items-center justify-center cursor-pointer transition-transform active:scale-95 focus-visible:ring-2 focus-visible:ring-amber-500"
        >
          <Trophy className="w-[clamp(0.9rem,2vh,1.1rem)] h-[clamp(0.9rem,2vh,1.1rem)]" />
        </button>

        <button
          onClick={() => onOpenScreen('referral')}
          aria-label="Referral Ladder & Community"
          title="Referral Ladder & Community"
          className="w-[clamp(32px,4.5vh,40px)] h-[clamp(32px,4.5vh,40px)] min-w-[32px] min-h-[32px] rounded-xl neu-btn text-teal-600 dark:text-teal-400 flex items-center justify-center cursor-pointer transition-transform active:scale-95 focus-visible:ring-2 focus-visible:ring-teal-500"
        >
          <Users className="w-[clamp(0.9rem,2vh,1.1rem)] h-[clamp(0.9rem,2vh,1.1rem)]" />
        </button>

        <button
          onClick={() => onOpenScreen('daily')}
          aria-label="Daily Check-in Reward"
          title="Daily Check-in Reward"
          className="relative w-[clamp(32px,4.5vh,40px)] h-[clamp(32px,4.5vh,40px)] min-w-[32px] min-h-[32px] rounded-xl neu-btn text-rose-600 dark:text-rose-400 flex items-center justify-center cursor-pointer transition-transform active:scale-95 focus-visible:ring-2 focus-visible:ring-rose-500"
        >
          <Gift className="w-[clamp(0.9rem,2vh,1.1rem)] h-[clamp(0.9rem,2vh,1.1rem)]" />
          {!claimedToday && (
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-rose-600 border border-white animate-pulse" />
          )}
        </button>
      </div>

      {/* Brand Header */}
      <div className="flex items-center justify-center gap-[clamp(0.5rem,1.5vw,1rem)] min-w-0 flex-1">
        <div
          data-zone="brand"
          className="text-center cursor-pointer group px-2 py-0.5 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-colors focus-visible:outline-hidden flex flex-col justify-center items-center shrink-0"
          onClick={() => onOpenScreen('loading')}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') onOpenScreen('loading');
          }}
          tabIndex={0}
          role="button"
          title="Axis Proof of Flower • Tap to replay intro loading screen"
          aria-label="Axis: Proof of Flower"
        >
          <h1 className="font-brand text-[clamp(1.15rem,2.8vw,1.55rem)] landscape:text-[clamp(1.05rem,2.2vh,1.4rem)] font-black tracking-tight leading-none text-[var(--accent)] truncate group-hover:opacity-90 transition-opacity">
            Axis
          </h1>
          <p className="text-[clamp(8.5px,1.2vw,10.5px)] landscape:text-[clamp(8.5px,1.5vh,10px)] text-[var(--ink2)] font-extrabold tracking-[0.16em] uppercase truncate mt-0.5 leading-tight">
            Proof of Flower
          </p>
        </div>
      </div>

      {/* Profile / Avatar Trigger */}
      <div data-zone="avatar" className="shrink-0">
        <button
          onClick={() => onOpenScreen('profile')}
          aria-label="User Profile & Settings"
          title="User Profile"
          className="w-[clamp(32px,4.5vh,40px)] h-[clamp(32px,4.5vh,40px)] min-w-[32px] min-h-[32px] rounded-xl neu-btn text-[var(--ink)] flex items-center justify-center overflow-hidden cursor-pointer transition-transform active:scale-95 focus-visible:ring-2 focus-visible:ring-emerald-500"
        >
          {state.profile?.avatar && state.profile.avatar.startsWith('data:') ? (
            <img src={state.profile.avatar} alt="Profile" className="w-full h-full object-cover" />
          ) : (
            <User className="w-[clamp(0.9rem,2vh,1.15rem)] h-[clamp(0.9rem,2vh,1.15rem)]" />
          )}
        </button>
      </div>
    </div>
  );
};
