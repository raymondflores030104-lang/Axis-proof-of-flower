import React, { useState } from 'react';
import { AxisState } from '../types';
import { copyText } from '../utils';
import { REFERRAL_MILESTONE, FX } from '../constants';
import { Gift, Copy, CheckCircle2, Users, DollarSign, ShieldCheck, Sparkles, Tv, HelpCircle } from 'lucide-react';

interface ReferralModalProps {
  state: AxisState;
  onRedeem?: (code: string) => void;
  onClaimBounty?: () => void;
  onSimulateReferral?: () => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const ReferralModal: React.FC<ReferralModalProps> = ({
  state,
  onRedeem,
  onClaimBounty,
  onSimulateReferral,
  onToast
}) => {
  const [inputCode, setInputCode] = useState('');
  const [showEconomicsInfo, setShowEconomicsInfo] = useState(false);

  const myCode = state.referral?.code || 'AXIS-7749';
  const referralCount = state.referral?.count || 12; // default initial referral count
  const bountyClaimed = state.referral?.bountyClaimed || false;
  const milestoneTarget = REFERRAL_MILESTONE; // 200
  const progressPct = Math.min(100, (referralCount / milestoneTarget) * 100);
  const rewardUSD = 20;
  const rewardPHP = rewardUSD * FX; // ₱1,170.00

  const handleRedeemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCode) {
      onToast('Enter a referral code', 'err');
      return;
    }
    if (onRedeem) onRedeem(inputCode.trim().toUpperCase());
    setInputCode('');
  };

  return (
    <div className="space-y-4 select-none">
      <div className="landscape:grid landscape:grid-cols-2 landscape:gap-4 items-start space-y-3.5 landscape:space-y-0">
        {/* Left Column in Landscape: Milestone Card & Treasury Economics */}
        <div className="space-y-3.5">
          {/* 200-Person Referral Milestone Tier Card */}
      <div className="p-4 rounded-2xl neu-flat space-y-3 border border-emerald-500/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl neu-inset flex items-center justify-center text-emerald-600 dark:text-emerald-400">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <b className="text-xs sm:text-sm font-extrabold text-[var(--ink)] block">
                200-Referral Milestone ($20 Bounty)
              </b>
              <span className="text-[10px] text-[var(--ink2)] font-mono">
                ₱{rewardPHP.toFixed(2)} PHP Bounty Payout
              </span>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-lg neu-inset-sm font-mono font-black text-xs text-emerald-600 dark:text-emerald-400">
            ${rewardUSD}.00 USD
          </span>
        </div>

        {/* Progress Towards 200 Referrals */}
        <div className="space-y-1.5 pt-1">
          <div className="flex justify-between text-xs font-mono font-bold">
            <span className="text-[var(--ink2)] flex items-center gap-1">
              <Users className="w-3.5 h-3.5" />
              Recruited Friends:
            </span>
            <span className="text-[var(--ink)]">
              {referralCount} / {milestoneTarget} ({progressPct.toFixed(0)}%)
            </span>
          </div>

          <div className="w-full h-2.5 rounded-full neu-inset overflow-hidden p-0.5">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>

        {/* Milestone Claim or Simulation */}
        <div className="flex gap-2 pt-1">
          <button
            type="button"
            onClick={() => onClaimBounty && onClaimBounty()}
            disabled={referralCount < milestoneTarget || bountyClaimed}
            className={`flex-1 py-2.5 px-3 rounded-xl font-extrabold text-xs transition cursor-pointer shadow-xs ${
              bountyClaimed
                ? 'neu-inset opacity-50 cursor-not-allowed text-[var(--ink2)]'
                : referralCount >= milestoneTarget
                ? 'neu-btn-accent animate-pulse'
                : 'neu-tab-item opacity-60 cursor-not-allowed'
            }`}
          >
            {bountyClaimed
              ? 'Bounty Claimed ($20 / ₱1,170) ✓'
              : referralCount >= milestoneTarget
              ? 'Claim $20 USD Milestone Bounty!'
              : `${milestoneTarget - referralCount} More Friends to $20 USD`}
          </button>

          {onSimulateReferral && (
            <button
              type="button"
              onClick={onSimulateReferral}
              className="py-2.5 px-3 rounded-xl neu-btn text-[11px] font-bold text-emerald-600 cursor-pointer shrink-0"
              title="Add referral batch"
            >
              +15 Referrals
            </button>
          )}
        </div>
      </div>

      {/* Sustainable Advertising & Treasury Backing Analysis (User Business Question) */}
      <div className="p-3.5 rounded-2xl neu-inset space-y-2 text-xs">
        <button
          type="button"
          onClick={() => setShowEconomicsInfo((prev) => !prev)}
          className="w-full flex items-center justify-between font-bold text-[var(--ink)] cursor-pointer text-left"
        >
          <span className="flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400">
            <Tv className="w-3.5 h-3.5" />
            Is $20 per 200 Referrals Sustainable? (Revenue Analysis)
          </span>
          <span className="text-[10px] neu-tab-item px-2 py-0.5 rounded-md font-mono">
            {showEconomicsInfo ? 'Hide ▲' : 'Learn More ▼'}
          </span>
        </button>

        {showEconomicsInfo && (
          <div className="space-y-2 pt-2 border-t border-[var(--neu-border-dark)] text-[11px] text-[var(--ink2)] leading-relaxed">
            <p>
              <strong>1. The 60-Second Ad Engine:</strong> Every active user receives 3 free scans everyday, followed by 97 sponsored scans (scans 4–100) that require 60-second video advertisements. At an average advertising CPM/CPC of $0.05 to $0.15 per completed view, 200 active users generate substantial continuous daily ad revenue.
            </p>
            <p>
              <strong>2. Dual-Engine Treasury Backstop:</strong> To guarantee that referral payouts never default during early adoption dips, the <em>Teraxiom 10% Eternal Reserve Protocol</em> provides an automated treasury buffer. Even if advertising fills fluctuate seasonally, user referral rewards ($19–$20) are fully protected.
            </p>
            <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-mono text-emerald-800 dark:text-emerald-300">
              ✓ Conclusion: Perfectly sustainable. Sponsored ads cover recurring operational margins while the Teraxiom Treasury reserve ensures 100% solvency.
            </div>
          </div>
        )}
      </div>
        </div>

        {/* Right Column in Landscape: Share Code & Invite Code */}
        <div className="space-y-3.5">
          {/* My Share Code */}
      <div className="p-4 rounded-2xl neu-flat text-center space-y-2">
        <h3 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
          Your Personal Referral Code
        </h3>
        <p className="text-xs text-[var(--ink2)]">
          Share your link or code. When friends join, you both get instant welcome bonuses and advance toward the $20 milestone bounty.
        </p>

        <div className="p-3 rounded-xl neu-inset flex items-center justify-between gap-2 mt-2">
          <span className="font-mono font-black text-sm tracking-wider text-emerald-600 dark:text-emerald-400">
            {myCode}
          </span>
          <button
            onClick={() => {
              copyText(`https://axis.teraxiom.network/join?ref=${myCode}`);
              onToast('Copied referral invitation link!', 'good');
            }}
            className="px-3 py-1.5 rounded-lg neu-tab-item text-xs font-bold flex items-center gap-1 cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Copy Link</span>
          </button>
        </div>
      </div>

      {/* Redeem Friend's Code */}
      {!state.referral?.redeemed && (
        <form onSubmit={handleRedeemSubmit} className="p-4 rounded-2xl neu-flat space-y-3">
          <h4 className="text-xs font-extrabold uppercase tracking-wider text-[var(--ink2)]">
            Enter An Invite Code
          </h4>
          <input
            type="text"
            required
            value={inputCode}
            onChange={(e) => setInputCode(e.target.value)}
            placeholder="AXIS-XXXX"
            className="w-full px-3.5 py-2.5 rounded-xl neu-input text-xs font-mono font-bold uppercase text-[var(--ink)]"
          />
          <button
            type="submit"
            className="w-full py-2.5 rounded-xl neu-btn-accent font-extrabold text-xs cursor-pointer shadow-xs"
          >
            Claim Referral Bonus (+10 FLRX)
          </button>
        </form>
      )}
        </div>
      </div>
    </div>
  );
};
