import React, { useState } from 'react';
import { SkeletonLoader } from './SkeletonLoader';
import { TelemetryDashboardModal } from './TelemetryDashboardModal';
import { SubscriptionModal } from './SubscriptionModal';

interface PrinciplesShowcaseModalProps {
  onOpenOnboarding: () => void;
  onSimulateBackgroundOp: () => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const PrinciplesShowcaseModal: React.FC<PrinciplesShowcaseModalProps> = ({
  onOpenOnboarding,
  onSimulateBackgroundOp,
  onToast
}) => {
  const [activeTab, setActiveTab] = useState<'1' | '2' | '3' | '4' | '5' | '6'>('1');
  const [showSkeletonView, setShowSkeletonView] = useState(false);
  const [showErrorComparison, setShowErrorComparison] = useState<'good' | 'bad'>('good');

  return (
    <div className="space-y-4 select-none">
      {/* Principle Tabs 1 through 6 */}
      <div className="grid grid-cols-6 gap-1 p-1.5 rounded-2xl neu-tab-bar text-xs font-bold font-mono">
        {(['1', '2', '3', '4', '5', '6'] as const).map((num) => (
          <button
            key={num}
            type="button"
            onClick={() => setActiveTab(num)}
            className={`py-2 rounded-xl text-center cursor-pointer transition ${
              activeTab === num ? 'neu-tab-active' : 'neu-tab-item'
            }`}
          >
            #{num}
          </button>
        ))}
      </div>

      {/* #1 SKELETON LOADERS VS SPINNERS */}
      {activeTab === '1' && (
        <div className="space-y-3.5">
          <div className="p-4 rounded-3xl neu-flat space-y-2">
            <span className="text-[10px] font-black uppercase text-rose-600 bg-rose-100 dark:bg-rose-950 px-2 py-0.5 rounded-md">
              #1 Spinning Loaders vs Skeletons
            </span>
            <h3 className="font-extrabold text-sm text-[var(--ink)]">
              Match the Layout of the Actual Screen
            </h3>
            <p className="text-xs text-[var(--ink2)] leading-relaxed">
              If you know what content is about to appear, use skeleton loaders that match the layout of the actual screen. The app immediately feels faster and more polished, even when loading time hasn&apos;t changed.
            </p>

            <button
              type="button"
              onClick={() => setShowSkeletonView(!showSkeletonView)}
              className="mt-2 w-full py-2.5 px-4 rounded-xl neu-tab-active font-extrabold text-xs cursor-pointer btn-instant-tap flex items-center justify-center gap-1.5"
            >
              <span>{showSkeletonView ? 'Hide Skeleton View' : '👁️ View Live Skeleton Screen'}</span>
            </button>
          </div>

          {showSkeletonView ? (
            <div className="p-2 rounded-3xl border-2 border-emerald-500/40 bg-[var(--bg)] max-h-72 overflow-y-auto">
              <SkeletonLoader />
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-3 rounded-2xl neu-inset opacity-70 space-y-1">
                <span className="text-rose-600 font-bold font-mono">✕ Generic Spinner</span>
                <p className="text-[11px] text-[var(--ink2)]">Blank screen with center circle forces user to wonder where elements will land.</p>
              </div>
              <div className="p-3 rounded-2xl neu-flat border border-emerald-500/30 space-y-1">
                <span className="text-emerald-700 dark:text-emerald-400 font-bold font-mono">✓ Layout Skeleton</span>
                <p className="text-[11px] text-[var(--ink)]">Pre-cognitive geometry with subtle shimmers creates perceived instant load.</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* #2 ZERO DARK PATTERNS */}
      {activeTab === '2' && (
        <div className="space-y-3.5">
          <div className="p-4 rounded-3xl neu-flat space-y-2">
            <span className="text-[10px] font-black uppercase text-rose-600 bg-rose-100 dark:bg-rose-950 px-2 py-0.5 rounded-md">
              #2 Dark Patterns vs Honest Subscriptions
            </span>
            <h3 className="font-extrabold text-sm text-[var(--ink)]">
              One Tap, No Questions Asked
            </h3>
            <p className="text-xs text-[var(--ink2)] leading-relaxed">
              Making subscriptions easy to start but difficult to cancel might make short-term money, but trades revenue for user trust. That is never worth it.
            </p>
          </div>

          <SubscriptionModal onToast={onToast} />
        </div>
      )}

      {/* #3 BUTTONS THAT RESPOND INSTANTLY */}
      {activeTab === '3' && (
        <div className="space-y-3.5">
          <div className="p-4 rounded-3xl neu-flat space-y-2">
            <span className="text-[10px] font-black uppercase text-rose-600 bg-rose-100 dark:bg-rose-950 px-2 py-0.5 rounded-md">
              #3 Instant Response &amp; Background Handling
            </span>
            <h3 className="font-extrabold text-sm text-[var(--ink)]">
              Immediate UI Acknowledgement
            </h3>
            <p className="text-xs text-[var(--ink2)] leading-relaxed">
              When someone taps something, the UI acknowledges immediately. For longer actions like uploading or on-chain hashing, update the UI first and handle work in the background.
            </p>

            <button
              type="button"
              onClick={onSimulateBackgroundOp}
              className="mt-2 w-full py-3 px-4 rounded-2xl neu-btn-accent font-extrabold text-xs cursor-pointer shadow-md btn-instant-tap flex items-center justify-center gap-2"
            >
              <span>⚡ Trigger Action (Experience Instant Feedback)</span>
            </button>
          </div>

          <div className="p-3.5 rounded-2xl neu-inset text-xs space-y-1">
            <b className="text-[var(--ink)] block">What just happens on tap:</b>
            <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
              1. Tactile compression micro-animation fires at 0ms.<br />
              2. Floating status pill &apos;Added, uploading / syncing...&apos; mounts immediately.<br />
              3. Local balances and lists update optimistically.<br />
              4. Heavy cryptographic work finishes silently in the background.
            </p>
          </div>
        </div>
      )}

      {/* #4 BUTTONS THAT MOVE AROUND */}
      {activeTab === '4' && (
        <div className="space-y-3.5">
          <div className="p-4 rounded-3xl neu-flat space-y-2">
            <span className="text-[10px] font-black uppercase text-rose-600 bg-rose-100 dark:bg-rose-950 px-2 py-0.5 rounded-md">
              #4 Buttons Moving Around During Onboarding
            </span>
            <h3 className="font-extrabold text-sm text-[var(--ink)]">
              Always In One Predictable Spot
            </h3>
            <p className="text-xs text-[var(--ink2)] leading-relaxed">
              Your continue button shouldn&apos;t be at the bottom on one screen, in the middle on another, and jumping around on the next. Keep primary actions in consistent positions so thumbs already know where to tap.
            </p>

            <button
              type="button"
              onClick={onOpenOnboarding}
              className="mt-2 w-full py-3 px-4 rounded-2xl neu-tab-active font-extrabold text-xs cursor-pointer btn-instant-tap flex items-center justify-center gap-2"
            >
              <span>👉 Launch Fixed-Anchor Onboarding Flow</span>
            </button>
          </div>
        </div>
      )}

      {/* #5 SHOWING USERS YOUR BACKEND */}
      {activeTab === '5' && (
        <div className="space-y-3.5">
          <div className="p-4 rounded-3xl neu-flat space-y-2">
            <span className="text-[10px] font-black uppercase text-rose-600 bg-rose-100 dark:bg-rose-950 px-2 py-0.5 rounded-md">
              #5 Showing Users Your Backend
            </span>
            <h3 className="font-extrabold text-sm text-[var(--ink)]">
              Never Expose 404, 500, or Stack Traces
            </h3>
            <p className="text-xs text-[var(--ink2)] leading-relaxed">
              Catch exceptions, log them silently to an internal diagnostic buffer, and show a simple message explaining what they should do next with reassuring copy.
            </p>

            {/* Toggle state comparison views */}
            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowErrorComparison('bad')}
                className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                  showErrorComparison === 'bad' ? 'bg-rose-600 text-white' : 'neu-tab-item'
                }`}
              >
                ✕ Bad: Raw Backend Error
              </button>
              <button
                type="button"
                onClick={() => setShowErrorComparison('good')}
                className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                  showErrorComparison === 'good' ? 'neu-tab-active font-extrabold' : 'neu-tab-item'
                }`}
              >
                ✓ Good: Clear Next Step
              </button>
            </div>
          </div>

          {showErrorComparison === 'bad' ? (
            <div className="p-4 rounded-3xl bg-zinc-900 text-zinc-100 font-mono text-[11px] space-y-2 border border-rose-500/50 shadow-inner">
              <span className="text-rose-400 font-bold block text-xs">500 Internal Server Error (NEVER SHOW THIS)</span>
              <p className="text-zinc-400 text-[10px] leading-tight">
                TypeError: Cannot read properties of undefined (reading &apos;id&apos;)<br />
                &nbsp;&nbsp;at getFeed (/api/v2/feed.js:48:17)<br />
                &nbsp;&nbsp;at Layer.handle (router/layer.js:95:5)<br />
                &nbsp;&nbsp;at pg.query (db/pool.js:212:9)<br />
                ECONNREFUSED 10.0.3.14:5432
              </p>
            </div>
          ) : (
            <div className="p-6 rounded-3xl neu-flat text-center space-y-3 border border-emerald-500/30">
              <div className="w-12 h-12 mx-auto rounded-full neu-inset flex items-center justify-center font-bold text-base">
                !
              </div>
              <h4 className="font-extrabold text-sm text-[var(--ink)]">We couldn&apos;t load your feed</h4>
              <p className="text-xs text-[var(--ink2)] leading-relaxed max-w-xs mx-auto">
                Check your connection and try again. Your data is safe.
              </p>
              <button
                type="button"
                onClick={() => onToast('✓ Connection refreshed safely', 'good')}
                className="w-full py-2.5 rounded-xl bg-[var(--tab-active-bg)] text-[var(--tab-active-ink)] font-extrabold text-xs cursor-pointer btn-instant-tap"
              >
                Try again
              </button>
            </div>
          )}
        </div>
      )}

      {/* #6 WHAT HAPPENS AFTER LAUNCH */}
      {activeTab === '6' && (
        <TelemetryDashboardModal />
      )}
    </div>
  );
};
