import React, { useEffect, useRef, useState, memo } from 'react';

interface CosmicBlackHoleProps {
  enabled?: boolean;
  speed?: 'slow' | 'medium' | 'fast';
  lowPowerMode?: boolean;
  relativitySlide?: number;
}

/* =========================================================================
   CINEMATIC 8K PHYSICALLY ACCURATE INTERSTELLAR BLACK HOLE (Gargantua)
   Features:
   - Perfect, pitch-black spherical event horizon completely devoid of light
   - Brilliant, blazing accretion disk of superheated cosmic dust & white-hot plasma gas
   - Intense relativistic Doppler beaming: approaching limb is blindingly bright & blue-shifted,
     receding limb is dimmed, diffused, and redshifted
   - Flawless Einsteinian gravitational lensing: rear accretion disk warped vertically over
     the top and underneath the sphere, creating the iconic halo-ring silhouette
   - Ultra-thin razor-sharp photon ring along the shadow boundary
   - Complex ray deflection producing fine, fiery filament lines and plasma micro-striations
   - Deep-space backdrop with physically stretched concentric Einstein-arc starfields & faint nebulae
   - Volumetric space-dust illumination and ACES filmic tonemapping
   ========================================================================= */

const BLACKHOLE_VS = `attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}`;

const BLACKHOLE_FS = `#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

uniform vec2 R;
uniform float T, uSpeed, uGlow, uPull, uLowQ;

// PRNG & Noise primitives
float h21(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
vec2 h22(vec2 p){float n=h21(p);return vec2(n,h21(p+n+7.1));}
float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h21(i),h21(i+vec2(1,0)),f.x),mix(h21(i+vec2(0,1)),h21(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<5;i++){s+=a*vn(p);p=mat2(1.6,1.2,-1.2,1.6)*p;a*=.5;}return s;}
mat2 rot(float a){float c=cos(a),s=sin(a);return mat2(c,-s,s,c);}

void main(){
  // Isotropic aspect normalization: preserves geometry without stretching on any screen size or ratio
  float minDim = min(R.x, R.y);
  vec2 uv = (gl_FragCoord.xy * 2.0 - R) / minDim;

  // Position black hole: in portrait, centered gracefully at (0.0, 0.28); in landscape, centered at (0.04, 0.02) behind Nexus Scan
  bool isPortrait = R.x < R.y;
  vec2 center = isPortrait ? vec2(0.0, 0.28) : vec2(0.04, 0.02);
  vec2 p = uv - center;

  // Accretion disk diagonal tilt angle (~ -27.5 degrees)
  float tilt = -0.48;
  mat2 rotM = rot(tilt);
  vec2 pr = rotM * p;

  float r = length(p);
  float r_s = 0.435; // Schwarzschild radius (event horizon)

  // 1. PERFECT PITCH-BLACK EVENT HORIZON (DEVOID OF ALL LIGHT)
  if(r < r_s * 0.92){
    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    return;
  }

  // 2. FLAWLESS EINSTEINIAN GRAVITATIONAL LENSING FIELD
  // General relativistic gravitational deflection angle alpha ~ (r_s / r)^2.25
  float deflect = pow(r_s / max(r, 0.01), 2.25) * 0.54 * uPull;
  vec2 pBent = p - normalize(p + 1e-4) * deflect;
  vec2 prBent = rotM * pBent;

  // Accretion Disk Radial Coordinates
  float rDisk = length(vec2(pr.x, pr.y * 3.4));
  float rDiskBent = length(vec2(prBent.x, prBent.y * 3.0));

  float ang = atan(pr.y, pr.x);
  float angBent = atan(prBent.y, prBent.x);

  // Differential Keplerian orbital velocities: inner matter orbits at a relativistic fraction of c
  float omega1 = (2.2 / max(rDisk, 0.18)) * uSpeed;
  float omega2 = (2.8 / max(rDiskBent, 0.16)) * uSpeed;

  // Active Inward Gravitational Suction (Spiral matter inflow into the singularity!)
  float suction1 = 1.15 * log(max(rDisk, 0.12)) * uPull;
  float suction2 = 1.35 * log(max(rDiskBent, 0.12)) * uPull;

  float swirl1 = ang - suction1 - T * omega1;
  float swirl2 = angBent - suction2 - T * omega2;

  // 3. FINE FIERY FILAMENT LINES & HIGH-FREQUENCY CHURNING PLASMA (Band-limited to prevent moiré aliasing)
  float fil1 = fbm(vec2(rDisk * 22.0, swirl1 * 4.0));
  float fil2 = vn(vec2(rDisk * 45.0, swirl1 * 8.5 + T * 0.45 * uSpeed));
  float fil3 = abs(sin(rDisk * 52.0 + fil1 * 3.5 + swirl1 * 6.0));
  float fil4 = vn(vec2(rDisk * 64.0, swirl2 * 10.0));
  float microStriations = clamp(fil1 * 0.46 + fil2 * 0.34 + fil3 * 0.26 + fil4 * 0.20, 0.0, 1.65);

  float filBent1 = fbm(vec2(rDiskBent * 24.0, swirl2 * 5.0));
  float filBent2 = vn(vec2(rDiskBent * 55.0, swirl2 * 9.5));
  float bentMicro = clamp(filBent1 * 0.55 + filBent2 * 0.45, 0.0, 1.55);

  // 4. INTENSE RELATIVISTIC DOPPLER BEAMING
  // Approaching limb (left side rotating toward camera) is blindingly bright & blue-white shifted;
  // Receding limb (right side rotating away) is dimmer, cooler, and redshifted.
  float doppler = clamp(0.58 - pr.x * 1.48, 0.14, 3.4);
  float dopplerBoost = pow(doppler, 1.65);

  // Primary Equatorial Accretion Disk
  float innerISCO = smoothstep(r_s * 0.96, r_s * 1.45, rDisk);
  float outerDisk = smoothstep(3.2, 0.5, rDisk);
  float diskThickness = exp(-abs(pr.y) * 19.5);
  float diskIntensity = diskThickness * innerISCO * outerDisk * (0.65 + microStriations * 0.72);

  // 5. ICONIC EINSTEINIAN HALO-RING SILHOUETTE (WARPED REAR DISK)
  // Gravitational Lensing Top Arc (Back of accretion disk bent vertically over the event horizon)
  float topArcDist = abs(r - r_s * 1.28);
  float topArcMask = smoothstep(r_s * 0.92, r_s * 1.06, r) * smoothstep(0.48, 0.0, topArcDist);
  float topArc = exp(-topArcDist * 18.0) * (0.65 + bentMicro * 0.62) * topArcMask;

  // Gravitational Lensing Bottom Arc (Underside of disk bent below the shadow)
  float bottomArcDist = abs(r - r_s * 1.18);
  float bottomArcMask = smoothstep(r_s * 0.92, r_s * 1.06, r) * smoothstep(0.32, 0.0, bottomArcDist);
  float bottomArc = exp(-bottomArcDist * 24.0) * bottomArcMask * 0.88;

  // Razor-Sharp Photon Sphere Ring along the shadow edge
  float photonDist = abs(r - r_s * 1.018);
  float photonRing = exp(-photonDist * 75.0) * 3.6;

  // Orbiting Plasma Hotspots & Flares plunging into the event horizon
  float flareAngle1 = mod(T * 2.4 * uSpeed, 6.28318);
  vec2 flarePos1 = vec2(cos(flareAngle1), sin(flareAngle1)) * r_s * 1.35;
  float flare1 = exp(-length(pr - flarePos1) * 14.0) * 1.8;

  float flareAngle2 = mod(T * 1.6 * uSpeed + 2.4, 6.28318);
  vec2 flarePos2 = vec2(cos(flareAngle2), sin(flareAngle2)) * r_s * 1.75;
  float flare2 = exp(-length(pr - flarePos2) * 11.0) * 1.4;

  float flareAngle3 = mod(T * 3.1 * uSpeed + 4.5, 6.28318);
  vec2 flarePos3 = vec2(cos(flareAngle3), sin(flareAngle3)) * r_s * 1.15;
  float flare3 = exp(-length(prBent - flarePos3) * 18.0) * 2.2;

  float totalLum = (diskIntensity * 2.4 + topArc * 2.2 + bottomArc * 1.35 + photonRing + flare1 + flare2 + flare3) * dopplerBoost * uGlow;

  // 6. COLOR SPECTRUM WITH DOPPLER TEMPERATURE SHIFT
  // Superheated white-hot core, brilliant molten solar gold, fiery amber, and redshifted crimson
  vec3 deepCrimson = vec3(0.75, 0.12, 0.02);
  vec3 warmAmber = vec3(0.98, 0.52, 0.08);
  vec3 solarGold = vec3(1.22, 0.90, 0.28);
  vec3 whiteHotCore = vec3(1.42, 1.36, 1.25);
  vec3 blueShiftGlow = vec3(1.30, 1.40, 1.55);

  vec3 diskCol = mix(deepCrimson, warmAmber, clamp(totalLum * 0.55, 0.0, 1.0));
  diskCol = mix(diskCol, solarGold, clamp(totalLum * 0.35 - 0.28, 0.0, 1.0));
  diskCol = mix(diskCol, whiteHotCore, clamp(totalLum * 0.22 - 0.72, 0.0, 1.0));
  // Additional relativistic blue-shift on the high-intensity approaching limb
  if(pr.x < -0.15 && totalLum > 1.8){
    diskCol = mix(diskCol, blueShiftGlow, clamp((totalLum - 1.8) * 0.35, 0.0, 0.65));
  }

  // 7. DEEP-SPACE BACKDROP: CONCENTRICALLY LENSED STARFIELD & FAINT NEBULAE
  // Gravitationally warped cosmic dust & volumetric space-dust illumination
  vec2 warpedDustUV = pBent * 1.6 + vec2(T * 0.012 * uSpeed, T * 0.006 * uSpeed);
  float cosmicDust = fbm(warpedDustUV * 2.5 + fbm(warpedDustUV * 5.0)) * 0.34;
  vec3 bgHaze = vec3(0.15, 0.05, 0.02) * cosmicDust + vec3(0.003, 0.002, 0.005);

  // Faint swirling deep-space nebula clouds in violet and amber
  float nebFbm = fbm(pBent * 1.2 + vec2(0.3, -0.4));
  vec3 nebCol = mix(vec3(0.04, 0.02, 0.08), vec3(0.08, 0.03, 0.02), nebFbm);
  bgHaze += nebCol * (0.4 + 0.3 * sin(T * 0.1));

  // Concentrically lensed background stars: subtle optical pinpricks with gentle Einstein arc deflection
  vec2 starUV = pBent * 68.0;
  vec2 starCell = floor(starUV);
  vec2 starFrac = fract(starUV) - 0.5;
  vec2 starOffset = (h22(starCell + 3.1) - 0.5) * 0.7;
  float starDist = length(starFrac - starOffset);
  float starRand = h21(starCell);
  if(starRand > 0.86 && r > r_s * 1.05){
    float starPoint = smoothstep(0.12, 0.0, starDist);
    float starTwinkle = 0.55 + 0.45 * sin(T * 1.8 + starRand * 40.0);
    vec3 starColor = mix(vec3(0.85, 0.92, 1.0), vec3(1.0, 0.92, 0.80), fract(starRand * 13.0));
    bgHaze += starColor * starPoint * starTwinkle * 0.42;
  }

  // Interstellar Exploration Probe (Endurance in outer orbit with soft beacon)
  float probeAngle = mod(T * 0.38 * uSpeed + 1.2, 6.28318);
  vec2 probePos = vec2(cos(probeAngle) * 1.82, sin(probeAngle) * 0.94);
  vec2 probeDiff = pr - probePos;
  float probeDist = length(probeDiff);
  if(probeDist < 0.032){
    vec3 probeCol = vec3(0.95, 1.0, 1.1);
    float beacon = pow(max(sin(T * 5.0), 0.0), 8.0) * 1.2;
    probeCol += vec3(0.2, 0.65, 0.95) * beacon;
    bgHaze = mix(bgHaze, probeCol, smoothstep(0.032, 0.008, probeDist) * 0.65);
  }

  // Composite Accretion Disk, Plasma Filaments, and Deep Space
  vec3 finalColor = bgHaze + diskCol * totalLum;

  // Razor-sharp knife-edge shadow cutoff at the event horizon
  float shadowCutoff = smoothstep(r_s * 0.935, r_s * 0.985, r);
  finalColor *= shadowCutoff;

  // 8. 8K ACES FILMIC TONE MAPPING & CINEMATIC GAMMA
  // Rich deep black levels and specular white core without blown-out filaments
  finalColor = clamp((finalColor * (2.51 * finalColor + 0.03)) / (finalColor * (2.43 * finalColor + 0.59) + 0.14), 0.0, 1.0);
  finalColor = pow(finalColor, vec3(0.4545));
  finalColor *= 1.0 - 0.22 * dot(uv * 0.5, uv * 0.5);

  gl_FragColor = vec4(finalColor, 1.0);
}
`;

export const CosmicBlackHole: React.FC<CosmicBlackHoleProps> = memo(({
  enabled = true,
  speed = 'slow',
  lowPowerMode = false,
  relativitySlide = 1.0
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const slideRef = useRef(relativitySlide);

  const ctrlRef = useRef({
    enabled,
    speed,
    lowPower: lowPowerMode
  });

  // Inertial physics controller tying black hole rotation, glow, and suction to user interaction
  const physicsRef = useRef({
    activityEnergy: 0,
    pull: 1.0,
    glow: 1.0,
    speedFactor: 1.0
  });

  useEffect(() => {
    slideRef.current = relativitySlide;
  }, [relativitySlide]);

  useEffect(() => {
    ctrlRef.current.enabled = enabled;
    ctrlRef.current.speed = speed;
    ctrlRef.current.lowPower = lowPowerMode;
  }, [enabled, speed, lowPowerMode]);

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;

    const gopt: WebGLContextAttributes = {
      antialias: false,
      alpha: true,
      depth: false,
      stencil: false,
      preserveDrawingBuffer: false,
      powerPreference: 'default'
    };

    let gl: WebGLRenderingContext | null = null;
    try {
      gl = (cv.getContext('webgl2', gopt) ||
        cv.getContext('webgl', gopt) ||
        cv.getContext('experimental-webgl', gopt)) as any;
    } catch {}

    if (!gl) return;

    function createShader(type: number, src: string) {
      const s = gl!.createShader(type);
      if (!s) return null;
      gl!.shaderSource(s, src);
      gl!.compileShader(s);
      if (!gl!.getShaderParameter(s, gl!.COMPILE_STATUS)) {
        console.error('[CosmicBlackHole] Shader compile error:', gl!.getShaderInfoLog(s));
        gl!.deleteShader(s);
        return null;
      }
      return s;
    }

    const vs = createShader(gl.VERTEX_SHADER, BLACKHOLE_VS);
    const fs = createShader(gl.FRAGMENT_SHADER, BLACKHOLE_FS);
    if (!vs || !fs) return;

    const prog = gl.createProgram();
    if (!prog) return;

    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.bindAttribLocation(prog, 0, 'a');
    gl.linkProgram(prog);

    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      console.error('[CosmicBlackHole] Program link error:', gl.getProgramInfoLog(prog));
      gl.deleteProgram(prog);
      return;
    }

    const uR = gl.getUniformLocation(prog, 'R');
    const uT = gl.getUniformLocation(prog, 'T');
    const uSpd = gl.getUniformLocation(prog, 'uSpeed');
    const uGlowLoc = gl.getUniformLocation(prog, 'uGlow');
    const uPullLoc = gl.getUniformLocation(prog, 'uPull');
    const uLowQ = gl.getUniformLocation(prog, 'uLowQ');

    const quadBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);

    let W = 0;
    let H = 0;

    function resize() {
      if (!cv || !gl) return;
      const isMobile = /Mobi|Android/i.test(navigator.userAgent);
      const isLow = ctrlRef.current.lowPower;
      const dprCap = isLow ? 0.65 : (isMobile ? 1.25 : 1.75);
      const d = Math.min(window.devicePixelRatio || 1, dprCap);

      const rect = cv.getBoundingClientRect();
      const clientW = rect.width || window.innerWidth || 800;
      const clientH = rect.height || window.innerHeight || 600;

      const w = Math.max(32, Math.floor(clientW * d));
      const h = Math.max(32, Math.floor(clientH * d));

      if (w !== W || h !== H) {
        W = cv.width = w;
        H = cv.height = h;
        gl.viewport(0, 0, W, H);
      }
    }

    // Interactive event listeners: scroll, pointer/touch drag, and device gyroscope
    let lastScrollY = typeof window !== 'undefined' ? window.scrollY : 0;
    let lastTouchX = 0;
    let lastTouchY = 0;
    let lastGamma = 0;
    let lastBeta = 0;

    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      const delta = Math.abs(currentScrollY - lastScrollY);
      lastScrollY = currentScrollY;
      const impulse = Math.min(delta * 0.035, 1.5);
      physicsRef.current.activityEnergy = Math.min(physicsRef.current.activityEnergy + impulse, 3.5);
    };

    const handlePointerMove = (e: PointerEvent) => {
      if (e.buttons > 0) {
        const dx = e.clientX - lastTouchX;
        const dy = e.clientY - lastTouchY;
        const dist = Math.hypot(dx, dy);
        const impulse = Math.min(dist * 0.02, 1.2);
        physicsRef.current.activityEnergy = Math.min(physicsRef.current.activityEnergy + impulse, 3.5);
      }
      lastTouchX = e.clientX;
      lastTouchY = e.clientY;
    };

    const handleOrientation = (e: DeviceOrientationEvent) => {
      if (e.gamma !== null && e.beta !== null) {
        const dg = Math.abs(e.gamma - lastGamma);
        const db = Math.abs(e.beta - lastBeta);
        lastGamma = e.gamma;
        lastBeta = e.beta;
        // Ignore sudden 90-degree device flips (portrait to landscape rotation)
        if (dg > 25.0 || db > 25.0) {
          return;
        }
        const impulse = Math.min((dg + db) * 0.02, 0.4);
        physicsRef.current.activityEnergy = Math.min(physicsRef.current.activityEnergy + impulse, 1.8);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    if (typeof window.DeviceOrientationEvent !== 'undefined') {
      window.addEventListener('deviceorientation', handleOrientation, { passive: true });
    }

    let T = 0;
    let last = performance.now();
    let animId: number | null = null;
    let isDestroyed = false;

    function frame(now: number) {
      if (isDestroyed) return;
      animId = requestAnimationFrame(frame);

      const dtr = Math.min(Math.max(now - last, 1), 100);
      last = now;

      if (document.hidden || !ctrlRef.current.enabled) {
        return;
      }

      // Smooth physics integration
      const energy = physicsRef.current.activityEnergy;
      physicsRef.current.activityEnergy *= 0.92; // exponential damping

      const slideMult = slideRef.current;
      const targetPull = (1.0 + energy * 0.45) * (0.8 + slideMult * 0.25);
      const targetGlow = (1.0 + energy * 0.40) * (0.85 + slideMult * 0.2);
      const targetSpeedFactor = (1.0 + energy * 0.55) * slideMult;

      physicsRef.current.pull += (targetPull - physicsRef.current.pull) * 0.12;
      physicsRef.current.glow += (targetGlow - physicsRef.current.glow) * 0.12;
      physicsRef.current.speedFactor += (targetSpeedFactor - physicsRef.current.speedFactor) * 0.12;

      const spd = ctrlRef.current.speed;
      const baseSpeed = spd === 'fast' ? 1.4 : spd === 'medium' ? 1.0 : 0.85;
      const dynamicSpeed = baseSpeed * physicsRef.current.speedFactor;
      const dt = (dtr / 1000) * dynamicSpeed;
      T = (T + dt) % 4000;

      resize();

      gl!.useProgram(prog);
      gl!.uniform2f(uR, W, H);
      gl!.uniform1f(uT, T);
      gl!.uniform1f(uSpd, dynamicSpeed);
      gl!.uniform1f(uGlowLoc, physicsRef.current.glow);
      gl!.uniform1f(uPullLoc, physicsRef.current.pull);
      gl!.uniform1f(uLowQ, ctrlRef.current.lowPower ? 1.0 : 0.0);

      gl!.bindBuffer(gl!.ARRAY_BUFFER, quadBuf);
      gl!.enableVertexAttribArray(0);
      gl!.vertexAttribPointer(0, 2, gl!.FLOAT, false, 0, 0);

      gl!.drawArrays(gl!.TRIANGLES, 0, 3);
    }

    const handleResize = () => {
      resize();
    };

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => handleResize());
      ro.observe(cv);
    }

    window.addEventListener('resize', handleResize, { passive: true });
    resize();
    animId = requestAnimationFrame(frame);

    return () => {
      isDestroyed = true;
      if (animId !== null) cancelAnimationFrame(animId);
      if (ro) ro.disconnect();
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('pointermove', handlePointerMove);
      if (typeof window.DeviceOrientationEvent !== 'undefined') {
        window.removeEventListener('deviceorientation', handleOrientation);
      }

      try {
        if (quadBuf) gl!.deleteBuffer(quadBuf);
        if (prog) gl!.deleteProgram(prog);
        if (vs) gl!.deleteShader(vs);
        if (fs) gl!.deleteShader(fs);
      } catch {}
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full block pointer-events-none select-none z-0"
      style={{
        filter: 'none',
        backdropFilter: 'none',
        width: '100%',
        height: '100%'
      }}
      aria-hidden="true"
    />
  );
});
