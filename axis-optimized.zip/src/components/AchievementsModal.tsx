import React from 'react';
import { AxisState } from '../types';
import { Award, Zap, Shield, Sparkles } from 'lucide-react';

interface AchievementsModalProps {
  state: AxisState;
  level: number;
  levelMultiplier: number;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  state,
  level,
  levelMultiplier
}) => {
  const BADGES = [
    { id: 'first_scan', title: 'Pioneer Miner', desc: 'Scan your first CPG product', icon: '🌱' },
    { id: 'ten_scans', title: 'Consistent Scanner', desc: 'Complete 10 total barcode scans', icon: '⭐' },
    { id: 'staker', title: 'Vault Contributor', desc: 'Lock FLRX into high-yield staking', icon: '🔒' },
    { id: 'trader', title: 'Market Maker', desc: 'Execute an instant swap on the DEX', icon: '📈' },
    { id: 'streak_7', title: 'Week Warrior', desc: 'Maintain a 7-day active scan streak', icon: '🔥' }
  ];

  return (
    <div className="space-y-4 select-none">
      {/* Level & XP Overview */}
      <div className="p-4 rounded-2xl neu-flat text-center space-y-2">
        <div className="w-14 h-14 mx-auto rounded-2xl neu-inset flex items-center justify-center text-emerald-600">
          <Award className="w-8 h-8" />
        </div>
        <h3 className="font-extrabold text-base text-[var(--ink)]">
          Miner Level {level}
        </h3>
        <p className="text-xs text-[var(--ink2)] font-mono">
          Current Mining Multiplier: {levelMultiplier.toFixed(2)}x
        </p>
      </div>

      <div className="space-y-2">
        <h4 className="text-xs font-extrabold uppercase tracking-wider text-[var(--ink2)]">
          Badges &amp; Milestones
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 landscape:grid-cols-2 gap-2">
          {BADGES.map((b) => {
            const unlocked = (state.ach?.[b.id] || 0) > 0 || (b.id === 'first_scan' && state.totalScans > 0) || (b.id === 'ten_scans' && state.totalScans >= 10);

            return (
              <div
                key={b.id}
                className={`p-3.5 rounded-2xl flex items-center justify-between gap-3 ${
                  unlocked ? 'neu-flat' : 'neu-inset opacity-60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl neu-inset flex items-center justify-center text-xl shrink-0">
                    {b.icon}
                  </div>
                  <div>
                    <b className="text-xs font-bold block text-[var(--ink)]">{b.title}</b>
                    <span className="text-[10px] text-[var(--ink2)]">{b.desc}</span>
                  </div>
                </div>

                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${unlocked ? 'neu-tab-active' : 'neu-inset text-[var(--ink2)]'}`}>
                  {unlocked ? 'Unlocked' : 'Locked'}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
