import React from 'react';
import { AxisState } from '../types';
import { COMPANIES } from '../constants';
import { fmtF, dt } from '../utils';

interface HistoryModalProps {
  state: AxisState;
  onSyncQueue: () => void;
  onOpenScanner: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  state,
  onSyncQueue,
  onOpenScanner
}) => {
  return (
    <div className="space-y-4 select-none">
      {/* Offline Queue Notice - Neumorphic Alert Plate */}
      {state.queue.length > 0 && (
        <div className="p-4 rounded-2xl neu-flat flex items-center justify-between gap-3">
          <div>
            <b className="text-xs sm:text-sm font-extrabold text-[var(--ink)] block">
              {state.queue.length} Offline Scan(s) Queued
            </b>
            <small className="text-[11px] text-[var(--ink2)]">
              Scans were saved while offline and will award FLRX once synced.
            </small>
          </div>
          <button
            onClick={onSyncQueue}
            className="px-3.5 py-2 rounded-xl neu-btn-accent bg-amber-500 hover:bg-amber-600 text-black font-extrabold text-xs shadow-xs transition shrink-0 cursor-pointer"
          >
            Sync Now
          </button>
        </div>
      )}

      {/* History List - Neumorphic Extruded Card */}
      <div className="p-4 rounded-2xl neu-flat space-y-3">
        <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
          Scan History ({state.history.length})
        </h4>

        {state.history.length === 0 ? (
          <div className="text-center py-8 space-y-3">
            <p className="text-xs text-[var(--ink2)] max-w-xs mx-auto">
              You haven't scanned any product barcodes yet. Scan your first item to start earning FLRX.
            </p>
            <button
              onClick={onOpenScanner}
              className="py-2.5 px-6 rounded-xl neu-btn-accent font-bold text-xs shadow-xs transition cursor-pointer"
            >
              Open Mining Scanner
            </button>
          </div>
        ) : (
          <div className="space-y-2 max-h-[440px] overflow-y-auto pr-1">
            {state.history.map((h) => {
              const comp = COMPANIES.find((c) => c.id === h.company);
              const compIcon = (comp as any)?.icon || (comp as any)?.banner?.slice(0, 2) || '📦';
              const compName = comp?.name || h.company;

              return (
                <div
                  key={h.id}
                  className="p-3 rounded-xl neu-flat-sm flex items-center justify-between gap-2.5 text-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 rounded-lg neu-inset flex items-center justify-center text-xl shrink-0">
                      {compIcon}
                    </div>
                    <div className="min-w-0">
                      <b className="text-[var(--ink)] block truncate font-bold">
                        {h.product}
                      </b>
                      <small className="text-[10px] text-[var(--ink2)] font-mono block">
                        {compName} · {dt(h.ts)}
                        {h.blockIndex ? ` · ${h.blockIndex}` : ''}
                        {h.nodesConfirmed ? ` · ${h.nodesConfirmed.toLocaleString()} nodes` : ''}
                        {h.sp > 1 ? ' · 2× Bonus' : ''}
                        {h.first > 0 ? ' · First Scan' : ''}
                      </small>
                    </div>
                  </div>

                  <div className="text-right shrink-0 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    <div>+{fmtF(h.reward + (h.first || 0))} FLRX</div>
                    {typeof h.phpReward === 'number' && (
                      <div className="text-[9px] text-[var(--ink2)] font-normal">
                        ₱{h.phpReward.toFixed(2)} (51%)
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
