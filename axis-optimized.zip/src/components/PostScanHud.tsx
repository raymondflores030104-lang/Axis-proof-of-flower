import React from 'react';
import { Sparkles, CheckCircle2 } from 'lucide-react';

export interface PendingScanItem {
  id?: string;
  code: string;
  ts?: number;
  timestamp?: number;
  expireTs?: number;
  rewardFlrx?: number;
  flrxReward?: number;
  company?: string;
  product?: string;
  productName?: string;
  phpValue?: number;
  tier?: number;
  verified: boolean;
}

interface PostScanHudProps {
  pendingScans: PendingScanItem[];
  onVerifyComplete: (codeOrId: string) => void;
  onOpenDetails: () => void;
  isLandscape?: boolean;
}

export const PostScanHud: React.FC<PostScanHudProps> = ({
  pendingScans,
  onVerifyComplete,
  onOpenDetails,
  isLandscape = false
}) => {
  if (!pendingScans || pendingScans.length === 0) {
    return (
      <div
        data-zone="activity"
        className={`rounded-2xl neu-flat flex items-center justify-between gap-2 text-xs select-none w-full overflow-hidden ${
          isLandscape
            ? 'p-2 sm:p-2.5 h-full'
            : 'mb-3.5 p-3 h-[70px]'
        }`}
      >
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <div className="w-8 h-8 rounded-xl neu-inset text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-emerald-500 animate-pulse" />
          </div>
          <div className="min-w-0 text-left flex-1">
            <b className="block text-[var(--ink)] font-extrabold text-[10.5px] sm:text-xs leading-snug truncate">
              PoF Consensus Network
            </b>
            <span className="text-[8.5px] sm:text-[9.5px] text-[var(--ink2)] font-mono block leading-tight mt-0.5 truncate">
              Node Quorum 100% · Active
            </span>
          </div>
        </div>
        <button
          onClick={onOpenDetails}
          className="px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl neu-tab-item text-[10px] sm:text-[11px] font-bold shrink-0 cursor-pointer hover:text-[var(--accent)] active:scale-95 transition-all"
        >
          History
        </button>
      </div>
    );
  }

  const latest = pendingScans[0];
  const prodName = latest.product || latest.productName || 'Verified Product';
  const compName = latest.company ? ` (${latest.company})` : '';
  const reward = latest.flrxReward ?? latest.rewardFlrx ?? 0.001;

  return (
    <div
      data-zone="activity"
      className={`rounded-2xl neu-flat flex items-center justify-between gap-2 text-xs select-none w-full overflow-hidden ${
        isLandscape
          ? 'p-2 sm:p-2.5 h-full'
          : 'mb-3.5 p-3 h-[70px]'
      }`}
    >
      <div className="flex items-center gap-2 min-w-0 flex-1">
        <div className="w-8 h-8 rounded-xl neu-inset text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
          <Sparkles className="w-4 h-4 text-emerald-500 animate-pulse" />
        </div>
        <div className="min-w-0 text-left flex-1">
          <b className="block text-[var(--ink)] font-extrabold text-[10.5px] sm:text-xs leading-snug truncate">
            {prodName}{compName}
          </b>
          <span className="text-[8.5px] sm:text-[9.5px] text-[var(--ink2)] font-mono block leading-tight mt-0.5 truncate">
            +{reward < 0.01 ? reward.toFixed(8) : reward.toFixed(4)} FLWRX{latest.phpValue ? ` · ₱${latest.phpValue.toFixed(2)}` : ''}
          </span>
        </div>
      </div>
      <button
        onClick={onOpenDetails}
        className="px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl neu-tab-item text-[10px] sm:text-[11px] font-bold shrink-0 cursor-pointer hover:text-[var(--accent)] active:scale-95 transition-all"
      >
        History
      </button>
    </div>
  );
};
