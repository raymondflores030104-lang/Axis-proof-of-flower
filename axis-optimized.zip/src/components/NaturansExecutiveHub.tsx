import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import {
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  Layers,
  ArrowRight,
  RefreshCw,
  Cpu,
  Building2,
  CheckCircle2,
  Sparkles,
  Zap,
  Globe2,
  Lock,
  Compass,
  Play,
  Pause,
  RotateCcw,
  Sliders,
  ChevronRight,
  Maximize2
} from 'lucide-react';

/* =========================================================================
   NATURANS EXECUTIVE HUB & CORPORATION ARCHITECTURE 3D ENGINE
   
   Production WebGL & Canvas Interactive Architecture:
   1. Real-Time 3D Chess Ledger & PGN Vector-to-QR Encryption Pipeline
   2. 400-Move Kinematic Trajectory Equations (Bold, Striking Vector Paths)
   3. Enhanced Market DCA Candlestick Component (High-Visibility Dynamic Scaling)
   4. Manufacturer Code-Depletion & Executive Multi-Sig Approval Simulation
   5. Global Ecological Impact & Post-Consumer Waste Narrative with Aesthetic Shift
   6. 100dvh Contextual Responsive Viewport & Landscape Orientation Matrix
   ========================================================================= */

interface NaturansExecutiveHubProps {
  onClose?: () => void;
  onToast?: (msg: string, type?: 'good' | 'err') => void;
  currentCurrency?: string;
  currencyRate?: number;
  currencySymbol?: string;
}

export type HubTab = 'architecture' | 'market_dca' | 'b2b_simulation' | 'chess_vectors' | 'ecological_impact';

// Algebraic PGN Move Sequence for Ledger Simulation
const PGN_SEQUENCES = [
  { move: '1. e4', from: [4, 1], to: [4, 3], piece: 'P', hash: '8f4c2e109d3b5a77', qrPayload: 'FLWRX-PASSKEY-NODE01-e2e4' },
  { move: '1... e5', from: [4, 6], to: [4, 4], piece: 'p', hash: '3a1f8b90c4d2e566', qrPayload: 'FLWRX-PASSKEY-NODE02-e7e5' },
  { move: '2. Nf3', from: [6, 0], to: [5, 2], piece: 'N', hash: '5c7e1a39d8b02f44', qrPayload: 'FLWRX-PASSKEY-NODE03-g1f3' },
  { move: '2... Nc6', from: [1, 7], to: [2, 5], piece: 'n', hash: '9b2d4f61e8a03c55', qrPayload: 'FLWRX-PASSKEY-NODE04-b8c6' },
  { move: '3. Bb5', from: [5, 0], to: [1, 4], piece: 'B', hash: '7e0a3c58b9f12d88', qrPayload: 'FLWRX-PASSKEY-NODE05-f1b5' },
  { move: '3... a6', from: [0, 6], to: [0, 5], piece: 'p', hash: '1d4b6a82e0c93f77', qrPayload: 'FLWRX-PASSKEY-NODE06-a7a6' },
  { move: '4. Ba4', from: [1, 4], to: [0, 3], piece: 'B', hash: '4f8c1e30a7b52d99', qrPayload: 'FLWRX-PASSKEY-NODE07-b5a4' },
  { move: '4... Nf6', from: [6, 7], to: [5, 5], piece: 'n', hash: '6a0c2e49f8b13d55', qrPayload: 'FLWRX-PASSKEY-NODE08-g8f6' },
  { move: '5. O-O', from: [4, 0], to: [6, 0], piece: 'K', hash: '2e9b4a70c1d85f33', qrPayload: 'FLWRX-PASSKEY-NODE09-e1g1' }
];

// 400 Possible Opening Move Vectors Data Archetypes (20 White x 20 Black)
const FIRST_MOVE_TARGETS = [
  // 16 pawn moves: 8 pawns x 2 squares each (single or double push)
  { from: 'a2', to: 'a3', type: 'pawn' }, { from: 'a2', to: 'a4', type: 'pawn' },
  { from: 'b2', to: 'b3', type: 'pawn' }, { from: 'b2', to: 'b4', type: 'pawn' },
  { from: 'c2', to: 'c3', type: 'pawn' }, { from: 'c2', to: 'c4', type: 'pawn' },
  { from: 'd2', to: 'd3', type: 'pawn' }, { from: 'd2', to: 'd4', type: 'pawn' },
  { from: 'e2', to: 'e3', type: 'pawn' }, { from: 'e2', to: 'e4', type: 'pawn' },
  { from: 'f2', to: 'f3', type: 'pawn' }, { from: 'f2', to: 'f4', type: 'pawn' },
  { from: 'g2', to: 'g3', type: 'pawn' }, { from: 'g2', to: 'g4', type: 'pawn' },
  { from: 'h2', to: 'h3', type: 'pawn' }, { from: 'h2', to: 'h4', type: 'pawn' },
  // 4 knight moves: 2 knights x 2 squares each
  { from: 'b1', to: 'a3', type: 'knight' }, { from: 'b1', to: 'c3', type: 'knight' },
  { from: 'g1', to: 'f3', type: 'knight' }, { from: 'g1', to: 'h3', type: 'knight' }
];

export const NaturansExecutiveHub: React.FC<NaturansExecutiveHubProps> = ({
  onClose,
  onToast,
  currentCurrency = 'PHP',
  currencyRate = 58.5,
  currencySymbol = '₱'
}) => {
  const [activeTab, setActiveTab] = useState<HubTab>('architecture');
  const [isSimulatingMove, setIsSimulatingMove] = useState(true);
  const [currentMoveIdx, setCurrentMoveIdx] = useState(0);
  const [vectorSpeed, setVectorSpeed] = useState(1.2);
  const [vectorIntensity, setVectorIntensity] = useState(1.0);
  
  // B2B Simulation States (Plant-04 -> Executive Hub)
  const [plantPool, setPlantPool] = useState(480); // Under 500 threshold
  const [maxPlantPool] = useState(25000);
  const [b2bStep, setB2bStep] = useState<'IDLE' | 'ALERT_TRIGGERED' | 'PACKET_TRANSIT' | 'EXECUTIVE_REVIEW' | 'REPLENISHED'>('ALERT_TRIGGERED');
  const [packetProgress, setPacketProgress] = useState(0);
  const [councilApprovals, setCouncilApprovals] = useState([true, true, true, false, false, false]); // 3 of 4 needed
  const [autoReplenishLoop, setAutoReplenishLoop] = useState(true);

  // Candlestick DCA Simulation Data with High-Visibility Scaling
  const [timeframe, setTimeframe] = useState<'1H' | '1D' | '1W' | '1Y'>('1D');
  const [accumulationGlow, setAccumulationGlow] = useState(true);

  // Canvas Refs
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(Date.now());

  // Handle B2B Simulation Cycle
  useEffect(() => {
    if (!autoReplenishLoop) return;

    const timer = setInterval(() => {
      setB2bStep((prev) => {
        if (prev === 'IDLE') {
          setPlantPool(420);
          return 'ALERT_TRIGGERED';
        }
        if (prev === 'ALERT_TRIGGERED') {
          return 'PACKET_TRANSIT';
        }
        if (prev === 'PACKET_TRANSIT') {
          setCouncilApprovals([true, true, true, true, false, false]); // 4-of-6 Quorum achieved!
          return 'EXECUTIVE_REVIEW';
        }
        if (prev === 'EXECUTIVE_REVIEW') {
          setPlantPool(maxPlantPool);
          return 'REPLENISHED';
        }
        if (prev === 'REPLENISHED') {
          return 'IDLE';
        }
        return 'IDLE';
      });
    }, 3200);

    return () => clearInterval(timer);
  }, [autoReplenishLoop, maxPlantPool]);

  // Handle Packet Progress Animation
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (b2bStep === 'PACKET_TRANSIT') {
      setPacketProgress(0);
      interval = setInterval(() => {
        setPacketProgress((p) => {
          if (p >= 100) {
            clearInterval(interval);
            return 100;
          }
          return p + 5;
        });
      }, 50);
    }
    return () => clearInterval(interval);
  }, [b2bStep]);

  // Main Canvas Render Loop (3D Chess Ledger, Bold 400 Move Vectors & Ecological Impact)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let isRunning = true;

    // Resize Handler with DPR clamp and orientation protection
    const handleResize = () => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const targetW = Math.max(300, Math.floor(rect.width * dpr));
      const targetH = Math.max(220, Math.floor(rect.height * dpr));

      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    // Render loop
    const render = () => {
      if (!isRunning || !canvas) return;
      const width = canvas.width;
      const height = canvas.height;
      const now = (Date.now() - startTimeRef.current) * 0.001 * vectorSpeed;

      // Clear frame
      ctx.clearRect(0, 0, width, height);

      // -------------------------------------------------------------
      // TAB 1 & 4: 3D CHESS LEDGER & 400 BOLD MOVE VECTORS (REAL-TIME MATH)
      // -------------------------------------------------------------
      if (activeTab === 'architecture' || activeTab === 'chess_vectors') {
        const cx = width * 0.5;
        const cy = height * 0.56;
        const boardSize = Math.min(width, height) * 0.44;
        const tileSize = boardSize / 8;

        // Isometric 3D Projection Matrices
        const cosAngle = Math.cos(Math.PI / 6);
        const sinAngle = Math.sin(Math.PI / 7);
        const elevation = 0.52;

        const toIso = (bx: number, by: number, z: number = 0) => {
          const px = (bx - 4) * tileSize;
          const py = (by - 4) * tileSize;
          const isoX = cx + (px - py) * cosAngle;
          const isoY = cy + (px + py) * sinAngle * elevation - z;
          return { x: isoX, y: isoY };
        };

        // Draw 3D Isometric Board Base & Ambient Shading
        ctx.save();

        // 3D Plinth Depth
        ctx.fillStyle = 'rgba(8, 22, 14, 0.75)';
        ctx.beginPath();
        const pTL = toIso(0, 0, 0);
        const pTR = toIso(8, 0, 0);
        const pBR = toIso(8, 8, 0);
        const pBL = toIso(0, 8, 0);
        const pBL_deep = toIso(0, 8, -18);
        const pBR_deep = toIso(8, 8, -18);
        const pTR_deep = toIso(8, 0, -18);

        ctx.moveTo(pBL.x, pBL.y);
        ctx.lineTo(pBR.x, pBR.y);
        ctx.lineTo(pBR_deep.x, pBR_deep.y);
        ctx.lineTo(pBL_deep.x, pBL_deep.y);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = 'rgba(5, 14, 9, 0.9)';
        ctx.beginPath();
        ctx.moveTo(pBR.x, pBR.y);
        ctx.lineTo(pTR.x, pTR.y);
        ctx.lineTo(pTR_deep.x, pTR_deep.y);
        ctx.lineTo(pBR_deep.x, pBR_deep.y);
        ctx.closePath();
        ctx.fill();

        // Render 64 Tiles with Ambient Lighting & Gradient
        for (let r = 0; r < 8; r++) {
          for (let c = 0; c < 8; c++) {
            const isLight = (r + c) % 2 === 0;
            const t0 = toIso(c, r);
            const t1 = toIso(c + 1, r);
            const t2 = toIso(c + 1, r + 1);
            const t3 = toIso(c, r + 1);

            ctx.beginPath();
            ctx.moveTo(t0.x, t0.y);
            ctx.lineTo(t1.x, t1.y);
            ctx.lineTo(t2.x, t2.y);
            ctx.lineTo(t3.x, t3.y);
            ctx.closePath();

            // Neumorphic Green / Obsidian Theme
            if (isLight) {
              ctx.fillStyle = 'rgba(168, 230, 185, 0.28)';
              ctx.strokeStyle = 'rgba(110, 214, 138, 0.5)';
            } else {
              ctx.fillStyle = 'rgba(16, 52, 28, 0.65)';
              ctx.strokeStyle = 'rgba(30, 80, 48, 0.7)';
            }
            ctx.lineWidth = 1;
            ctx.fill();
            ctx.stroke();
          }
        }

        // =========================================================
        // 400 EXPONENTIAL MOVE VECTORS (BOLD, HIGH-VISIBILITY KINEMATIC MATH)
        // Formula: Bold oscillating trajectory snapping from origin to 400 squares
        // =========================================================
        const numActiveVectors = activeTab === 'chess_vectors' ? 24 : 8;
        for (let v = 0; v < numActiveVectors; v++) {
          const moveData = FIRST_MOVE_TARGETS[v % FIRST_MOVE_TARGETS.length];
          const colFrom = moveData.from.charCodeAt(0) - 97 + 0.5;
          const rowFrom = parseInt(moveData.from[1]) - 1 + 0.5;
          const colTo = moveData.to.charCodeAt(0) - 97 + 0.5;
          const rowTo = parseInt(moveData.to[1]) - 1 + 0.5;

          const pStart = toIso(colFrom, rowFrom, 4);
          const pEnd = toIso(colTo, rowTo, 4);

          // Kinematic Arc Math: Cubic Smoothstep + High-Amplitude Sine Oscillation
          const cycleTime = (now * 1.4 + v * 0.32) % 2.0;
          const tProgress = Math.min(1.0, cycleTime / 1.5);
          const smoothT = tProgress * tProgress * (3 - 2 * tProgress);

          // Bold Trajectory Path
          ctx.beginPath();
          ctx.moveTo(pStart.x, pStart.y);

          const midX = (pStart.x + pEnd.x) * 0.5;
          const midY = (pStart.y + pEnd.y) * 0.5 - 34 - Math.sin(now * 3.5 + v) * 8 * vectorIntensity;

          ctx.quadraticCurveTo(midX, midY, pEnd.x, pEnd.y);

          // High-visibility neon emerald / electric cyan stroke with intense amplitude
          const grad = ctx.createLinearGradient(pStart.x, pStart.y, pEnd.x, pEnd.y);
          grad.addColorStop(0, 'rgba(0, 255, 136, 0.95)');
          grad.addColorStop(0.5, 'rgba(0, 229, 255, 0.9)');
          grad.addColorStop(1, 'rgba(16, 185, 129, 0.95)');

          ctx.strokeStyle = grad;
          ctx.lineWidth = (3.2 + Math.sin(now * 4 + v) * 0.8) * vectorIntensity;
          ctx.lineCap = 'round';
          ctx.shadowColor = 'rgba(0, 255, 136, 0.6)';
          ctx.shadowBlur = 12 * vectorIntensity;
          ctx.stroke();
          ctx.shadowBlur = 0; // reset

          // Animated Vector Head Packet
          const packetX = (1 - smoothT) * (1 - smoothT) * pStart.x + 2 * (1 - smoothT) * smoothT * midX + smoothT * smoothT * pEnd.x;
          const packetY = (1 - smoothT) * (1 - smoothT) * pStart.y + 2 * (1 - smoothT) * smoothT * midY + smoothT * smoothT * pEnd.y;

          ctx.fillStyle = '#FFFFFF';
          ctx.beginPath();
          ctx.arc(packetX, packetY, 4.5 * vectorIntensity, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = 'rgba(0, 255, 136, 0.45)';
          ctx.beginPath();
          ctx.arc(packetX, packetY, 9 * vectorIntensity, 0, Math.PI * 2);
          ctx.fill();
        }

        // Animated PGN Move Transformation to QR Matrix Stream
        const activeMove = PGN_SEQUENCES[currentMoveIdx % PGN_SEQUENCES.length];
        const pgnOrigin = toIso(activeMove.from[0] + 0.5, activeMove.from[1] + 0.5, 6);
        const pgnTarget = toIso(activeMove.to[0] + 0.5, activeMove.to[1] + 0.5, 6);

        // Origin Glow Ring
        ctx.strokeStyle = 'rgba(250, 204, 21, 0.9)';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(pgnOrigin.x, pgnOrigin.y, 14 + Math.sin(now * 5) * 3, 0, Math.PI * 2);
        ctx.stroke();

        // Target Landing Ring
        ctx.strokeStyle = 'rgba(0, 255, 136, 0.95)';
        ctx.beginPath();
        ctx.arc(pgnTarget.x, pgnTarget.y, 16 + Math.cos(now * 5) * 3, 0, Math.PI * 2);
        ctx.stroke();

        // Encrypted QR Matrix Teleportation Stream (Vertical Data Column)
        const qrStreamX = pgnTarget.x;
        const qrStreamY = pgnTarget.y;
        for (let q = 0; q < 7; q++) {
          const bitY = qrStreamY - 20 - q * 10 - ((now * 35) % 15);
          const bitVal = ((q + Math.floor(now * 6)) % 2 === 0);
          ctx.fillStyle = bitVal ? 'rgba(0, 255, 136, 0.85)' : 'rgba(255, 255, 255, 0.6)';
          ctx.fillRect(qrStreamX - 4 + ((q % 3) - 1) * 6, bitY, 4.5, 4.5);
        }

        ctx.restore();
      }

      // -------------------------------------------------------------
      // TAB 2: ENHANCED MARKET DCA CANDLESTICK (HIGH-VISIBILITY DYNAMIC SCALING)
      // -------------------------------------------------------------
      else if (activeTab === 'market_dca') {
        const paddingLeft = 45;
        const paddingRight = 20;
        const paddingTop = 28;
        const paddingBottom = 40;
        const chartW = width - paddingLeft - paddingRight;
        const chartH = height - paddingTop - paddingBottom;

        // Synthetic 32 Candlestick bars with realistic micro-volatility
        const numBars = 30;
        const basePrice = 0.042;
        const candles: Array<{ open: number; close: number; high: number; low: number; vol: number }> = [];
        
        let runningPrice = basePrice;
        for (let i = 0; i < numBars; i++) {
          const trend = Math.sin(i * 0.28) * 0.0012 + (i > 18 ? (i - 18) * 0.0004 : 0);
          const delta = (Math.sin(i * 1.33 + now * 0.5) * 0.0006) + trend;
          const open = runningPrice;
          const close = open + delta;
          const high = Math.max(open, close) + Math.abs(Math.sin(i * 2.1)) * 0.0004;
          const low = Math.min(open, close) - Math.abs(Math.cos(i * 1.8)) * 0.0004;
          const vol = 12000 + Math.abs(Math.sin(i)) * 45000;
          candles.push({ open, close, high, low, vol });
          runningPrice = close;
        }

        // DYNAMIC AUTO-SCALING ALGORITHM (Eliminates flat horizontal compression)
        let minP = Math.min(...candles.map((c) => c.low));
        let maxP = Math.max(...candles.map((c) => c.high));
        const priceRange = Math.max(maxP - minP, 0.0002);
        // Force 15% top/bottom breathing margin to maximize dramatic amplitude
        minP -= priceRange * 0.12;
        maxP += priceRange * 0.12;
        const effectiveRange = maxP - minP;

        const getY = (val: number) => paddingTop + (1 - (val - minP) / effectiveRange) * chartH;
        const barSpacing = chartW / numBars;
        const barWidth = Math.max(3, barSpacing * 0.68);

        // Draw High-Contrast Horizontal Grid Lines
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
        ctx.lineWidth = 1;
        ctx.font = '10px monospace';
        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';

        for (let g = 0; g <= 4; g++) {
          const gridVal = minP + (g / 4) * effectiveRange;
          const gy = getY(gridVal);
          ctx.beginPath();
          ctx.moveTo(paddingLeft, gy);
          ctx.lineTo(width - paddingRight, gy);
          ctx.stroke();
          ctx.fillText(`$${gridVal.toFixed(4)}`, 4, gy + 3);
        }

        // Draw 365-Day Rolling Spot DCA Accumulation Zone (Soft Emerald Channel)
        if (accumulationGlow) {
          ctx.beginPath();
          for (let i = 0; i < numBars; i++) {
            const bx = paddingLeft + i * barSpacing + barWidth * 0.5;
            const by = getY(candles[i].open);
            if (i === 0) ctx.moveTo(bx, by);
            else ctx.lineTo(bx, by);
          }
          ctx.strokeStyle = 'rgba(0, 255, 136, 0.45)';
          ctx.lineWidth = 3;
          ctx.setLineDash([4, 4]);
          ctx.stroke();
          ctx.setLineDash([]);
        }

        // Render High-Visibility Neon Emerald & Deep Crimson Candlesticks
        for (let i = 0; i < numBars; i++) {
          const c = candles[i];
          const bx = paddingLeft + i * barSpacing + (barSpacing - barWidth) * 0.5;
          const centerX = bx + barWidth * 0.5;
          const isBull = c.close >= c.open;

          const yOpen = getY(c.open);
          const yClose = getY(c.close);
          const yHigh = getY(c.high);
          const yLow = getY(c.low);

          const candleTop = Math.min(yOpen, yClose);
          const candleHeight = Math.max(2, Math.abs(yClose - yOpen));

          // Wicked Line
          ctx.beginPath();
          ctx.moveTo(centerX, yHigh);
          ctx.lineTo(centerX, yLow);
          ctx.strokeStyle = isBull ? '#00FF88' : '#FF1744';
          ctx.lineWidth = 1.6;
          ctx.stroke();

          // Body with Radiant Glow
          ctx.save();
          if (isBull) {
            ctx.fillStyle = '#00FF88';
            ctx.shadowColor = 'rgba(0, 255, 136, 0.65)';
            ctx.shadowBlur = 8;
          } else {
            ctx.fillStyle = '#FF1744';
            ctx.shadowColor = 'rgba(255, 23, 68, 0.65)';
            ctx.shadowBlur = 8;
          }
          ctx.fillRect(bx, candleTop, barWidth, candleHeight);
          ctx.restore();
        }

        // Live Market Pulsing Pointer at Last Candle
        const lastCandle = candles[candles.length - 1];
        const lastX = paddingLeft + (numBars - 1) * barSpacing + barWidth * 0.5;
        const lastY = getY(lastCandle.close);

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(lastX, lastY, 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#00FF88';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(lastX, lastY, 8 + Math.sin(now * 6) * 3, 0, Math.PI * 2);
        ctx.stroke();
      }

      // -------------------------------------------------------------
      // TAB 5: VISCERAL GLOBAL ECOLOGICAL IMPACT & POST-CONSUMER WASTE NARRATIVE
      // -------------------------------------------------------------
      else if (activeTab === 'ecological_impact') {
        // Dynamic Aesthetic Shift: Raw chaotic marine pollution converting to blooming flora
        const cx = width * 0.5;
        const cy = height * 0.5;

        // Draw Toxic Muddy / Plastic Water Background Layer
        const grad = ctx.createLinearGradient(0, 0, 0, height);
        grad.addColorStop(0, '#0c1a17');
        grad.addColorStop(0.5, '#172822');
        grad.addColorStop(1, '#08120e');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        // Water Wave Oscillations with Plastic Floating Particles
        const waveY = height * 0.55;
        ctx.beginPath();
        ctx.moveTo(0, height);
        ctx.lineTo(0, waveY);

        for (let x = 0; x <= width; x += 15) {
          const dy = Math.sin(x * 0.02 + now * 1.8) * 12 + Math.cos(x * 0.04 - now * 1.2) * 6;
          ctx.lineTo(x, waveY + dy);
        }
        ctx.lineTo(width, height);
        ctx.closePath();
        ctx.fillStyle = 'rgba(20, 60, 45, 0.65)';
        ctx.fill();

        // 14 Floating Plastic Bottle / Waste Silhouettes Choking Channels
        for (let b = 0; b < 14; b++) {
          const bx = ((b * 62 + now * 25) % (width + 60)) - 30;
          const by = waveY + Math.sin(bx * 0.03 + now * 2) * 14 + (b % 4) * 16;
          const rotAngle = Math.sin(now * 1.5 + b) * 0.35;

          ctx.save();
          ctx.translate(bx, by);
          ctx.rotate(rotAngle);

          // Plastic Bottle Geometry
          ctx.fillStyle = 'rgba(220, 235, 245, 0.35)';
          ctx.strokeStyle = 'rgba(240, 248, 255, 0.6)';
          ctx.lineWidth = 1;
          ctx.fillRect(-8, -4, 16, 8);
          // Bottle Cap
          ctx.fillStyle = '#f59e0b';
          ctx.fillRect(8, -2, 3, 4);

          ctx.restore();
        }

        // Proof of Flower (PoF) Recycling Rays: Transforming Waste Into Blooming Flora
        const numFlowers = 6;
        for (let f = 0; f < numFlowers; f++) {
          const fx = width * (0.2 + f * 0.13);
          const fy = height * 0.35 + Math.sin(now * 2 + f) * 8;
          const petalCount = 6;
          const radius = 10 + Math.sin(now * 3 + f) * 2;

          // Golden-Emerald Blossom
          ctx.save();
          ctx.translate(fx, fy);
          for (let p = 0; p < petalCount; p++) {
            const angle = (p / petalCount) * Math.PI * 2 + now * 0.4;
            const px = Math.cos(angle) * radius;
            const py = Math.sin(angle) * radius;

            ctx.beginPath();
            ctx.arc(px, py, radius * 0.45, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(0, 255, 136, 0.8)';
            ctx.fill();
          }

          // Flower Center
          ctx.beginPath();
          ctx.arc(0, 0, radius * 0.35, 0, Math.PI * 2);
          ctx.fillStyle = '#FDE047';
          ctx.fill();

          ctx.restore();
        }
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      isRunning = false;
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      window.removeEventListener('resize', handleResize);
    };
  }, [activeTab, currentMoveIdx, vectorSpeed, vectorIntensity, accumulationGlow]);

  return (
    <div className="naturans-executive-hub w-full flex flex-col space-y-3 select-none text-[var(--ink)]">
      {/* 1. Header Toolbar & Context Navigation */}
      <div className="flex items-center justify-between gap-2 p-2.5 rounded-2xl neu-flat bg-gradient-to-r from-emerald-950/40 via-zinc-900/40 to-teal-950/40 border border-emerald-500/30">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-8 h-8 rounded-xl neu-inset text-emerald-400 flex items-center justify-center shrink-0">
            <Building2 className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h3 className="text-xs sm:text-sm font-extrabold uppercase tracking-wide text-white truncate">
                Naturans Executive Hub
              </h3>
              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-bold shrink-0">
                PoF Consensus
              </span>
            </div>
            <p className="text-[10px] text-zinc-400 truncate">
              Corporation Architecture &amp; Real-Time Chess-Ledger Mapping
            </p>
          </div>
        </div>

        {/* Live Ledger Status Badge */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[10px] font-mono font-bold text-emerald-300 hidden sm:inline">
            4-of-6 Multi-Sig Active
          </span>
        </div>
      </div>

      {/* 2. Interactive Section Tabs (High Responsive Horizontal Scroller) */}
      <div className="grid grid-cols-5 gap-1 p-1 rounded-2xl neu-tab-bar text-[10px] sm:text-xs font-bold font-mono">
        <button
          onClick={() => setActiveTab('architecture')}
          className={`py-2 px-1 rounded-xl text-center cursor-pointer transition truncate ${
            activeTab === 'architecture' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          1. 3D Ledger
        </button>
        <button
          onClick={() => setActiveTab('chess_vectors')}
          className={`py-2 px-1 rounded-xl text-center cursor-pointer transition truncate ${
            activeTab === 'chess_vectors' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          2. 400 Vectors
        </button>
        <button
          onClick={() => setActiveTab('market_dca')}
          className={`py-2 px-1 rounded-xl text-center cursor-pointer transition truncate ${
            activeTab === 'market_dca' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          3. Market DCA
        </button>
        <button
          onClick={() => setActiveTab('b2b_simulation')}
          className={`py-2 px-1 rounded-xl text-center cursor-pointer transition truncate ${
            activeTab === 'b2b_simulation' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          4. B2B Portal
        </button>
        <button
          onClick={() => setActiveTab('ecological_impact')}
          className={`py-2 px-1 rounded-xl text-center cursor-pointer transition truncate ${
            activeTab === 'ecological_impact' ? 'neu-tab-active !text-amber-300' : 'neu-tab-item'
          }`}
        >
          5. Eco Narrative
        </button>
      </div>

      {/* 3. Primary Graphics Display Canvas (WebGL / 2D High-Fidelity Geometry Engine) */}
      <div className="relative w-full h-[230px] sm:h-[290px] md:h-[340px] rounded-3xl neu-inset overflow-hidden border border-emerald-500/20 bg-zinc-950 flex flex-col justify-between p-3">
        {/* Dynamic Watermark / Overlay Header */}
        <div className="relative z-10 flex items-center justify-between text-[10px] font-mono text-zinc-400">
          <div className="flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/10">
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-bold text-zinc-200">
              {activeTab === 'architecture' && '3D CHESS LEDGER MATRIX · ENCRYPTING MOVES TO QR'}
              {activeTab === 'chess_vectors' && 'KINEMATICS: 400 EXPONENTIAL OPENING VECTORS'}
              {activeTab === 'market_dca' && 'DYNAMIC SCALED DCA: EMERALD BULLS & CRIMSON BEARS'}
              {activeTab === 'b2b_simulation' && 'B2B FLOW: PLANT-04 ➔ EXECUTIVE HUB REPLENISHMENT'}
              {activeTab === 'ecological_impact' && 'POST-CONSUMER LIFE CYCLE: TURNING PLASTIC TO FLOWERS'}
            </span>
          </div>

          <div className="flex items-center gap-1 bg-black/60 backdrop-blur-md px-2 py-1 rounded-lg border border-white/10">
            <span className="text-emerald-400 font-bold">FLWRX</span>
            <span className="text-zinc-500">|</span>
            <span>{currentCurrency}</span>
          </div>
        </div>

        {/* The Live Rendering Canvas */}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full object-cover pointer-events-none"
        />

        {/* Bottom Interactive HUD Overlays depending on Tab */}
        <div className="relative z-10 flex items-center justify-between gap-2 mt-auto">
          {activeTab === 'architecture' && (
            <div className="w-full flex items-center justify-between bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-xl border border-emerald-500/30 text-[10px] font-mono">
              <div className="flex items-center gap-2">
                <span className="text-amber-400 font-bold">{PGN_SEQUENCES[currentMoveIdx].move}</span>
                <span className="text-zinc-400 hidden sm:inline">➜ Hash: {PGN_SEQUENCES[currentMoveIdx].hash}</span>
              </div>
              <button
                onClick={() => setCurrentMoveIdx((prev) => (prev + 1) % PGN_SEQUENCES.length)}
                className="py-1 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold cursor-pointer transition active:scale-95"
              >
                Next Move ➔
              </button>
            </div>
          )}

          {activeTab === 'chess_vectors' && (
            <div className="w-full flex items-center justify-between bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-xl border border-emerald-500/30 text-[10px] font-mono">
              <div className="text-zinc-300">
                <b className="text-emerald-400">400 Positions:</b> 20 White Moves &times; 20 Black Responses
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setVectorIntensity((prev) => (prev >= 1.5 ? 0.8 : prev + 0.3))}
                  className="py-1 px-2 rounded-lg neu-inset text-emerald-400 font-bold cursor-pointer"
                >
                  Glow: {vectorIntensity.toFixed(1)}x
                </button>
              </div>
            </div>
          )}

          {activeTab === 'market_dca' && (
            <div className="w-full flex items-center justify-between bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-xl border border-emerald-500/30 text-[10px] font-mono">
              <span className="text-zinc-300">
                365-Day Rolling Spot DCA Accumulation Channel (70/30 PnL Split)
              </span>
              <button
                onClick={() => setAccumulationGlow(!accumulationGlow)}
                className="py-1 px-2 rounded-lg neu-inset text-emerald-400 font-bold cursor-pointer"
              >
                {accumulationGlow ? 'Channel: ON' : 'Channel: OFF'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 4. Tab-Specific Interactive Control Panes */}

      {/* TAB 1: 3D CORPORATE ARCHITECTURE & CHESS LEDGER */}
      {activeTab === 'architecture' && (
        <div className="space-y-2.5">
          <div className="p-3.5 rounded-2xl neu-flat space-y-2 border border-emerald-500/20">
            <h4 className="text-xs font-black uppercase text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              <span>Real-Time Chess Ledger to Anti-Counterfeit QR Pipeline</span>
            </h4>
            <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
              Every physical product's Flower Code is anchored to an immutable cryptographic game move sequence.
              Just as each vector displacement on an 8&times;8 matrix generates a unique board hash, AXIS encrypts
              product authentication passkeys into physical QR matrices that can only ever be claimed once by decentralized consumers.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center font-mono text-[11px]">
            <div className="p-2.5 rounded-xl neu-inset space-y-0.5">
              <span className="text-[9px] uppercase text-[var(--ink2)] block">Move Notation</span>
              <b className="text-[var(--ink)]">{PGN_SEQUENCES[currentMoveIdx].move}</b>
            </div>
            <div className="p-2.5 rounded-xl neu-inset space-y-0.5">
              <span className="text-[9px] uppercase text-[var(--ink2)] block">Block Merkle Root</span>
              <b className="text-emerald-600 truncate block">{PGN_SEQUENCES[currentMoveIdx].hash.slice(0, 8)}...</b>
            </div>
            <div className="p-2.5 rounded-xl neu-inset space-y-0.5">
              <span className="text-[9px] uppercase text-[var(--ink2)] block">Passkey Payload</span>
              <b className="text-teal-600 truncate block">NODE-0{currentMoveIdx + 1}</b>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: UX PRECISION: BOLD 400 MOVE VECTORS */}
      {activeTab === 'chess_vectors' && (
        <div className="space-y-2.5">
          <div className="p-3.5 rounded-2xl neu-flat space-y-2 border border-emerald-500/20">
            <h4 className="text-xs font-black uppercase text-emerald-600 dark:text-emerald-400">
              The 400 Possible Opening Vectors Theorem
            </h4>
            <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
              <em>&ldquo;After one move each, there are exactly four hundred possible positions.&rdquo;</em>
              In this high-fidelity visualization, thin, faint trajectory lines are replaced with bold, high-amplitude
              kinematic vectors. Each line models the cubic smoothstep and sine-wave oscillation of cryptographic piece movement,
              visually proving the exponential explosion of anti-counterfeit verification permutations.
            </p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setVectorSpeed((s) => (s >= 2.0 ? 0.8 : s + 0.4))}
              className="flex-1 py-2 rounded-xl neu-btn font-extrabold text-xs cursor-pointer flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Speed: {vectorSpeed.toFixed(1)}x</span>
            </button>
            <button
              onClick={() => onToast && onToast('Kinematic vector math recalculated across 400 quadrants!', 'good')}
              className="flex-1 py-2 rounded-xl neu-btn-accent font-extrabold text-xs cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Snap Vectors</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: ENHANCED MARKET DCA CANDLESTICK */}
      {activeTab === 'market_dca' && (
        <div className="space-y-2.5">
          <div className="p-3.5 rounded-2xl neu-flat space-y-2 border border-emerald-500/20">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase text-emerald-600 dark:text-emerald-400">
                High-Visibility Dynamic Scaled Accumulation
              </h4>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-600">
                Auto-Normalizing Y-Axis
              </span>
            </div>
            <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
              Standard charts flatten prolonged accumulation into an illegible horizontal line. Our dynamic axis-scaling
              algorithm detects tight consolidation bands and amplifies minute price discovery into hyper-visible neon emerald
              expansions and deep crimson pullbacks, providing institutional transparency on every 365-day DCA tranche.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center font-mono text-[11px]">
            <div className="p-2.5 rounded-xl neu-inset">
              <span className="text-[9px] text-[var(--ink2)] block">365-Day DCA Tranche</span>
              <b className="text-[var(--ink)]">Tranche #14</b>
            </div>
            <div className="p-2.5 rounded-xl neu-inset">
              <span className="text-[9px] text-[var(--ink2)] block">Realized PnL Split</span>
              <b className="text-emerald-600">70% Plant / 30% Treasury</b>
            </div>
            <div className="p-2.5 rounded-xl neu-inset">
              <span className="text-[9px] text-[var(--ink2)] block">Unbonding Lock</span>
              <b className="text-[var(--ink)]">365 Days</b>
            </div>
            <div className="p-2.5 rounded-xl neu-inset">
              <span className="text-[9px] text-[var(--ink2)] block">Spot Price ({currentCurrency})</span>
              <b className="text-emerald-600">{currencySymbol}{(0.042 * currencyRate).toFixed(2)}</b>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: MANUFACTURER CODE-DEPLETION & EXECUTIVE APPROVAL SIMULATION */}
      {activeTab === 'b2b_simulation' && (
        <div className="space-y-2.5">
          <div className="p-3.5 rounded-2xl neu-flat space-y-3 border border-emerald-500/20">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                <AlertTriangle className={`w-4 h-4 ${plantPool < 500 ? 'text-rose-500 animate-bounce' : 'text-emerald-500'}`} />
                <span>B2B Multi-Sig Replenishment Engine</span>
              </h4>
              <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md ${
                plantPool < 500 ? 'bg-rose-500/20 text-rose-500' : 'bg-emerald-500/20 text-emerald-600'
              }`}>
                {plantPool < 500 ? 'CRITICAL DEPLETION' : 'NOMINAL QUOTA'}
              </span>
            </div>

            {/* Plant-04 Pool Gauge */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span>Manufacturing Plant-04 (Cavite Hub):</span>
                <b className={plantPool < 500 ? 'text-rose-500 font-extrabold' : 'text-emerald-600'}>
                  {plantPool.toLocaleString()} / {maxPlantPool.toLocaleString()} QR Codes
                </b>
              </div>
              <div className="w-full h-2 rounded-full neu-inset overflow-hidden">
                <div
                  className={`h-full transition-all duration-500 ${
                    plantPool < 500 ? 'bg-rose-500' : 'bg-emerald-500'
                  }`}
                  style={{ width: `${Math.max(3, (plantPool / maxPlantPool) * 100)}%` }}
                />
              </div>
            </div>

            {/* Real-time Multi-Step Simulation Flow Indicator */}
            <div className="p-3 rounded-xl neu-inset space-y-2 font-mono text-[10px]">
              <div className="flex items-center justify-between border-b border-[var(--neu-border-dark)] pb-1">
                <span>SIMULATION STEP:</span>
                <b className="text-amber-500 uppercase">{b2bStep.replace('_', ' ')}</b>
              </div>

              {b2bStep === 'ALERT_TRIGGERED' && (
                <div className="text-rose-400 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                  <span>Warning: Plant-04 pool dropped below 500 threshold! Generating replenishment request packet...</span>
                </div>
              )}

              {b2bStep === 'PACKET_TRANSIT' && (
                <div className="space-y-1">
                  <div className="text-teal-400 flex items-center justify-between">
                    <span>Transiting request packet to Executive Hub (BGC HQ)...</span>
                    <span>{packetProgress}%</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-zinc-800 overflow-hidden">
                    <div className="h-full bg-teal-400 transition-all duration-75" style={{ width: `${packetProgress}%` }} />
                  </div>
                </div>
              )}

              {b2bStep === 'EXECUTIVE_REVIEW' && (
                <div className="text-emerald-400 flex items-center justify-between">
                  <span>Executive Council: 4-of-6 Multi-Signature verified! Ed25519 signatures committed.</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>
              )}

              {b2bStep === 'REPLENISHED' && (
                <div className="text-emerald-500 font-bold flex items-center gap-2">
                  <Sparkles className="w-4 h-4" />
                  <span>Batch #891 (25,000 QR Codes) officially credited to Plant-04! Escrow locked.</span>
                </div>
              )}
            </div>

            {/* Manual Trigger Buttons */}
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setB2bStep('PACKET_TRANSIT');
                  onToast && onToast('Manual replenishment request dispatched to Executive Hub!', 'good');
                }}
                className="flex-1 py-2 rounded-xl neu-btn font-extrabold text-xs cursor-pointer flex items-center justify-center gap-1.5"
              >
                <span>Request Replenishment</span>
              </button>
              <button
                onClick={() => setAutoReplenishLoop(!autoReplenishLoop)}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  autoReplenishLoop ? 'neu-tab-active' : 'neu-tab-item'
                }`}
              >
                {autoReplenishLoop ? 'Auto Loop: ON' : 'Auto Loop: PAUSED'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: GLOBAL ECOLOGICAL IMPACT & POST-CONSUMER WASTE NARRATIVE */}
      {activeTab === 'ecological_impact' && (
        <div className="space-y-2.5">
          <div className="p-3.5 rounded-2xl neu-flat space-y-2.5 border border-amber-500/30 bg-gradient-to-br from-amber-950/20 to-emerald-950/20">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase text-amber-500 flex items-center gap-1.5">
                <Globe2 className="w-4 h-4" />
                <span>The Post-Consumer Value Abyss &amp; Proof of Flower</span>
              </h4>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-400">
                Global Narrative
              </span>
            </div>

            <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
              Every day, billions of fast-moving consumer packaging items suffer from an immediate psychological drop-off:
              the instant liquid or food is consumed, the container loses <strong>100% of its perceived value</strong>.
              It is discarded onto streets, clogging agricultural drainage canals, triggering catastrophic urban flooding,
              and polluting rivers that empty into oceanic gyres.
            </p>

            <div className="p-3 rounded-xl neu-inset space-y-1.5 text-[11px] text-[var(--ink)]">
              <b className="text-emerald-500 block">How AXIS &amp; Proof of Flower Breaks the Death Cycle:</b>
              <ul className="list-disc pl-4 space-y-1 text-[var(--ink2)] text-[10.5px]">
                <li>
                  <strong>Value Persistence:</strong> Flower Codes ensure packaging retains guaranteed liquid fiat value
                  (PHP 0.50 &ndash; 50.00) even after consumption.
                </li>
                <li>
                  <strong>Direct Citizen Mining:</strong> 90% of all FLWRXCOIN tokens can only ever be mined through
                  physical recycling and decentralized node quorum.
                </li>
                <li>
                  <strong>Eliminating $4.2B Counterfeits:</strong> Cryptographic verification guarantees zero fake packaging
                  or duplicate claims enter the ecosystem.
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
