import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  errorId: string;
}

// In-memory diagnostic ring buffer for developer/admin audit (never shown to users)
export const internalDiagnosticLogs: Array<{ id: string; timestamp: number; error: string; stack?: string }> = [];

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    errorId: ''
  };

  public static getDerivedStateFromError(error: Error): State {
    const msg = error?.message || '';
    const stack = error?.stack || '';
    const isExtension =
      msg.includes('MetaMask') ||
      msg.includes('Failed to connect to MetaMask') ||
      stack.includes('chrome-extension://') ||
      stack.includes('moz-extension://') ||
      stack.includes('inpage.js');

    if (isExtension) {
      console.warn('[Axis Security Guard] Suppressed third-party extension error:', msg);
      return { hasError: false, errorId: '' };
    }

    const errorId = Math.random().toString(36).substring(2, 9);
    // Log internally for developer diagnostics without exposing backend traces to the user
    internalDiagnosticLogs.unshift({
      id: errorId,
      timestamp: Date.now(),
      error: error?.message || 'Unknown runtime error',
      stack: error?.stack
    });
    if (internalDiagnosticLogs.length > 50) internalDiagnosticLogs.pop();
    
    return { hasError: true, errorId };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Silent internal capture - Never output stack trace to UI
    console.warn('[Axis Security Guard] Handled uncaught exception safely:', error?.message);
  }

  private handleRetry = () => {
    this.setState({ hasError: false, errorId: '' });
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      // #5 SHOWING USERS YOUR BACKEND: Catch it, log it internally, show simple message with clear next step
      return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-[var(--bg)] select-none">
          <div className="max-w-sm w-full p-8 rounded-3xl neu-flat text-center space-y-6 border border-[var(--neu-border-dark)] shadow-xl">
            {/* Minimalist exclamation circle (as shown in guideline) */}
            <div className="w-16 h-16 mx-auto rounded-full neu-inset flex items-center justify-center text-[var(--ink)]">
              <span className="text-2xl font-black font-mono">!</span>
            </div>

            <div className="space-y-2">
              <h2 className="font-extrabold text-lg tracking-tight text-[var(--ink)]">
                We couldn&apos;t load this screen
              </h2>
              <p className="text-xs text-[var(--ink2)] leading-relaxed">
                Check your connection and try again. Your data and balances are safe.
              </p>
            </div>

            {/* Clear, solid, full-width primary action button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={this.handleRetry}
                className="w-full py-3.5 px-6 rounded-2xl neu-btn-accent font-extrabold text-sm shadow-md transition cursor-pointer"
              >
                Try again
              </button>
            </div>

            <div className="text-[10px] text-[var(--ink2)] font-mono opacity-60">
              Ref: {this.state.errorId || 'SYS-OK'} · Stored Safely
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
