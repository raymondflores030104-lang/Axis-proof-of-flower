import React, { useState } from 'react';

interface OnboardingModalProps {
  onComplete: () => void;
  onClose: () => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ onComplete, onClose }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 3;

  const steps = [
    {
      title: 'Scan Everyday Products',
      subtitle: 'Turn retail barcodes into liquid crypto rewards',
      desc: 'Point your camera at everyday items from partner brands like Coca-Cola, Nestlé, and Unilever. Every verified scan mints FLRX tokens straight to your vault.',
      badge: 'Step 1 of 3 · Optical Verification',
      icon: '📷'
    },
    {
      title: 'Instant Cash Out & Vouchers',
      subtitle: 'Zero lock-ins, zero deceptive points',
      desc: 'Swap FLRX directly into Philippine Pesos (PHP) with one tap to GCash and Maya, or redeem grocery barcodes at 7-Eleven. Real liquid purchasing power.',
      badge: 'Step 2 of 3 · Liquid Fiat Bridge',
      icon: '💳'
    },
    {
      title: 'Built on Trust & Transparency',
      subtitle: 'Zero dark patterns, anchored controls',
      desc: 'No hidden renewal traps, no jumping buttons, and no confusing multi-screen mazes. You are always in control of your data and funds.',
      badge: 'Step 3 of 3 · User-First Protocol',
      icon: '🛡️'
    }
  ];

  const stepData = steps[currentStep - 1];

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep((prev) => prev + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="flex flex-col h-[520px] max-h-[85vh] select-none justify-between">
      {/* Top Header & Consistent Step Progress Indicator */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-[var(--ink2)]">
          <span className="font-mono text-[10px] uppercase tracking-wider">{stepData.badge}</span>
          <span className="font-mono">{currentStep} / {totalSteps}</span>
        </div>

        {/* Smooth step progress indicator bar */}
        <div className="w-full h-1.5 rounded-full neu-inset overflow-hidden flex gap-1 p-0.5">
          {[1, 2, 3].map((step) => (
            <div
              key={step}
              className={`h-full flex-1 rounded-full transition-all duration-300 ${
                step <= currentStep ? 'bg-emerald-600' : 'bg-black/10'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Center Content Body (Changes smoothly while thumb zone stays anchored) */}
      <div className="my-auto py-6 text-center space-y-4 px-2">
        <div className="w-20 h-20 mx-auto rounded-3xl neu-flat flex items-center justify-center text-4xl shadow-md transform transition-transform duration-200 hover:scale-105">
          {stepData.icon}
        </div>
        <div className="space-y-1.5">
          <h3 className="font-extrabold text-lg tracking-tight text-[var(--ink)]">
            {stepData.title}
          </h3>
          <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">
            {stepData.subtitle}
          </p>
        </div>
        <p className="text-xs text-[var(--ink2)] leading-relaxed max-w-xs mx-auto">
          {stepData.desc}
        </p>
      </div>

      {/* #4 PRINCIPLE: FIXED ANCHORED ACTION BAR - Button NEVER moves around between screens */}
      <div className="pt-4 border-t border-[var(--neu-border-dark)] sticky bottom-0 bg-[var(--neu-bg)] pb-1">
        <div className="flex items-center justify-between text-[10px] text-[var(--ink2)] font-mono mb-2 px-1">
          <span>✓ Anchored Thumb Position</span>
          <span>Principle #4 Compliant</span>
        </div>
        <button
          type="button"
          onClick={handleNext}
          className="w-full py-3.5 px-6 rounded-2xl neu-btn-accent font-extrabold text-sm shadow-md hover:opacity-95 active:scale-98 transition cursor-pointer btn-instant-tap flex items-center justify-center gap-2"
        >
          <span>{currentStep === totalSteps ? 'Get Started' : 'Continue'}</span>
          <span>→</span>
        </button>
      </div>
    </div>
  );
};
