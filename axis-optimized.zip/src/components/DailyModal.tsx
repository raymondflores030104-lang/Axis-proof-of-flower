import React from 'react';
import { AxisState } from '../types';
import { Calendar, Flame, CheckCircle2 } from 'lucide-react';

interface DailyModalProps {
  state: AxisState;
  onClaimDaily: () => void;
  onSpinWheel?: (prize: any) => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const DailyModal: React.FC<DailyModalProps> = ({
  state,
  onClaimDaily
}) => {
  const todayKey = new Date().toISOString().slice(0, 10);
  const alreadyClaimed = state.claim?.last === todayKey;

  const streakDays = [
    { day: 1, reward: 0.5 },
    { day: 2, reward: 1.0 },
    { day: 3, reward: 1.5 },
    { day: 4, reward: 2.0 },
    { day: 5, reward: 3.0 },
    { day: 6, reward: 4.5 },
    { day: 7, reward: 10.0 }
  ];

  return (
    <div className="space-y-4 select-none">
      <div className="landscape:grid landscape:grid-cols-12 landscape:gap-4 landscape:space-y-0 items-center">
        {/* Left Column in Landscape: Streak Info & Claim Button */}
        <div className="landscape:col-span-5 space-y-3">
          <div className="p-3.5 sm:p-4 rounded-2xl neu-flat text-center space-y-1.5 sm:space-y-2">
            <div className="w-11 h-11 sm:w-12 sm:h-12 mx-auto rounded-2xl neu-inset flex items-center justify-center text-amber-500">
              <Flame className="w-5 h-5 sm:w-6 sm:h-6 animate-bounce" />
            </div>
            <h3 className="font-extrabold text-sm sm:text-base text-[var(--ink)]">
              {state.claim?.streak || 1}-Day Mining Streak
            </h3>
            <p className="text-[11px] text-[var(--ink2)] max-w-xs mx-auto leading-tight">
              Check in daily to accumulate bonus FLWRX.
            </p>
          </div>

          <button
            onClick={onClaimDaily}
            disabled={alreadyClaimed}
            className={`w-full py-2.5 sm:py-3 rounded-xl font-extrabold text-xs sm:text-sm transition cursor-pointer shadow-xs ${
              alreadyClaimed
                ? 'neu-inset opacity-50 cursor-not-allowed text-[var(--ink2)]'
                : 'neu-btn-accent'
            }`}
          >
            {alreadyClaimed ? 'Checked In Today ✓' : 'Claim Daily Bonus'}
          </button>
        </div>

        {/* Right Column in Landscape: 7-Day Matrix */}
        <div className="landscape:col-span-7 mt-3 landscape:mt-0">
          <div className="grid grid-cols-7 gap-1 sm:gap-1.5 text-center">
            {streakDays.map((d) => {
              const isDone = (state.claim?.streak || 1) >= d.day && alreadyClaimed;
              const isCurrent = (state.claim?.streak || 1) === d.day && !alreadyClaimed;

              return (
                <div
                  key={d.day}
                  className={`p-1.5 sm:p-2 rounded-xl flex flex-col items-center justify-between min-h-[64px] sm:min-h-[70px] ${
                    isDone ? 'neu-tab-active' : isCurrent ? 'neu-flat border-2 border-amber-500' : 'neu-inset'
                  }`}
                >
                  <span className="text-[8.5px] sm:text-[9px] font-bold uppercase">D{d.day}</span>
                  <span className="text-[10px] sm:text-[11px] font-black font-mono">+{d.reward}</span>
                  {isDone ? (
                    <CheckCircle2 className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-white" />
                  ) : (
                    <span className="text-[7.5px] sm:text-[8px] font-bold">FLWRX</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
