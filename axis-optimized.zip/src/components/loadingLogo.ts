/**
 * Loading-screen helpers: the growing tree logo and the "SCAN FOR / World Reward" lockup.
 * Pure geometry + small DOM helpers so the animation can be driven by progress (0-100).
 */

export interface Leaf {
  ay: number;
  s: number;
  a: number;
  rx: number;
  ry: number;
}

/** Bottom leaves first, top leaf last. */
export const LEAVES: Leaf[] = [
  { ay: 138, s: -1, a: 32, rx: 25, ry: 10 },
  { ay: 130, s: 1, a: 32, rx: 25, ry: 10 },
  { ay: 110, s: -1, a: 38, rx: 23, ry: 9.5 },
  { ay: 102, s: 1, a: 38, rx: 23, ry: 9.5 },
  { ay: 84, s: -1, a: 46, rx: 19, ry: 8 },
  { ay: 76, s: 1, a: 46, rx: 19, ry: 8 },
  { ay: 58, s: 1, a: 90, rx: 16, ry: 7 },
];

/** Stem runs bottom (y0) to top (y1). `end` = progress % when the stem is fully grown, `pop` = progress % a leaf takes to pop. */
export const STEM = { y0: 166, y1: 54, len: 112, end: 80, pop: 18 };

export const easeOutBack = (x: number): number => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};

/** Progress (%) at which leaf i starts to pop: right when the growing stem reaches its attach point. */
export const leafStart = (leaf: Leaf): number =>
  (STEM.end * (STEM.y0 - leaf.ay)) / STEM.len;

/** Scale (0 → overshoot → 1) of leaf i at progress p. */
export const leafScale = (leaf: Leaf, p: number): number => {
  const x = Math.max(0, Math.min(1, (p - leafStart(leaf)) / STEM.pop));
  return x <= 0 ? 0 : easeOutBack(x);
};

export const leafShape = (leaf: Leaf) => {
  const r = (leaf.a * Math.PI) / 180;
  const dx = leaf.s * Math.cos(r);
  const dy = -Math.sin(r);
  return {
    cx: 100 + dx * leaf.rx,
    cy: leaf.ay + dy * leaf.rx,
    rotate: (Math.atan2(dy, dx) * 180) / Math.PI,
    tipX: 100 + dx * leaf.rx * 1.85,
    tipY: leaf.ay + dy * leaf.rx * 1.85,
  };
};

export const leafTransform = (leaf: Leaf, scale: number): string =>
  `translate(100 ${leaf.ay}) scale(${scale.toFixed(3)}) translate(-100 -${leaf.ay})`;

export const stemOffset = (p: number): number =>
  STEM.len * (1 - Math.min(1, p / STEM.end));

/** Apply progress p (0-100) to the logo elements. */
export const applyLogoProgress = (
  stem: SVGPathElement | null,
  leaves: (SVGGElement | null)[],
  p: number
) => {
  if (stem) {
    stem.setAttribute('stroke-dashoffset', stemOffset(p).toFixed(2));
    stem.setAttribute('stroke-opacity', p / STEM.end > 0.01 ? '1' : '0');
  }
  LEAVES.forEach((leaf, i) => {
    const g = leaves[i];
    if (g) g.setAttribute('transform', leafTransform(leaf, leafScale(leaf, p)));
  });
};

export const STACK_SIZE = 12.8; // 20% less size than 16 (16 * 0.8)
export const STACK_WEIGHT = 600;
export const SCAN_WEIGHT = 800;

export interface LockupMetrics {
  width: number;
  height: number;
  base: number;
  scanSize: number;
  scanSpacing: number;
  stackX: number;
  stackSize: number;
  worldY: number;
  rewardY: number;
}

export const computeLockup = (
  measure: (text: string, weight: number) => { asc: number; w: number }
): LockupMetrics => {
  const fs = STACK_SIZE;
  const step = fs * 1.2;
  const mW = measure('World', STACK_WEIGHT);
  const mR = measure('Reward', STACK_WEIGHT);
  const mS = measure('SCAN FOR', SCAN_WEIGHT);
  const total = step + Math.max(mW.asc, mR.asc) * fs; // height of the World/Reward stack
  const scanSize = total / mS.asc; // SCAN FOR capitals == stack height
  const scanSpacing = scanSize * 0.05;
  const wScan = mS.w * scanSize + scanSpacing * 8;
  const gap = scanSize * 0.3;
  const wStack = Math.max(mW.w, mR.w) * fs;
  const width = Math.ceil(wScan + gap + wStack + 2);
  const height = Math.ceil(total + 4);
  const base = height - 2;
  return {
    width,
    height,
    base,
    scanSize,
    scanSpacing,
    stackX: wScan + gap,
    stackSize: fs,
    worldY: base - step,
    rewardY: base,
  };
};

/** Measure text with a canvas; falls back to typical proportions if the browser can't. */
export const canvasMeasure = (family: string) => {
  let ctx: CanvasRenderingContext2D | null = null;
  try {
    ctx = document.createElement('canvas').getContext('2d');
  } catch {
    ctx = null;
  }
  return (text: string, weight: number) => {
    let asc = 0.72;
    let w = text.length * 0.62;
    if (ctx) {
      try {
        ctx.font = `${weight} 100px ${family}`;
        const m = ctx.measureText(text);
        if (m.actualBoundingBoxAscent) asc = m.actualBoundingBoxAscent / 100;
        if (m.width) w = m.width / 100;
      } catch {
        /* keep fallback */
      }
    }
    return { asc, w };
  };
};
