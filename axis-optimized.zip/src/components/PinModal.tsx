import React, { useState } from 'react';
import { Lock, AlertCircle, ShieldCheck } from 'lucide-react';
import { hashPinWithSalt, verifyPinHash } from '../blockchain/cryptoUtils';

export interface PinModalProps {
  title?: string;
  mode?: 'verify' | 'setup';
  currentPinHash?: string | null;
  currentPinSalt?: string | null;
  onSuccess: (result: { pinHash: string; pinSalt: string } | boolean) => void;
  onCancel?: () => void;
  onClose?: () => void;
  onToast?: (msg: string, type?: 'good' | 'err') => void;
}

export const PinModal: React.FC<PinModalProps> = ({
  title = 'Enter Security PIN',
  mode = 'verify',
  currentPinHash,
  currentPinSalt,
  onSuccess,
  onCancel,
  onClose,
  onToast
}) => {
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [step, setStep] = useState<'enter' | 'confirm'>(mode === 'setup' ? 'enter' : 'enter');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockedUntil, setLockedUntil] = useState<number | null>(null);

  const handleDigit = (digit: string) => {
    if (lockedUntil && Date.now() < lockedUntil) {
      const waitSec = Math.ceil((lockedUntil - Date.now()) / 1000);
      setErrorMsg(`Too many failed attempts. Device locked for ${waitSec}s.`);
      return;
    }
    setErrorMsg(null);
    if (pin.length < 6) {
      setPin((prev) => prev + digit);
    }
  };

  const handleBackspace = () => {
    setErrorMsg(null);
    setPin((prev) => prev.slice(0, -1));
  };

  const handleConfirm = async () => {
    if (lockedUntil && Date.now() < lockedUntil) {
      const waitSec = Math.ceil((lockedUntil - Date.now()) / 1000);
      setErrorMsg(`Device locked for ${waitSec}s.`);
      return;
    }

    if (pin.length < 4) {
      setErrorMsg('PIN must be at least 4 digits');
      return;
    }

    if (mode === 'setup') {
      if (step === 'enter') {
        setConfirmPin(pin);
        setPin('');
        setStep('confirm');
        setErrorMsg(null);
        return;
      }

      // Step confirm
      if (pin !== confirmPin) {
        setErrorMsg('PINs do not match. Please restart setup.');
        setPin('');
        setConfirmPin('');
        setStep('enter');
        return;
      }

      // Generate cryptographically secure salted hash
      try {
        const { hash, salt } = await hashPinWithSalt(pin);
        onSuccess({ pinHash: hash, pinSalt: salt });
      } catch (err: any) {
        setErrorMsg(err?.message || 'Cryptographic hashing failed');
      }
      return;
    }

    // Verification Mode
    if (!currentPinHash || !currentPinSalt) {
      // No PIN previously set, accept entry as valid
      onSuccess(true);
      return;
    }

    const isValid = await verifyPinHash(pin, currentPinHash, currentPinSalt);
    if (isValid) {
      setFailedAttempts(0);
      onSuccess(true);
    } else {
      const nextFailures = failedAttempts + 1;
      setFailedAttempts(nextFailures);
      setPin('');

      if (nextFailures >= 5) {
        const lockDuration = 5 * 60 * 1000; // 5 minute lock
        setLockedUntil(Date.now() + lockDuration);
        setErrorMsg('Security Lockout: 5 consecutive failed attempts. Locked for 5 minutes.');
        if (onToast) onToast('PIN verification locked due to excessive failed attempts.', 'err');
      } else {
        const remaining = 5 - nextFailures;
        setErrorMsg(`Incorrect PIN. ${remaining} attempt(s) remaining before lockout.`);
      }
    }
  };

  return (
    <div className="space-y-4 select-none max-w-xs mx-auto text-center">
      <div className="w-12 h-12 mx-auto rounded-2xl neu-inset flex items-center justify-center text-emerald-600">
        <Lock className="w-6 h-6" />
      </div>
      <div>
        <h3 className="font-extrabold text-sm text-[var(--ink)]">
          {mode === 'setup'
            ? step === 'enter'
              ? 'Create New Master PIN'
              : 'Confirm Master PIN'
            : title}
        </h3>
        <p className="text-[11px] text-[var(--ink2)]">
          {mode === 'setup'
            ? step === 'enter'
              ? 'Enter 4-6 digit master security PIN'
              : 'Re-enter your PIN to confirm'
            : 'Enter 4-6 digit security PIN to authorize'}
        </p>
      </div>

      {errorMsg && (
        <div className="p-2 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-bold flex items-center justify-center gap-1.5 animate-pulse">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* PIN Dots Display */}
      <div className="flex justify-center gap-3 py-2">
        {[0, 1, 2, 3, 4, 5].map((idx) => (
          <div
            key={idx}
            className={`w-3.5 h-3.5 rounded-full transition-all ${
              idx < pin.length ? 'bg-emerald-600 scale-110 shadow-xs' : 'neu-inset'
            }`}
          />
        ))}
      </div>

      {/* Keypad */}
      <div className="grid grid-cols-3 gap-2.5 pt-2">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
          <button
            key={digit}
            onClick={() => handleDigit(digit)}
            className="py-3 rounded-2xl neu-btn text-base font-bold font-mono text-[var(--ink)] cursor-pointer active:scale-95 transition-transform"
          >
            {digit}
          </button>
        ))}
        <button
          onClick={handleBackspace}
          className="py-3 rounded-2xl neu-btn text-xs font-bold text-rose-500 cursor-pointer active:scale-95 transition-transform"
        >
          DEL
        </button>
        <button
          onClick={() => handleDigit('0')}
          className="py-3 rounded-2xl neu-btn text-base font-bold font-mono text-[var(--ink)] cursor-pointer active:scale-95 transition-transform"
        >
          0
        </button>
        <button
          onClick={handleConfirm}
          disabled={pin.length < 4}
          className={`py-3 rounded-2xl font-bold text-xs cursor-pointer active:scale-95 transition-all ${
            pin.length >= 4 ? 'neu-tab-active font-extrabold' : 'neu-inset opacity-50'
          }`}
        >
          {step === 'confirm' ? 'SAVE' : 'OK'}
        </button>
      </div>

      <div className="pt-2 text-[10px] text-[var(--ink2)] flex items-center justify-center gap-1">
        <ShieldCheck className="w-3 h-3 text-emerald-600" />
        <span>Protected with PBKDF2 CSPRNG Cryptographic Salts</span>
      </div>
    </div>
  );
};
