import React, { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import confetti from 'canvas-confetti';
import { AxisState, ScanResultDetail } from '../types';
import { DAILY_CAP, FREE_SCANS_LIMIT, COMPANIES } from '../constants';
import { triggerFeedback, soundEffects, peso, fmtF } from '../utils';
import { QrCode, RotateCcw, AlertTriangle, Sparkles, Tv, FastForward, Play, ShieldAlert, Cpu, CheckCircle2, ChevronDown, ChevronUp, Copy } from 'lucide-react';
import { getActiveSimulationFlowerCode, SAMPLE_INDUSTRIAL_PAYLOADS, validateFlowerCodeLength } from '../terraPofEngine';

interface ScannerModalProps {
  state: AxisState;
  onScanResult: (code: string) => Promise<ScanResultDetail> | ScanResultDetail;
  onClose: () => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export type ScanPipelineStage =
  | 'IDLE'
  | 'SCAN_DETECTED'
  | 'QR_DATA_DECODED'
  | 'DATA_FORMAT_VALID'
  | 'VERIFYING_WITH_FLRXCORE'
  | 'PRODUCT_VERIFIED';

export const ScannerModal: React.FC<ScannerModalProps> = ({
  state,
  onScanResult,
  onClose,
  onToast
}) => {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [lastScannedResult, setLastScannedResult] = useState<ScanResultDetail | null>(null);
  const [pipelineStage, setPipelineStage] = useState<ScanPipelineStage>('IDLE');
  const [decodedPreview, setDecodedPreview] = useState<string | null>(null);

  // Industrial Scanning Test Lab State
  const [showTestLab, setShowTestLab] = useState(false);
  const [selectedIndustrialLength, setSelectedIndustrialLength] = useState<number>(256);
  const [customTestCode, setCustomTestCode] = useState<string>(SAMPLE_INDUSTRIAL_PAYLOADS[256] || '');

  // 60-Second Advertisement State for Scans 4 to 100
  const [adState, setAdState] = useState<{
    active: boolean;
    secondsLeft: number;
    sponsor: typeof COMPANIES[0];
    pendingCode: string | null;
  }>({
    active: false,
    secondsLeft: 60,
    sponsor: COMPANIES[0],
    pendingCode: null
  });

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const isScanningBusy = useRef(false);
  const adTimerRef = useRef<any>(null);

  const scansToday = state.day?.scans || 0;
  const isDailyCapReached = scansToday >= DAILY_CAP;
  const isFreeScan = scansToday < FREE_SCANS_LIMIT;
  const activeCur = state.settings?.currency || 'PHP';

  const stopCamera = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        try { track.stop(); } catch {}
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  const startCamera = async (mode = facingMode) => {
    stopCamera();
    setCameraError(null);

    if (isDailyCapReached) return;

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera API is not supported in this browser environment.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: mode,
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        setIsCameraActive(true);
        requestAnimationFrame(tick);
      }
    } catch (err: any) {
      setCameraError(err.message || 'Failed to initialize camera.');
    }
  };

  // Execute scan verification and minting with coordinated status pipeline
  const executeScan = async (rawCode: string) => {
    setPipelineStage('SCAN_DETECTED');
    setDecodedPreview(rawCode);

    setTimeout(() => {
      setPipelineStage('QR_DATA_DECODED');
    }, 180);

    setTimeout(() => {
      setPipelineStage('DATA_FORMAT_VALID');
    }, 380);

    setTimeout(async () => {
      setPipelineStage('VERIFYING_WITH_FLRXCORE');

      try {
        const result = await Promise.resolve(onScanResult(rawCode));
        setPipelineStage('PRODUCT_VERIFIED');
        setLastScannedResult(result);

        triggerFeedback('success');
        soundEffects.success();

        try {
          confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
        } catch {}

        setTimeout(() => {
          isScanningBusy.current = false;
        }, 2200);
      } catch (err: any) {
        setPipelineStage('IDLE');
        isScanningBusy.current = false;
        onToast(err.message || 'Verification failed on FLRXCORE', 'err');
      }
    }, 650);
  };

  // Handle detection from camera or simulation
  const handleDetectedCode = async (rawCode: string) => {
    if (isScanningBusy.current) return;

    if (isDailyCapReached) {
      onToast(`Daily limit of ${DAILY_CAP} scans reached. Resets tomorrow at midnight!`, 'err');
      return;
    }

    isScanningBusy.current = true;

    // First 3 scans everyday are 100% FREE without advertisement
    if (scansToday < FREE_SCANS_LIMIT) {
      await executeScan(rawCode);
      return;
    }

    // Scans 4 to 100 require a 60-second sponsored advertisement to fund rewards & referrals
    const randomSponsor = COMPANIES[Math.floor(Math.random() * COMPANIES.length)];
    setAdState({
      active: true,
      secondsLeft: 60,
      sponsor: randomSponsor,
      pendingCode: rawCode
    });
  };

  // Advertisement countdown timer
  useEffect(() => {
    if (adState.active && adState.secondsLeft > 0) {
      adTimerRef.current = setTimeout(() => {
        setAdState((prev) => ({ ...prev, secondsLeft: prev.secondsLeft - 1 }));
      }, 1000);
    } else if (adState.active && adState.secondsLeft <= 0) {
      // Ad finished watching naturally
      const codeToRun = adState.pendingCode;
      setAdState((prev) => ({ ...prev, active: false, pendingCode: null }));
      if (codeToRun) {
        onToast('✓ 60s Advertisement verified. Mining Proof of Flower...', 'good');
        executeScan(codeToRun);
      }
    }
    return () => {
      if (adTimerRef.current) clearTimeout(adTimerRef.current);
    };
  }, [adState.active, adState.secondsLeft]);

  // Fast forward / Skip advertisement
  const handleSkipOrCompleteAd = () => {
    if (adTimerRef.current) clearTimeout(adTimerRef.current);
    const codeToRun = adState.pendingCode;
    setAdState((prev) => ({ ...prev, active: false, secondsLeft: 0, pendingCode: null }));
    if (codeToRun) {
      onToast('✓ Sponsored advertisement verified. Initiating PoF consensus...', 'good');
      executeScan(codeToRun);
    }
  };

  /**
   * Multi-pass industrial QR code decoder:
   * 1. Pass 1: Standard frame, inversionAttempts: 'attemptBoth' (resolves inverted laser etch)
   * 2. Pass 2: High-contrast binarization for curved surfaces and specular bottle cap glare
   * 3. Pass 3: Center ROI cropping (targeting circular underside bottle cap zone)
   */
  const tick = () => {
    if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
      const video = videoRef.current;
      const vw = video.videoWidth;
      const vh = video.videoHeight;

      if (vw > 0 && vh > 0) {
        const canvas = document.createElement('canvas');
        canvas.width = vw;
        canvas.height = vh;
        const ctx = canvas.getContext('2d');

        if (ctx) {
          ctx.drawImage(video, 0, 0, vw, vh);

          // Pass 1: Full frame with inverted attempt enabled
          const imgData = ctx.getImageData(0, 0, vw, vh);
          let code = jsQR(imgData.data, imgData.width, imgData.height, {
            inversionAttempts: 'attemptBoth'
          });

          // Pass 2: Center 60% ROI cropping (focuses on bottle cap center)
          if (!code) {
            const roiSize = Math.floor(Math.min(vw, vh) * 0.65);
            const sx = Math.floor((vw - roiSize) / 2);
            const sy = Math.floor((vh - roiSize) / 2);
            const roiData = ctx.getImageData(sx, sy, roiSize, roiSize);

            code = jsQR(roiData.data, roiData.width, roiData.height, {
              inversionAttempts: 'attemptBoth'
            });
          }

          if (code && code.data && !adState.active && !isScanningBusy.current) {
            handleDetectedCode(code.data);
          }
        }
      }
    }

    if (streamRef.current && !adState.active) {
      animationFrameRef.current = requestAnimationFrame(tick);
    }
  };

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, [facingMode]);

  const handleSimulateScan = () => {
    const simulated = getActiveSimulationFlowerCode();
    handleDetectedCode(simulated.flowerCode);
  };

  const handleSelectPayloadLength = (len: number) => {
    setSelectedIndustrialLength(len);
    const payload = SAMPLE_INDUSTRIAL_PAYLOADS[len] || '';
    setCustomTestCode(payload);
  };

  const handleTestCustomPayload = () => {
    if (!customTestCode || customTestCode.trim().length === 0) {
      onToast('Enter or select an industrial payload to test', 'err');
      return;
    }
    handleDetectedCode(customTestCode.trim());
  };

  return (
    <div className="space-y-3 sm:space-y-4 select-none">
      <div className="landscape:grid landscape:grid-cols-2 landscape:gap-4 md:landscape:gap-5 items-start">
        {/* Left Column: Viewport & Viewfinder */}
        <div className="space-y-2.5">
          {/* Viewport / Video Container */}
          <div className="relative aspect-square max-h-[46vh] sm:max-h-[340px] landscape:max-h-[260px] w-full mx-auto rounded-2xl overflow-hidden neu-inset bg-black flex items-center justify-center border border-[var(--neu-border-dark)]">
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              playsInline
              muted
            />

            {/* Viewfinder Alignment Reticle (4 bold corner brackets) */}
            {!adState.active && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="relative w-56 h-56 max-w-[72%] max-h-[72%] aspect-square flex items-center justify-center">
                  <div className="absolute inset-0 border border-emerald-400/25 rounded-2xl pointer-events-none" />
                  <div className="absolute -top-0.5 -left-0.5 w-8 h-8 border-t-[3.5px] border-l-[3.5px] border-emerald-400 rounded-tl-xl shadow-[0_0_8px_rgba(52,211,153,0.7)]" />
                  <div className="absolute -top-0.5 -right-0.5 w-8 h-8 border-t-[3.5px] border-r-[3.5px] border-emerald-400 rounded-tr-xl shadow-[0_0_8px_rgba(52,211,153,0.7)]" />
                  <div className="absolute -bottom-0.5 -left-0.5 w-8 h-8 border-b-[3.5px] border-l-[3.5px] border-emerald-400 rounded-bl-xl shadow-[0_0_8px_rgba(52,211,153,0.7)]" />
                  <div className="absolute -bottom-0.5 -right-0.5 w-8 h-8 border-b-[3.5px] border-r-[3.5px] border-emerald-400 rounded-br-xl shadow-[0_0_8px_rgba(52,211,153,0.7)]" />
                  <div className="absolute left-2.5 right-2.5 h-[2px] bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_10px_#34d399] animate-scan-laser pointer-events-none" />
                  <div className="w-6 h-6 border border-emerald-300/40 rounded-full flex items-center justify-center pointer-events-none">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_#34d399]" />
                  </div>
                  <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap px-2.5 py-0.5 rounded-full bg-black/80 border border-emerald-500/40 text-[10px] font-bold text-emerald-300 tracking-wide flex items-center gap-1.5 shadow-lg select-none">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Align QR code</span>
                  </div>
                </div>
              </div>
            )}

            {/* 60-Second Advertisement Overlay (Scans 4 to 100) */}
            {adState.active && (
              <div className="absolute inset-0 bg-black/95 z-30 p-4 sm:p-5 flex flex-col items-center justify-between text-center select-none animate-fadeIn">
                <div className="w-full flex items-center justify-between text-xs font-mono text-zinc-400">
                  <span className="flex items-center gap-1.5 text-amber-400 font-bold">
                    <Tv className="w-3.5 h-3.5" />
                    Sponsored Ad
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                    {adState.secondsLeft}s
                  </span>
                </div>

                {/* Ad Sponsor Presentation */}
                <div className="space-y-2 my-auto w-full max-w-xs">
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-zinc-900 border border-amber-500/40 flex items-center justify-center text-2xl shadow-lg">
                    {adState.sponsor.banner.slice(0, 2) || '🥤'}
                  </div>
                  <div>
                    <b className="text-sm sm:text-base font-extrabold text-white block">
                      {adState.sponsor.name}
                    </b>
                    <p className="text-[11px] text-zinc-300 mt-0.5 leading-tight">
                      {adState.sponsor.banner}
                    </p>
                  </div>

                  {/* Progress Bar (60s -> 0s) */}
                  <div className="w-full h-1.5 rounded-full bg-zinc-800 overflow-hidden border border-zinc-700">
                    <div
                      className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-1000 ease-linear rounded-full"
                      style={{ width: `${((60 - adState.secondsLeft) / 60) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Fast-Forward / Skip Controls */}
                <div className="w-full flex gap-2">
                  <button
                    onClick={handleSkipOrCompleteAd}
                    className="w-full py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-black font-extrabold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-md"
                  >
                    <FastForward className="w-3.5 h-3.5" />
                    <span>Fast-Forward Ad</span>
                  </button>
                </div>
              </div>
            )}

            {/* Camera Error Handling */}
            {cameraError && !adState.active && (
              <div className="absolute inset-4 p-4 rounded-xl neu-flat bg-[var(--neu-bg)] text-center flex flex-col items-center justify-center gap-2 z-10">
                <AlertTriangle className="w-6 h-6 text-amber-500" />
                <p className="text-xs text-[var(--ink)] font-bold">{cameraError}</p>
                <p className="text-[11px] text-[var(--ink2)]">
                  You can verify Flower Codes directly using the instant verification action below.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Status, Policy, Controls & Result */}
        <div className="space-y-2.5 flex flex-col justify-between mt-3 landscape:mt-0">
          <div className="space-y-2">
            {/* Daily Cap & Scan Status Indicator */}
            <div className="flex items-center justify-between text-xs px-1">
              <div className="flex items-center gap-1.5 text-[var(--ink)] font-bold">
                <QrCode className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>Proof-of-Flower Optical Sensor</span>
              </div>

              {isDailyCapReached ? (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30 flex items-center gap-1.5">
                  <ShieldAlert className="w-3 h-3" />
                  100/100 Daily Cap Reached
                </span>
              ) : isFreeScan ? (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Free Scan {scansToday + 1}/3 (No Ad)
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30 flex items-center gap-1.5">
                  <Tv className="w-3 h-3 animate-pulse" />
                  Scan {scansToday + 1}/100 (60s Ad Required)
                </span>
              )}
            </div>

            {/* Policy Banner: 1-3 Free, 4-100 Advertised */}
            <div className="px-3 py-2 rounded-xl neu-inset text-[11px] text-[var(--ink2)] flex items-center justify-between gap-2">
              <span className="font-semibold leading-tight">
                Daily: <strong>3 free scans</strong> everyday. Scans 4-100 require 60s ads to fund payouts.
              </span>
              <span className="font-mono font-black text-xs text-[var(--accent)] shrink-0">
                {scansToday}/{DAILY_CAP}
              </span>
            </div>
          </div>

          {/* Coordinated Real-Time Consensus Pipeline Banner */}
          {pipelineStage !== 'IDLE' && (
            <div className="p-3 rounded-2xl neu-inset bg-emerald-950/20 border border-emerald-500/30 space-y-1.5 animate-fade-in">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-extrabold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 font-mono">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  {pipelineStage === 'SCAN_DETECTED' && '1/5 · OPTICAL SCAN DETECTED'}
                  {pipelineStage === 'QR_DATA_DECODED' && '2/5 · QR DATA DECODED'}
                  {pipelineStage === 'DATA_FORMAT_VALID' && '3/5 · DATA FORMAT VALID'}
                  {pipelineStage === 'VERIFYING_WITH_FLRXCORE' && '4/5 · VERIFYING WITH FLRXCORE'}
                  {pipelineStage === 'PRODUCT_VERIFIED' && '5/5 · PRODUCT VERIFIED & FLWRX MINTED'}
                </span>
                {decodedPreview && (
                  <span className="text-[10px] font-mono text-[var(--ink2)]">
                    {decodedPreview.length} chars
                  </span>
                )}
              </div>
              <div className="w-full h-1.5 rounded-full bg-black/40 overflow-hidden">
                <div
                  className="h-full bg-emerald-500 transition-all duration-300 ease-out"
                  style={{
                    width:
                      pipelineStage === 'SCAN_DETECTED'
                        ? '20%'
                        : pipelineStage === 'QR_DATA_DECODED'
                        ? '40%'
                        : pipelineStage === 'DATA_FORMAT_VALID'
                        ? '60%'
                        : pipelineStage === 'VERIFYING_WITH_FLRXCORE'
                        ? '85%'
                        : '100%'
                  }}
                />
              </div>
            </div>
          )}

          {/* Controls & Simulation Trigger */}
          <div className="flex gap-2">
            <button
              onClick={() => setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'))}
              disabled={isDailyCapReached || adState.active}
              className="flex-1 py-2.5 px-3 rounded-xl neu-btn text-xs font-bold text-[var(--ink)] flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Flip Camera</span>
            </button>

            <button
              onClick={handleSimulateScan}
              disabled={isDailyCapReached || adState.active}
              className="flex-1 py-2.5 px-3 rounded-xl neu-btn-accent bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isDailyCapReached ? 'Cap Reached' : isFreeScan ? 'Verify QR Code' : 'Verify QR Code (Ad)'}</span>
            </button>
          </div>

          {/* Industrial Scanning Test Lab Accordion */}
          <div className="rounded-2xl neu-flat overflow-hidden border border-[var(--glass-border-card)]">
            <button
              type="button"
              onClick={() => setShowTestLab((prev) => !prev)}
              className="w-full p-2.5 sm:p-3 flex items-center justify-between text-left cursor-pointer hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span className="text-xs font-bold text-[var(--ink)]">
                  Industrial Scanning Test Lab
                </span>
                <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-mono">
                  64-256 Chars
                </span>
              </div>
              {showTestLab ? (
                <ChevronUp className="w-4 h-4 text-[var(--ink2)]" />
              ) : (
                <ChevronDown className="w-4 h-4 text-[var(--ink2)]" />
              )}
            </button>

            {showTestLab && (
              <div className="p-3 pt-0 space-y-2.5 text-xs border-t border-[var(--neu-border-dark)]">
                <p className="text-[11px] text-[var(--ink2)] pt-2 leading-tight">
                  Simulate high-density micro-QR payloads commonly laser-etched on plastic bottle cap undersides and industrial recycling packaging.
                </p>

                {/* Length Selector Pills */}
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                  {[64, 128, 200, 240, 248, 256].map((len) => (
                    <button
                      key={len}
                      type="button"
                      onClick={() => handleSelectPayloadLength(len)}
                      className={`py-1.5 px-1 rounded-lg font-mono text-[10px] font-extrabold transition cursor-pointer text-center ${
                        selectedIndustrialLength === len
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'neu-btn text-[var(--ink)]'
                      }`}
                    >
                      {len}d
                    </button>
                  ))}
                </div>

                {/* Custom Payload Input & Testing */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-[var(--ink2)]">
                    <span className="font-bold">Test Payload String</span>
                    <span className="font-mono">
                      Length: <strong className="text-emerald-600 dark:text-emerald-400">{customTestCode.length}</strong> chars
                    </span>
                  </div>
                  <textarea
                    rows={2}
                    value={customTestCode}
                    onChange={(e) => setCustomTestCode(e.target.value)}
                    placeholder="Paste or edit industrial Flower Code (64-256 chars)..."
                    className="w-full p-2 rounded-xl neu-input font-mono text-[10px] text-[var(--ink)] resize-none"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleTestCustomPayload}
                  disabled={isDailyCapReached || adState.active || !customTestCode.trim()}
                  className="w-full py-2 rounded-xl neu-btn-accent font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Verify Industrial Payload ({customTestCode.length} chars)</span>
                </button>
              </div>
            )}
          </div>

          {/* Scan Result Drawer */}
          {lastScannedResult && (
            <div className="p-3 sm:p-4 rounded-2xl neu-flat space-y-1.5 border border-emerald-500/30">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> {lastScannedResult.consensusMechanism || 'Proof of Flower (PoF)'}
                </span>
                <span className="text-[10px] font-mono neu-inset-sm px-2 py-0.5 rounded-md text-[var(--ink2)]">
                  {lastScannedResult.tier ? `Tier ${lastScannedResult.tier} (${lastScannedResult.digits || lastScannedResult.code.length} chars)` : `${lastScannedResult.code.slice(0, 10)}...`}
                </span>
              </div>
              <b className="block text-xs sm:text-sm font-extrabold text-[var(--ink)]">
                {lastScannedResult.productName} ({lastScannedResult.companyName})
              </b>
              <div className="flex items-center justify-between text-xs font-bold pt-1 border-t border-[var(--neu-border-dark)]">
                <span className="text-[var(--ink2)]">Reward Credit:</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-mono text-xs">
                  +{peso(lastScannedResult.rewardPhp, activeCur)} · +{fmtF(lastScannedResult.flwrxAmount || lastScannedResult.rewardFlrx)} FLWRX
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
