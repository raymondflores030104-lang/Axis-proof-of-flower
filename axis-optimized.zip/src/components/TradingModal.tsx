import React, { useState } from 'react';
import { AxisState, Candle } from '../types';
import { FX, FEE } from '../constants';
import { peso, fmtF, r2, r4, r6, curInfo } from '../utils';
import { TrendingUp, ArrowDownUp, ShieldCheck, AlertCircle } from 'lucide-react';

interface TradingModalProps {
  state: AxisState;
  candles: Candle[];
  chg24: number;
  onTrade: (side: 'buy' | 'sell', amount: number) => void;
  onPlaceOrder: (type: 'market' | 'limit' | 'stop', side: 'buy' | 'sell', amt: number, px: number) => void;
  onCancelOrder: (id: string) => void;
  onAddAlert: (dir: 'above' | 'below', price: number) => void;
  onDeleteAlert?: (id: string) => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const TradingModal: React.FC<TradingModalProps> = ({
  state,
  candles,
  chg24,
  onTrade,
  onPlaceOrder,
  onCancelOrder,
  onAddAlert,
  onToast
}) => {
  const [activeTab, setActiveTab] = useState<'trade' | 'orders'>('trade');
  const [tradeSide, setTradeSide] = useState<'buy' | 'sell'>('buy');
  const [amount, setAmount] = useState('');

  const userCur = state.settings?.currency || 'PHP';
  const [curSym, curRate] = curInfo(userCur);
  const pairLabel = `FLWRX/${userCur}`;

  const numAmount = parseFloat(amount) || 0;
  const currentPriceCur = userCur === 'USD'
    ? state.price
    : (userCur === 'PHP' ? state.price * FX : state.price * (curRate || 1));
  const currentPricePHP = state.price * FX;

  const totalCostPHP = numAmount * currentPricePHP * (1 + FEE);
  const totalProceedsPHP = numAmount * currentPricePHP * (1 - FEE);

  const totalCostCur = numAmount * currentPriceCur * (1 + FEE);
  const totalProceedsCur = numAmount * currentPriceCur * (1 - FEE);

  const handleExecute = (e: React.FormEvent) => {
    e.preventDefault();
    if (numAmount <= 0) {
      onToast('Enter a valid amount to trade', 'err');
      return;
    }

    if (tradeSide === 'buy' && state.php < totalCostPHP) {
      onToast(`Insufficient ${userCur} balance`, 'err');
      return;
    }

    if (tradeSide === 'sell' && state.flrx < numAmount) {
      onToast('Insufficient FLWRX balance', 'err');
      return;
    }

    onTrade(tradeSide, numAmount);
    setAmount('');
  };

  return (
    <div className="space-y-4 select-none">
      {/* Sub Tabs */}
      <div className="flex rounded-2xl neu-tab-bar p-1.5 text-xs font-bold gap-1.5">
        <button
          onClick={() => setActiveTab('trade')}
          className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
            activeTab === 'trade' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          Instant Swap ({pairLabel})
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
            activeTab === 'orders' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          Open Orders ({state.orders?.filter((o) => o.status === 'open').length || 0})
        </button>
      </div>

      {activeTab === 'trade' && (
        <div className="space-y-3.5 landscape:grid landscape:grid-cols-2 landscape:gap-4 landscape:space-y-0 items-start">
          {/* Left Column in Landscape: Price Action & Direction & Rates */}
          <div className="space-y-3">
            {/* Price Action Header Card */}
            <div className="p-3.5 rounded-2xl neu-flat flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase text-[var(--ink2)] block">
                  FLWRX Market Price
                </span>
                <b className="text-base sm:text-lg font-black font-mono text-[var(--ink)]">
                  ${state.price.toFixed(4)}{' '}
                  <span className="text-xs font-normal text-[var(--ink2)]">
                    (≈ {curSym}{currentPriceCur.toFixed(2)})
                  </span>
                </b>
              </div>
              <span className={`text-xs font-black font-mono px-2 py-1 rounded-lg neu-inset-sm ${chg24 >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                {chg24 >= 0 ? '+' : ''}{chg24.toFixed(2)}%
              </span>
            </div>

            {/* Trade Direction Selector */}
            <div className="flex rounded-xl neu-tab-bar p-1 text-xs font-bold gap-1">
              <button
                onClick={() => setTradeSide('buy')}
                className={`flex-1 py-2 rounded-lg transition cursor-pointer ${
                  tradeSide === 'buy' ? 'neu-tab-active' : 'neu-tab-item'
                }`}
              >
                Buy FLWRX
              </button>
              <button
                onClick={() => setTradeSide('sell')}
                className={`flex-1 py-2 rounded-lg transition cursor-pointer ${
                  tradeSide === 'sell' ? 'neu-tab-active !text-rose-700' : 'neu-tab-item'
                }`}
              >
                Sell FLWRX
              </button>
            </div>

            <div className="p-3 rounded-xl neu-inset space-y-1 text-[11px] font-mono">
              <div className="flex justify-between text-[var(--ink2)]">
                <span>Fee (0.1%):</span>
                <span>{curSym}{(numAmount * currentPriceCur * FEE).toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-[var(--ink)] pt-1 border-t border-[var(--neu-border-dark)]">
                <span>{tradeSide === 'buy' ? 'Total Cost:' : 'Estimated Receive:'}</span>
                <span>{curSym}{(tradeSide === 'buy' ? totalCostCur : totalProceedsCur).toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Right Column in Landscape: Form & CTAs */}
          <form onSubmit={handleExecute} className="p-3.5 sm:p-4 rounded-2xl neu-flat space-y-3">
            <div>
              <div className="flex items-center justify-between text-xs font-bold mb-1">
                <label className="text-[var(--ink)]">Amount (FLWRX)</label>
                <span className="text-[10px] text-[var(--ink2)] font-mono">
                  {tradeSide === 'buy' ? `Avail: ${peso(state.php, userCur)}` : `Avail: ${fmtF(state.flrx)} FLWRX`}
                </span>
              </div>
              <input
                type="number"
                min="0.01"
                step="any"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full px-3.5 py-2.5 rounded-xl neu-input text-[var(--ink)] text-sm font-mono font-bold"
              />
            </div>

            {/* Quick Percentage Chips */}
            <div className="flex gap-1.5 sm:gap-2">
              {[25, 50, 75, 100].map((pct) => (
                <button
                  type="button"
                  key={pct}
                  onClick={() => {
                    if (tradeSide === 'buy') {
                      const maxFlrx = (state.php / currentPricePHP) * 0.999;
                      setAmount(r4(maxFlrx * (pct / 100)).toString());
                    } else {
                      setAmount(r4(state.flrx * (pct / 100)).toString());
                    }
                  }}
                  className="flex-1 py-1 rounded-lg neu-tab-item text-[10px] font-bold cursor-pointer"
                >
                  {pct}%
                </button>
              ))}
            </div>

            <button
              type="submit"
              className={`w-full py-2.5 sm:py-3 rounded-xl font-extrabold text-sm cursor-pointer shadow-xs transition ${
                tradeSide === 'buy' ? 'neu-btn-accent' : 'neu-btn text-rose-700'
              }`}
            >
              Confirm {tradeSide === 'buy' ? 'Purchase' : 'Sale'}
            </button>
          </form>
        </div>
      )}

      {activeTab === 'orders' && (
        <div className="p-4 rounded-2xl neu-flat space-y-3">
          {(!state.orders || state.orders.length === 0) ? (
            <p className="text-xs text-[var(--ink2)] text-center py-6">
              No active or past trade orders yet.
            </p>
          ) : (
            <div className="space-y-2">
              {state.orders.map((o) => (
                <div key={o.id} className="p-3 rounded-xl neu-inset flex items-center justify-between text-xs">
                  <div>
                    <span className={`font-bold uppercase ${o.side === 'buy' ? 'text-emerald-600' : 'text-rose-600'}`}>
                      {o.side} {o.amt} FLWRX
                    </span>
                    <span className="block text-[10px] text-[var(--ink2)] font-mono">
                      @ ${o.price.toFixed(4)} ({o.type})
                    </span>
                  </div>
                  {o.status === 'open' && (
                    <button
                      onClick={() => onCancelOrder(o.id)}
                      className="px-2.5 py-1 rounded-lg neu-btn text-rose-500 font-bold text-[10px] cursor-pointer"
                    >
                      Cancel
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
