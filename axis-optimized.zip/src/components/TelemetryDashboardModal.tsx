import React, { useState } from 'react';

export const TelemetryDashboardModal: React.FC = () => {
  const [selectedIssue, setSelectedIssue] = useState<string | null>(null);

  const topIssues = [
    {
      id: 'issue-1',
      title: 'Checkout crash on Android 12',
      impact: '312 users · new in v1.0.1',
      status: 'Fixed same day (v1.0.2)',
      severity: 'high',
      details: 'Race condition during biometric intent handshake. Guarded with fallback PIN verification and timeout cancellation.'
    },
    {
      id: 'issue-2',
      title: 'Sync API timing out',
      impact: '88 users · dropped from 6.2s to 0.02s',
      status: 'Optimized index',
      severity: 'medium',
      details: 'Sub-millisecond query caching and hash-indexed lookups lowered p95 search latency to near-instant 0.02 seconds.'
    },
    {
      id: 'issue-3',
      title: '41% drop-off at signup step 3',
      impact: 'Onboarding funnel friction',
      status: 'Redesigned (Principle #4)',
      severity: 'low',
      details: 'Continue button was shifting position on compact keyboards. Anchored to static thumb zone, dropping exit rate to under 4%.'
    },
    {
      id: 'issue-4',
      title: 'Slow cold start on older devices',
      impact: '3.8 s perceived stall on Android Go',
      status: 'Replaced with Skeletons',
      severity: 'low',
      details: 'Replaced generic spinning wheel with layout-matching skeleton shimmers, providing instant layout cognition.'
    },
    {
      id: 'issue-5',
      title: 'Proof of Flower (PoF) Node Scaling Latency',
      impact: 'Tier 1-11 (100 to 500M nodes) quorum',
      status: 'p95 0.02s verified',
      severity: 'low',
      details: 'Decentralized nodes confirm broadcasted Passkeys with >=50% quorum. 100% single-use burn rate achieved.'
    }
  ];

  return (
    <div className="space-y-4 select-none">
      {/* Top Banner Tag */}
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-extrabold font-mono uppercase bg-black text-white px-2.5 py-1 rounded-md">
          DAY 12 AFTER LAUNCH
        </span>
        <span className="text-xs font-mono font-bold text-emerald-700 dark:text-emerald-400">
          ● 99.98% Crash-Free Sessions
        </span>
      </div>

      {/* Main Grid: Crash Rate Chart & Top Issues */}
      <div className="p-4 rounded-3xl neu-flat space-y-4 border border-[var(--neu-border-dark)]">
        {/* 1. Crash Rate Visual Chart */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-extrabold">
            <span className="text-[var(--ink)]">Crash rate</span>
            <span className="text-[10px] text-[var(--ink2)] font-mono">% of sessions, first 12 days</span>
          </div>

          <div className="p-4 rounded-2xl neu-inset relative h-40 flex flex-col justify-between overflow-hidden">
            {/* SVG Trend Line Graph */}
            <svg className="w-full h-full overflow-visible" viewBox="0 0 300 100" preserveAspectRatio="none">
              {/* Grid Lines */}
              <line x1="0" y1="25" x2="300" y2="25" stroke="rgba(0,0,0,0.06)" strokeDasharray="3 3" />
              <line x1="0" y1="65" x2="300" y2="65" stroke="rgba(0,0,0,0.06)" strokeDasharray="3 3" />

              {/* Version separator lines */}
              <line x1="100" y1="0" x2="100" y2="100" stroke="rgba(0,0,0,0.12)" strokeDasharray="2 2" />
              <line x1="180" y1="0" x2="180" y2="100" stroke="rgba(0,0,0,0.12)" strokeDasharray="2 2" />

              {/* Crash Rate Curve: v1.0 -> Spike at v1.0.1 -> Plunge to v1.0.2 */}
              <path
                d="M 10 82 Q 70 80 95 72 L 135 24 L 175 78 Q 240 84 290 85"
                fill="none"
                stroke="#143012"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Spike Point Marker: Caught in 40 min */}
              <circle cx="135" cy="24" r="5" fill="#dc2626" className="animate-pulse" />

              {/* Recovery Point Marker: Fixed same day */}
              <circle cx="175" cy="78" r="4" fill="#16a34a" />
            </svg>

            {/* Interactive Callout Badges on the Chart */}
            <div className="absolute top-2 left-[40%] bg-rose-600 text-white text-[9px] font-black px-2 py-0.5 rounded-md shadow-sm">
              Caught in 40 min
            </div>
            <div className="absolute bottom-6 right-[30%] bg-emerald-700 text-white text-[9px] font-black px-2 py-0.5 rounded-md shadow-sm">
              Fixed same day
            </div>

            {/* X-axis version tags */}
            <div className="flex justify-between text-[10px] font-mono text-[var(--ink2)] pt-2 border-t border-[var(--neu-border-dark)]">
              <span>v1.0 (Launch)</span>
              <span>v1.0.1 (Incident)</span>
              <span>v1.0.2 (Hardened)</span>
            </div>
          </div>
        </div>

        {/* 2. Top issues this week list */}
        <div className="space-y-2 pt-1 border-t border-[var(--neu-border-dark)]">
          <h4 className="text-xs font-black uppercase tracking-wider text-[var(--ink)]">
            Top issues this week
          </h4>

          <div className="space-y-2">
            {topIssues.map((issue) => (
              <div
                key={issue.id}
                role="button"
                tabIndex={0}
                onClick={() => setSelectedIssue(selectedIssue === issue.id ? null : issue.id)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') setSelectedIssue(selectedIssue === issue.id ? null : issue.id);
                }}
                className="p-3 rounded-2xl neu-inset text-xs space-y-1.5 cursor-pointer transition hover:bg-black/5"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                        issue.severity === 'high'
                          ? 'bg-rose-500'
                          : issue.severity === 'medium'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                    />
                    <b className="text-[var(--ink)] font-bold">{issue.title}</b>
                  </div>
                  <span className="text-[10px] font-mono font-bold text-emerald-700 dark:text-emerald-400 shrink-0">
                    {issue.status}
                  </span>
                </div>

                <div className="text-[11px] text-[var(--ink2)] font-mono pl-4.5">
                  {issue.impact}
                </div>

                {selectedIssue === issue.id && (
                  <div className="p-2.5 mt-2 rounded-xl bg-black/5 text-[11px] text-[var(--ink)] leading-relaxed pl-4.5 animate-fade-in">
                    {issue.details}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Philosophy Quote Box from Image #6 */}
      <div className="p-4 rounded-2xl neu-flat text-xs space-y-1.5 text-[var(--ink2)] leading-relaxed">
        <b className="text-[var(--ink)] text-xs block">Engineering Reality:</b>
        <p>
          &ldquo;A real app isn&apos;t finished when you publish it to the App Store. We actively look at crash tracking, errors, performance, and user behavior so we can see what&apos;s going wrong and improve the product once real people start using it.&rdquo;
        </p>
      </div>
    </div>
  );
};
