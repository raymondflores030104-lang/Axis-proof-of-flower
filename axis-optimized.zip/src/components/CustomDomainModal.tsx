import React, { useState } from 'react';
import { Globe, CheckCircle2, ShieldCheck, Copy } from 'lucide-react';
import { copyText } from '../utils';

interface CustomDomainModalProps {
  onClose?: () => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const CustomDomainModal: React.FC<CustomDomainModalProps> = ({ onToast }) => {
  const [domainInput, setDomainInput] = useState('');
  const [verifiedDomain, setVerifiedDomain] = useState<string | null>(null);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!domainInput.includes('.')) {
      onToast('Enter a valid domain name (e.g., scan.mybrand.com)', 'err');
      return;
    }
    setVerifiedDomain(domainInput);
    onToast(`CNAME Record generated for ${domainInput}`, 'good');
  };

  return (
    <div className="space-y-4 select-none">
      <div className="p-4 rounded-2xl neu-flat space-y-2">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-emerald-600" />
          <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink)]">
            Custom Brand Domain &amp; White-label
          </h4>
        </div>
        <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
          Enterprise retail partners can connect custom hostnames to serve this Proof-of-Scan portal under their branded web address.
        </p>
      </div>

      <form onSubmit={handleVerify} className="p-4 rounded-2xl neu-flat space-y-3">
        <div className="space-y-1">
          <label className="text-xs font-bold text-[var(--ink)] block">Custom Domain</label>
          <input
            type="text"
            required
            value={domainInput}
            onChange={(e) => setDomainInput(e.target.value)}
            placeholder="rewards.yourbrand.ph"
            className="w-full px-3.5 py-2.5 rounded-xl neu-input text-xs font-mono text-[var(--ink)]"
          />
        </div>

        <button
          type="submit"
          className="w-full py-2.5 rounded-xl neu-btn-accent font-extrabold text-xs cursor-pointer shadow-xs"
        >
          Generate DNS Records
        </button>
      </form>

      {verifiedDomain && (
        <div className="p-3.5 rounded-2xl neu-inset space-y-2 text-xs font-mono">
          <div className="flex justify-between items-center text-[var(--ink)] font-bold">
            <span>CNAME Target:</span>
            <span className="text-emerald-600">cname.axis.network</span>
          </div>
          <p className="text-[10px] text-[var(--ink2)] font-sans">
            Add this DNS record with your domain registrar. SSL will provision automatically within 15 minutes.
          </p>
        </div>
      )}
    </div>
  );
};
