import React from 'react';
import { AxisState } from '../types';
import { COMPANIES, Company } from '../constants';
import { Building2, Sparkles, Camera } from 'lucide-react';

interface CompaniesModalProps {
  state: AxisState;
  sponsoredCompany: Company;
  onOpenScanner: () => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const CompaniesModal: React.FC<CompaniesModalProps> = ({
  state,
  sponsoredCompany,
  onOpenScanner
}) => {
  return (
    <div className="space-y-4 select-none">
      {/* Featured Partner Banner */}
      <div className="p-4 rounded-2xl neu-flat bg-gradient-to-br from-emerald-600/10 to-teal-600/10 border border-emerald-500/20 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md neu-tab-active">
            Featured Brand Today
          </span>
          <span className="text-xs font-black text-emerald-600 dark:text-emerald-400 font-mono">
            +{sponsoredCompany.flrxPerScan} FLWRX / Scan
          </span>
        </div>
        <b className="block text-base font-extrabold text-[var(--ink)]">
          {sponsoredCompany.name}
        </b>
        <p className="text-xs text-[var(--ink2)] leading-relaxed">
          {sponsoredCompany.banner}
        </p>
        <button
          onClick={onOpenScanner}
          className="w-full py-2.5 rounded-xl neu-btn-accent font-extrabold text-xs flex items-center justify-center gap-1.5 cursor-pointer mt-1 shadow-xs"
        >
          <Camera className="w-4 h-4" />
          <span>Scan {sponsoredCompany.name} Products</span>
        </button>
      </div>

      {/* Full Brand Directory */}
      <div className="space-y-2.5">
        <h4 className="text-xs font-extrabold uppercase tracking-wider text-[var(--ink2)]">
          All Participating FMCG Partners ({COMPANIES.length})
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 landscape:grid-cols-2 gap-2.5">
          {COMPANIES.map((c) => {
            const scansCount = state.everCompanies?.[c.id] || 0;

            return (
              <div key={c.id} className="p-3.5 rounded-2xl neu-flat flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl neu-inset flex items-center justify-center text-emerald-600 font-bold shrink-0">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <b className="text-xs font-bold block text-[var(--ink)]">{c.name}</b>
                    <span className="text-[10px] text-[var(--ink2)] block font-mono">
                      Category: {c.cat} · Reward: {c.flrxPerScan} FLWRX
                    </span>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded-md neu-inset-sm text-emerald-600">
                    {scansCount} Scans
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
