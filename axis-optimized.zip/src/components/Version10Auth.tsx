import React, { useState } from 'react';
import { Mail, Lock, Eye, EyeOff, User, ArrowRight, ShieldCheck, Check, Sparkles, KeyRound } from 'lucide-react';

interface Version10AuthProps {
  onSuccess: (userData: { name: string; email: string; isNewUser?: boolean }) => void;
  defaultEmail?: string;
  defaultName?: string;
}

export const Version10Auth: React.FC<Version10AuthProps> = ({
  onSuccess,
  defaultEmail = '',
  defaultName = ''
}) => {
  const [mode, setMode] = useState<'signin' | 'register' | 'forgot'>('signin');
  const [email, setEmail] = useState(defaultEmail || '');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState(defaultName || '');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [agreeTerms, setAgreeTerms] = useState(true);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const validateEmail = (val: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val.trim());
  };

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanEmail = email.trim();
    if (!cleanEmail) {
      setErrorMsg('Please enter your email address');
      return;
    }
    if (!validateEmail(cleanEmail)) {
      setErrorMsg('Please enter a valid email address');
      return;
    }
    if (!password) {
      setErrorMsg('Please enter your password');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onSuccess({
        name: name.trim() || cleanEmail.split('@')[0],
        email: cleanEmail,
        isNewUser: false
      });
    }, 600);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanName = name.trim();
    const cleanEmail = email.trim();

    if (!cleanName || cleanName.length < 2) {
      setErrorMsg('Please enter your full name or miner alias');
      return;
    }
    if (!cleanEmail || !validateEmail(cleanEmail)) {
      setErrorMsg('Please enter a valid email address');
      return;
    }
    if (!password || password.length < 6) {
      setErrorMsg('Password must be at least 6 characters');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match');
      return;
    }
    if (!agreeTerms) {
      setErrorMsg('You must agree to the Terms & Privacy Policy');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onSuccess({
        name: cleanName,
        email: cleanEmail,
        isNewUser: true
      });
    }, 700);
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanEmail = email.trim();
    if (!cleanEmail || !validateEmail(cleanEmail)) {
      setErrorMsg('Please enter a valid email to receive reset instructions');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSuccessNotice(`Password reset instructions dispatched to ${cleanEmail}`);
    }, 650);
  };

  const handleInstantAnchorLogin = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onSuccess({
        name: 'Citizen Miner',
        email: 'miner@axis.network',
        isNewUser: false
      });
    }, 350);
  };

  return (
    <div className="fixed inset-0 z-40 flex flex-col items-center justify-start sm:justify-center p-4 sm:p-6 bg-black/45 overflow-y-auto select-none safe-pad-top safe-pad-bottom safe-pad-left safe-pad-right">
      <div className="relative w-full max-w-md my-auto py-5 sm:py-6 px-5 sm:p-8 rounded-3xl neu-sheet shadow-2xl animate-modal-pop border border-[var(--glass-border-card)]">
        {/* Top Brand Logo & App Identity */}
        <div className="text-center mb-4 sm:mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-2xl p-1 mb-2 sm:mb-3 bg-[#F8F7F2] border border-emerald-500/20 shadow-md">
            <img
              src="/pwa-192x192.png"
              alt="Axis Teraxiom Logo"
              className="w-full h-full object-contain rounded-xl"
            />
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-[var(--ink)] font-brand">
            {mode === 'forgot'
              ? 'Reset Password'
              : mode === 'register'
              ? 'Create Account'
              : 'Welcome Back'}
          </h2>
          <p className="text-[11px] sm:text-xs text-[var(--ink2)] mt-0.5 sm:mt-1 font-medium max-w-xs mx-auto">
            {mode === 'forgot'
              ? 'Enter your email to receive recovery instructions.'
              : mode === 'register'
              ? 'Join Teraxiom Axis to mine FLRX and earn real-world rewards.'
              : 'Sign in to access your Proof of Flower node & FLRX wallet.'}
          </p>
        </div>

        {/* Tab Switcher for Sign In vs Register (Version 10 Header Control) */}
        {mode !== 'forgot' && (
          <div className="flex rounded-2xl neu-tab-bar p-1.5 mb-4 sm:mb-6 text-xs font-bold gap-1.5 bg-black/5 dark:bg-white/5">
            <button
              type="button"
              onClick={() => {
                setMode('signin');
                setErrorMsg(null);
                setSuccessNotice(null);
              }}
              className={`flex-1 py-2.5 rounded-xl transition cursor-pointer text-center font-bold ${
                mode === 'signin' ? 'neu-tab-active shadow-sm' : 'neu-tab-item opacity-80'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setErrorMsg(null);
                setSuccessNotice(null);
              }}
              className={`flex-1 py-2.5 rounded-xl transition cursor-pointer text-center font-bold ${
                mode === 'register' ? 'neu-tab-active shadow-sm' : 'neu-tab-item opacity-80'
              }`}
            >
              Register
            </button>
          </div>
        )}

        {/* Inline Error Message */}
        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Inline Success Message */}
        {successNotice && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>{successNotice}</span>
          </div>
        )}

        {/* 1. SIGN IN FORM */}
        {mode === 'signin' && (
          <form onSubmit={handleSignIn} className="space-y-4 text-xs">
            <div className="space-y-1.5">
              <label className="block font-bold text-[var(--ink)]">Email Address</label>
              <div className="relative flex items-center">
                <Mail className="absolute left-3.5 w-4 h-4 text-[var(--ink2)] pointer-events-none" />
                <input
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-3.5 py-3 rounded-xl neu-input text-[var(--ink)] text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="font-bold text-[var(--ink)]">Password</label>
                <button
                  type="button"
                  onClick={() => {
                    setMode('forgot');
                    setErrorMsg(null);
                    setSuccessNotice(null);
                  }}
                  className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline cursor-pointer"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative flex items-center">
                <Lock className="absolute left-3.5 w-4 h-4 text-[var(--ink2)] pointer-events-none" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-11 py-3 rounded-xl neu-input text-[var(--ink)] text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 text-[var(--ink2)] hover:text-[var(--ink)] cursor-pointer p-1"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between py-1">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 accent-emerald-600 cursor-pointer"
                />
                <span className="font-semibold text-[var(--ink2)]">Remember me</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl neu-btn-accent font-extrabold text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Sign In</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* 2. REGISTRATION FORM */}
        {mode === 'register' && (
          <form onSubmit={handleRegister} className="space-y-3.5 text-xs">
            <div className="space-y-1">
              <label className="block font-bold text-[var(--ink)]">Full Name</label>
              <div className="relative flex items-center">
                <User className="absolute left-3.5 w-4 h-4 text-[var(--ink2)] pointer-events-none" />
                <input
                  type="text"
                  required
                  autoComplete="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Juan Dela Cruz"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl neu-input text-[var(--ink)] text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block font-bold text-[var(--ink)]">Email Address</label>
              <div className="relative flex items-center">
                <Mail className="absolute left-3.5 w-4 h-4 text-[var(--ink2)] pointer-events-none" />
                <input
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="miner@domain.com"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl neu-input text-[var(--ink)] text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block font-bold text-[var(--ink)]">Password</label>
              <div className="relative flex items-center">
                <Lock className="absolute left-3.5 w-4 h-4 text-[var(--ink2)] pointer-events-none" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="new-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min. 6 characters"
                  className="w-full pl-10 pr-11 py-2.5 rounded-xl neu-input text-[var(--ink)] text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 text-[var(--ink2)] hover:text-[var(--ink)] cursor-pointer p-1"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <label className="block font-bold text-[var(--ink)]">Confirm Password</label>
              <div className="relative flex items-center">
                <Lock className="absolute left-3.5 w-4 h-4 text-[var(--ink2)] pointer-events-none" />
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  required
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter password"
                  className="w-full pl-10 pr-11 py-2.5 rounded-xl neu-input text-[var(--ink)] text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3.5 text-[var(--ink2)] hover:text-[var(--ink)] cursor-pointer p-1"
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <label className="flex items-start gap-2 cursor-pointer select-none pt-1">
              <input
                type="checkbox"
                checked={agreeTerms}
                onChange={(e) => setAgreeTerms(e.target.checked)}
                className="w-4 h-4 mt-0.5 rounded text-emerald-600 focus:ring-emerald-500 accent-emerald-600 cursor-pointer"
              />
              <span className="text-[11px] text-[var(--ink2)] leading-tight">
                I agree to Teraxiom's <span className="font-bold underline text-[var(--ink)]">Terms of Service</span> and <span className="font-bold underline text-[var(--ink)]">Privacy Policy</span>.
              </span>
            </label>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl neu-btn-accent font-extrabold text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98] mt-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Create Axis Account</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* 3. FORGOT PASSWORD VIEW */}
        {mode === 'forgot' && (
          <form onSubmit={handleForgotSubmit} className="space-y-4 text-xs">
            <div className="space-y-1.5">
              <label className="block font-bold text-[var(--ink)]">Account Email</label>
              <div className="relative flex items-center">
                <Mail className="absolute left-3.5 w-4 h-4 text-[var(--ink2)] pointer-events-none" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-3.5 py-3 rounded-xl neu-input text-[var(--ink)] text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl neu-btn-accent font-extrabold text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <span>Send Reset Link</span>
              )}
            </button>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => {
                  setMode('signin');
                  setErrorMsg(null);
                  setSuccessNotice(null);
                }}
                className="text-xs font-bold text-[var(--ink2)] hover:text-[var(--ink)] cursor-pointer"
              >
                ← Back to Sign In
              </button>
            </div>
          </form>
        )}

        {/* Social / Instant Passkey Sign-in Alternatives */}
        {mode !== 'forgot' && (
          <div className="mt-6 pt-5 border-t border-[var(--neu-border-dark)]">
            <div className="text-center mb-3">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--ink2)]">
                Or Continue With
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 mb-2.5">
              <button
                type="button"
                onClick={() => {
                  setLoading(true);
                  setTimeout(() => {
                    setLoading(false);
                    onSuccess({
                      name: 'Google Miner',
                      email: 'google.miner@axis.network',
                      isNewUser: false
                    });
                  }, 400);
                }}
                className="py-2.5 px-3 rounded-xl neu-btn font-bold text-xs flex items-center justify-center gap-2 text-[var(--ink)] cursor-pointer hover:opacity-90 active:scale-95"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Google</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setLoading(true);
                  setTimeout(() => {
                    setLoading(false);
                    onSuccess({
                      name: 'Apple Miner',
                      email: 'apple.miner@axis.network',
                      isNewUser: false
                    });
                  }, 400);
                }}
                className="py-2.5 px-3 rounded-xl neu-btn font-bold text-xs flex items-center justify-center gap-2 text-[var(--ink)] cursor-pointer hover:opacity-90 active:scale-95"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.66-.82 1.11-1.96.99-3.1-.96.04-2.12.65-2.8 1.45-.6.69-1.12 1.83-.98 2.94 1.08.08 2.14-.54 2.79-1.29z" />
                </svg>
                <span>Apple</span>
              </button>
            </div>

            {/* Instant Citizen Anchor Login */}
            <button
              type="button"
              onClick={handleInstantAnchorLogin}
              className="w-full py-2.5 px-3 rounded-xl neu-inset-sm font-bold text-xs flex items-center justify-center gap-2 text-emerald-600 dark:text-emerald-400 cursor-pointer hover:brightness-105 active:scale-95 transition"
              title="One-tap bypass using local device cryptographic Passkey Anchor"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Continue as Citizen Passkey (One-Tap Anchor)</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
