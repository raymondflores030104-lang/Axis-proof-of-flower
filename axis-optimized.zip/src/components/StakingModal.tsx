import React, { useState } from 'react';
import { AxisState, StakePosition } from '../types';
import { STAKING_TIERS } from '../constants';
import { fmtF } from '../utils';
import { Lock, Percent, CheckCircle2, ArrowUpRight, Clock, ShieldCheck } from 'lucide-react';

interface StakingModalProps {
  state: AxisState;
  onStake: (amount: number, lockIndex: number) => void;
  onUnstake: (id: string) => void;
  onClaimYield?: (id: string) => void;
  onClaimAll?: () => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const StakingModal: React.FC<StakingModalProps> = ({
  state,
  onStake,
  onUnstake,
  onClaimYield,
  onClaimAll,
  onToast
}) => {
  const [stakeAmount, setStakeAmount] = useState('');
  const [lockTier, setLockTier] = useState(0);

  const handleStakeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(stakeAmount) || 0;
    if (val <= 0) {
      onToast('Enter a valid amount to stake', 'err');
      return;
    }
    if (state.flrx < val) {
      onToast('Insufficient FLWRX balance', 'err');
      return;
    }

    onStake(val, lockTier);
    setStakeAmount('');
  };

  const now = Date.now();

  return (
    <div className="space-y-3.5 select-none">
      <div className="landscape:grid landscape:grid-cols-2 landscape:gap-4 md:landscape:gap-5 items-start space-y-3.5 landscape:space-y-0">
        {/* Left Column in Landscape: Staking Form */}
        <div className="space-y-3">
          {/* Staking Form */}
          <form onSubmit={handleStakeSubmit} className="p-3.5 sm:p-4 rounded-2xl neu-flat space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-extrabold uppercase tracking-wider text-[var(--ink2)]">
            Stake FLWRX to Earn Yield
          </h4>
          <span className="text-[10px] font-mono font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            Teraxiom Node Security
          </span>
        </div>

        {/* Lock Duration Selector */}
        <div className="grid grid-cols-4 gap-1.5">
          {STAKING_TIERS.map((t, idx) => (
            <button
              key={t.label}
              type="button"
              onClick={() => setLockTier(idx)}
              className={`p-2 rounded-xl text-center cursor-pointer transition ${
                lockTier === idx ? 'neu-tab-active font-extrabold' : 'neu-tab-item'
              }`}
            >
              <span className="text-[10px] font-bold block">{t.label}</span>
              <span className="text-[11px] font-black font-mono block">{t.apyLabel}</span>
            </button>
          ))}
        </div>

        <div>
          <div className="flex justify-between items-center text-xs font-bold mb-1">
            <label className="text-[var(--ink)]">Amount to Stake</label>
            <button
              type="button"
              onClick={() => setStakeAmount(state.flrx.toString())}
              className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
            >
              Max: {fmtF(state.flrx)}
            </button>
          </div>
          <input
            type="number"
            min="0.1"
            step="any"
            required
            value={stakeAmount}
            onChange={(e) => setStakeAmount(e.target.value)}
            placeholder="0.00"
            className="w-full px-3.5 py-2.5 rounded-xl neu-input text-sm font-bold font-mono text-[var(--ink)]"
          />
        </div>

        <button
          type="submit"
          className="w-full py-3 rounded-xl neu-btn-accent font-extrabold text-xs cursor-pointer shadow-xs transition"
        >
          Confirm Staking ({STAKING_TIERS[lockTier].apyLabel})
        </button>
      </form>
        </div>

        {/* Right Column in Landscape: Vault Balance Overview & Active Positions */}
        <div className="space-y-3">
          {/* Vault Balance Overview */}
          <div className="p-3 sm:p-3.5 rounded-2xl neu-flat flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase text-[var(--ink2)] block">
                Total Staked in Vault
              </span>
              <b className="text-base sm:text-lg font-black font-mono text-emerald-600 dark:text-emerald-400">
                {fmtF(state.staked || 0)} FLWRX
              </b>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-bold uppercase text-[var(--ink2)] block">
                Liquid FLWRX
              </span>
              <b className="text-xs sm:text-sm font-bold font-mono text-[var(--ink)]">
                {fmtF(state.flrx)} FLWRX
              </b>
            </div>
          </div>

          {/* Active Stakes List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-extrabold uppercase tracking-wider text-[var(--ink2)]">
                Active Staking Positions ({state.stakes?.length || 0})
              </h4>
              {state.stakes && state.stakes.length > 1 && onClaimAll && (
                <button
                  type="button"
                  onClick={onClaimAll}
                  className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 cursor-pointer hover:underline"
                >
                  Claim All Yield
                </button>
              )}
            </div>

            {(!state.stakes || state.stakes.length === 0) ? (
              <p className="text-xs text-[var(--ink2)] text-center py-4 neu-inset rounded-xl">
                No active positions. Stake FLRX to begin earning passive protocol yield.
              </p>
            ) : (
              state.stakes.map((pos) => {
                const lockDays = pos.lockDays ?? pos.d ?? 0;
                const unlockTimestamp = pos.start + lockDays * 86400000;
                const isUnlocked = lockDays === 0 || now >= unlockTimestamp;
                const apyPct = (pos.apy * 100).toFixed(0);

                // Compute pending yield estimate
                const elapsedDays = Math.max(0, (now - (pos.lastClaim || pos.start)) / (1000 * 60 * 60 * 24));
                const estPendingYield = pos.amount * pos.apy * (elapsedDays / 365);

                return (
                  <div key={pos.id} className="p-3.5 rounded-xl neu-inset space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <div>
                        <b className="text-[var(--ink)] font-mono text-sm block">
                          {pos.amount} FLWRX Staked
                        </b>
                        <span className="text-[10px] text-[var(--ink2)] font-mono flex items-center gap-1.5 mt-0.5">
                          <Clock className="w-3 h-3 text-emerald-600" />
                          {lockDays === 0 ? 'Flexible' : `${lockDays}d Lock`} · {apyPct}% APY
                          {pos.claimed > 0 && ` · Claimed: +${pos.claimed.toFixed(4)}`}
                        </span>
                      </div>

                      <div className="text-right">
                        <span className="text-[9px] uppercase font-bold text-[var(--ink2)] block">
                          Earned Yield
                        </span>
                        <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                          +{estPendingYield.toFixed(4)} FLWRX
                        </span>
                      </div>
                    </div>

                    {/* Actions: Claim Yield & Unstake */}
                    <div className="flex gap-2 pt-1 border-t border-[var(--neu-border-dark)]">
                      <button
                        type="button"
                        onClick={() => onClaimYield && onClaimYield(pos.id)}
                        className="flex-1 py-1.5 px-2 rounded-lg neu-tab-item text-[11px] font-bold text-emerald-600 dark:text-emerald-400 cursor-pointer text-center"
                      >
                        Claim Yield
                      </button>

                      <button
                        type="button"
                        onClick={() => onUnstake(pos.id)}
                        disabled={!isUnlocked}
                        className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-bold transition text-center cursor-pointer ${
                          isUnlocked
                            ? 'neu-btn text-[var(--ink)] hover:text-rose-600'
                            : 'opacity-40 neu-inset cursor-not-allowed text-[var(--ink2)]'
                        }`}
                      >
                        {isUnlocked ? 'Unstake' : `Locked (${Math.ceil((unlockTimestamp - now) / 86400000)}d left)`}
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
