import React, { useState } from 'react';
import { POF_NODE_TIERS, POF_TOKENOMICS } from '../terraPofEngine';

export interface WhitepaperModalProps {
  onToast?: (msg: string, type?: 'good' | 'err') => void;
  onOpenArchitecture?: () => void;
}

export const WhitepaperModal: React.FC<WhitepaperModalProps> = ({ onToast, onOpenArchitecture }) => {
  const [activeSection, setActiveSection] = useState<'abstract' | 'engine' | 'tokenomics' | 'security' | 'pitch'>('abstract');

  return (
    <div className="space-y-4 select-none">
      <div className="flex rounded-2xl neu-tab-bar p-1.5 text-xs font-bold gap-1.5 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveSection('abstract')}
          className={`flex-1 py-1.5 px-2 rounded-xl transition cursor-pointer text-[11px] whitespace-nowrap ${
            activeSection === 'abstract' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          1. Yin-Yang Duality
        </button>
        <button
          onClick={() => setActiveSection('engine')}
          className={`flex-1 py-1.5 px-2 rounded-xl transition cursor-pointer text-[11px] whitespace-nowrap ${
            activeSection === 'engine' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          2. Proof of Flower
        </button>
        <button
          onClick={() => setActiveSection('tokenomics')}
          className={`flex-1 py-1.5 px-2 rounded-xl transition cursor-pointer text-[11px] whitespace-nowrap ${
            activeSection === 'tokenomics' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          3. Tokenomics
        </button>
        <button
          onClick={() => setActiveSection('security')}
          className={`flex-1 py-1.5 px-2 rounded-xl transition cursor-pointer text-[11px] whitespace-nowrap ${
            activeSection === 'security' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          4. Anti-Bot & Lock
        </button>
        <button
          onClick={() => setActiveSection('pitch')}
          className={`flex-1 py-1.5 px-2 rounded-xl transition cursor-pointer text-[11px] whitespace-nowrap ${
            activeSection === 'pitch' ? 'neu-tab-active' : 'neu-tab-item'
          }`}
        >
          5. 15-Min Pitch Script
        </button>
      </div>

      <div className="p-4 rounded-2xl neu-flat space-y-3 max-h-[60vh] overflow-y-auto">
        {activeSection === 'abstract' && (
          <div className="space-y-2 text-xs leading-relaxed text-[var(--ink)]">
            <h4 className="font-extrabold text-sm text-emerald-600 dark:text-emerald-400">
              The Yin-Yang System Architecture (Teraxiom vs. Axis)
            </h4>
            <p>
              This decentralized ecosystem operates on a strict Yin-Yang duality bridging physical recycled consumer goods to digital liquid value:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-[var(--ink2)]">
              <li>
                <strong>The White Side (Yang) — The Teraxiom Blockchain Website:</strong> Creates the Flower Codes (with embedded PHP/FLWRXCOIN values), manages business transparency, and automatically broadcasts the cryptographic Passkeys / Target Flower Code Hashes to decentralized nodes.
              </li>
              <li>
                <strong>The Black Side (Yin) — This Axis Application &amp; Decentralized Nodes:</strong> Receives the broadcasted Passkeys and targets. The Axis App and its decentralized nodes exist to FIND, MATCH, and VERIFY those Flower Codes in the physical world when consumers scan recycled packaging.
              </li>
            </ul>
            <p className="text-[var(--ink2)]">
              <strong>Application-First Doctrine:</strong> The Axis App is the primary identity anchor. A user must register and generate their official cryptographic keypair inside this Axis App first before linking with the Teraxiom Website.
            </p>
          </div>
        )}

        {activeSection === 'engine' && (
          <div className="space-y-2 text-xs leading-relaxed text-[var(--ink)]">
            <h4 className="font-extrabold text-sm text-emerald-600 dark:text-emerald-400">
              Proof of Flower (PoF) Consensus &amp; 11-Tier Node Scaling
            </h4>
            <p>
              Consensus Law: <em>&ldquo;More FLWRXCOIN minted = less waste pollution and more flowers blooming in nature.&rdquo;</em>
            </p>
            <p className="text-[var(--ink2)]">
              Flower Codes scale dynamically across 11 tiers from 28 to 98 digits in steps of +7. Every scan queries the decentralized nodes to verify against broadcasted Passkeys, requiring &gt;= 50% node quorum:
            </p>
            <div className="p-3 rounded-xl neu-inset space-y-1 font-mono text-[10px] text-[var(--ink2)]">
              <div>• Tier 1: 28 digits → 100 Nodes (50 required)</div>
              <div>• Tier 2: 35 digits → 350 Nodes (175 required)</div>
              <div>• Tier 3: 42 digits → 1,200 Nodes (600 required)</div>
              <div>• Tier 4: 49 digits → 4,500 Nodes (2,250 required)</div>
              <div>• Tier 5: 56 digits → 15,000 Nodes (7,500 required)</div>
              <div>• Tier 6: 63 digits → 55,000 Nodes (27,500 required)</div>
              <div>• Tier 7: 70 digits → 200,000 Nodes (100,000 required)</div>
              <div>• Tier 8: 77 digits → 700,000 Nodes (350,000 required)</div>
              <div>• Tier 9: 84 digits → 2,500,000 Nodes (1,250,000 required)</div>
              <div>• Tier 10: 91 digits → 5,000,000 Nodes (2,500,000 required)</div>
              <div>• Tier 11: 98 digits → 500,000,000 Nodes (250,000,000 required)</div>
            </div>
            <p className="text-[var(--ink2)]">
              Once verified, the Passkey is permanently burned, enforcing an absolute single-use double-spend prohibition.
            </p>
          </div>
        )}

        {activeSection === 'tokenomics' && (
          <div className="space-y-2 text-xs leading-relaxed text-[var(--ink)]">
            <h4 className="font-extrabold text-sm text-emerald-600 dark:text-emerald-400">
              Tokenomics, Dual-Unit Precision &amp; Halving
            </h4>
            <div className="space-y-1 text-[var(--ink2)]">
              <p>
                <strong>Supply Cap:</strong> 10,000,000 (10M) FLWRXCOIN Total Cap.
              </p>
              <ul className="list-disc pl-5 space-y-0.5">
                <li>9,000,000 (9M) Circulating User Mining Pool (90%).</li>
                <li>1,000,000 (1M) TERRA Company Reserve (10% Eternal Lock).</li>
              </ul>
              <p>
                <strong>Base Rate:</strong> PHP 0.50 = 0.00000100 FLWRXCOIN (8-decimal precision: 1 PHP = 0.00000200 FLWRXCOIN).
              </p>
              <p>
                <strong>Dual-Unit System:</strong> Every scan yields both:
                <br />
                1) <em>Exact PHP Value:</em> Fixed (PHP 0.50 to PHP 50.00) anchored to the physical packaging budget. Never halves.
                <br />
                2) <em>FLWRXCOIN:</em> Follows the 4-Year (1,460-day) Halving Schedule.
              </p>
              <p>
                <strong>2-Year (730-day) Batch Expiration Rule:</strong> Unredeemed Passkeys older than 730 days expire permanently; remaining escrow splits 50/50 between the manufacturer and system reserve.
              </p>
            </div>
          </div>
        )}

        {activeSection === 'security' && (
          <div className="space-y-2 text-xs leading-relaxed text-[var(--ink)]">
            <h4 className="font-extrabold text-sm text-emerald-600 dark:text-emerald-400">
              Anti-Bot, Sybil Defense &amp; Eternal 10% Reserve Lock
            </h4>
            <ul className="list-disc pl-5 space-y-1.5 text-[var(--ink2)]">
              <li>
                <strong>Rate-Limiting:</strong> Maximum 5 scans per minute per hardware device.
              </li>
              <li>
                <strong>Hardware Fingerprint:</strong> Cryptographic device binding blocks emulator clones and state duplication.
              </li>
              <li>
                <strong>24-Hour Brute-Force Lockout:</strong> 5 consecutive invalid Passkey inputs trigger a strict 24-hour cryptographic hardware freeze.
              </li>
              <li>
                <strong>Eternal 10% Reserve Lock Governance:</strong> The company withdrawal cap of 10% can never be increased to 11%+ unless 100% of all registered Axis App users vote YES unanimously. A single NO vote triggers an immediate veto and removes the proposing executive.
              </li>
            </ul>
          </div>
        )}

        {activeSection === 'pitch' && (
          <div className="space-y-3 text-xs leading-relaxed text-[var(--ink)]">
            <div className="flex items-center justify-between pb-2 border-b border-[var(--c-border)]">
              <h4 className="font-extrabold text-sm text-emerald-600 dark:text-emerald-400">
                Official 12-15 Minute Video Pitch Script
              </h4>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 font-bold">
                12-15 MIN DURATION
              </span>
            </div>

            <div className="p-3 rounded-xl neu-inset space-y-2 text-[11px]">
              <div className="font-bold text-emerald-600 dark:text-emerald-400">
                ACT I: THE GLOBAL PACKAGING DILEMMA &amp; YIN-YANG ARCHITECTURE (0:00 - 3:00)
              </div>
              <p className="text-[var(--ink2)]">
                &bull; <em>Hook:</em> Billions of tons of FMCG packaging enter landfills every month. Traditional deposit-return systems suffer from multi-billion dollar fraud, fake barcodes, and zero proof of physical material authenticity.
              </p>
              <p className="text-[var(--ink2)]">
                &bull; <em>The Yin-Yang Solution:</em> The White Side (Yang = Teraxiom Blockchain Website) mints cryptographic Flower Codes with escrowed PHP &amp; FLWRXCOIN. The Black Side (Yin = Axis Mobile App + Decentralized Nodes) scans and burns these codes in consumers&apos; hands.
              </p>
            </div>

            <div className="p-3 rounded-xl neu-inset space-y-2 text-[11px]">
              <div className="font-bold text-emerald-600 dark:text-emerald-400">
                ACT II: PROOF OF FLOWER (PoF) CONSENSUS &amp; 11-TIER NODE CONSENSUS (3:00 - 6:30)
              </div>
              <p className="text-[var(--ink2)]">
                &bull; <em>Consensus Formula:</em> More FLWRXCOIN minted = less waste pollution and more flowers blooming in nature.
              </p>
              <p className="text-[var(--ink2)]">
                &bull; <em>Cryptographic Match:</em> 28 to 98 digits (+7 digits per tier) matching broadcasted Passkeys with &gt;=50% decentralized node quorum across up to 500 million nodes. Single-use burn prevents all double-spending.
              </p>
            </div>

            <div className="p-3 rounded-xl neu-inset space-y-2 text-[11px]">
              <div className="font-bold text-emerald-600 dark:text-emerald-400">
                ACT III: TOKENOMICS, DUAL-VALUE &amp; ETERNAL LOCK (6:30 - 9:30)
              </div>
              <p className="text-[var(--ink2)]">
                &bull; <em>10M Hard Cap:</em> 9M (90%) mined exclusively by recycling citizens. 1M (10%) locked in eternal company reserve requiring 100% unanimous user consensus to modify.
              </p>
              <p className="text-[var(--ink2)]">
                &bull; <em>Dual Rewards:</em> Guaranteed Fiat PHP (0.50 - 50.00 PHP) unaffected by market volatility, paired with FLWRXCOIN governed by 4-year halving.
              </p>
            </div>

            <div className="p-3 rounded-xl neu-inset space-y-2 text-[11px]">
              <div className="font-bold text-emerald-600 dark:text-emerald-400">
                ACT IV: INSTITUTIONAL TREASURY &amp; 70/30 REALIZED PNL SPLIT (9:30 - 12:30)
              </div>
              <p className="text-[var(--ink2)]">
                &bull; <em>365-Day Rolling Spot DCA:</em> Capital deployed systematically across 365 daily tranches with 1-year unbonding lock per tranche.
              </p>
              <p className="text-[var(--ink2)]">
                &bull; <em>Realized Profit Engine:</em> 70% retained by Manufacturing Partner, 30% remitted to Executive Treasury.
              </p>
            </div>

            <div className="p-3 rounded-xl neu-inset space-y-2 text-[11px]">
              <div className="font-bold text-emerald-600 dark:text-emerald-400">
                ACT V: TRACTION, RUNWAY &amp; THE INVITATION (12:30 - 15:00)
              </div>
              <p className="text-[var(--ink2)]">
                &bull; 70M PHP seed round deployed with 3-5 year runway discipline in BGC, Manila. Real FMCG partners onboarded. Join the revolution where every piece of recycled plastic mints a cleaner tomorrow.
              </p>
              {onOpenArchitecture && (
                <button
                  type="button"
                  onClick={onOpenArchitecture}
                  className="mt-2 w-full py-2.5 px-3 rounded-xl neu-btn-accent font-extrabold text-xs cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>⚡ Launch 3D Corporation Architecture &amp; Chess Ledger Engine</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
