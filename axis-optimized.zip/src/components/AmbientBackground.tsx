import React, { useEffect, useRef, memo, useState } from 'react';
import { CosmicBlackHole } from './CosmicBlackHole';
import { MigratoryBirds } from './MigratoryBirds';

export type WeatherMode = 'leaves' | 'autumn' | 'sakura' | 'raining' | 'storming' | 'blackhole';

interface AmbientBackgroundProps {
  enabled?: boolean;
  speed?: 'slow' | 'medium' | 'fast';
  weatherMode?: WeatherMode;
  gustTrigger?: number;
  lowPowerMode?: boolean;
  tone?: number;
  relativitySlide?: number;
}

export interface EnvironmentSceneInfo {
  id: WeatherMode;
  name: string;
  theme: string;
  description: string;
  sceneIndex: number;
  fallbackGradient: string;
}

export const PROCEDURAL_ENVIRONMENTS: Record<WeatherMode, EnvironmentSceneInfo> = {
  storming: {
    id: 'storming',
    name: 'Sunset Ocean & Reef',
    theme: 'Golden Sunset Waves & 0% Baseline Living Coral Reef',
    description: 'Split-level sunset ocean: 85% golden sunset waves; 15% luminous reef with corals at 0% baseline, god-rays, micro-bubbles, sea turtle & tangs',
    sceneIndex: 0,
    fallbackGradient: 'linear-gradient(180deg, #1c0e28 0%, #3d1c34 35%, #0d283c 75%, #032b36 100%)'
  },
  raining: {
    id: 'raining',
    name: 'River & Rain',
    theme: 'Turquoise River, Riverside Bear, Blue Heron, Otter & Leaping Fish',
    description: 'High-contrast flowing turquoise river with wet rocks, riverside brown bear, perched blue heron, river otter, swimming freshwater trout, and leaping fish',
    sceneIndex: 1,
    fallbackGradient: 'linear-gradient(180deg, #092c28 0%, #0d4a42 45%, #082622 100%)'
  },
  leaves: {
    id: 'leaves',
    name: 'Canopy',
    theme: 'Lush Green Canopy, Forest Elk, Woodland Bear & Mountain Lion',
    description: 'Towering green forest canopy with daylight sunbeams, forest elk, woodland bear, watchful mountain lion on rock ledge, multi-colored wildflowers, and fluttering songbirds',
    sceneIndex: 2,
    fallbackGradient: 'linear-gradient(180deg, #113821 0%, #1c5232 45%, #154127 100%)'
  },
  autumn: {
    id: 'autumn',
    name: 'Autumn',
    theme: 'Golden Foliage, Antlered Stag, Foraging Bear & Migrating Birds',
    description: 'Vibrant autumn landscape brought close to the lens with crimson and amber trees, antlered stag, foraging black bear, drifting leaves, and migrating bird flocks',
    sceneIndex: 3,
    fallbackGradient: 'linear-gradient(180deg, #381a07 0%, #5c2c0d 45%, #421e08 100%)'
  },
  sakura: {
    id: 'sakura',
    name: 'Sakura',
    theme: 'Cherry Blossom Trees, Japanese Sika Deer & White-Eye Birds',
    description: 'Spring environment with rich pink cherry blossoms, Japanese sika deer grazing in pink flower carpets, white-eye songbirds, and swallows',
    sceneIndex: 4,
    fallbackGradient: 'linear-gradient(180deg, #441430 0%, #6d204d 45%, #481233 100%)'
  },
  blackhole: {
    id: 'blackhole',
    name: 'Cosmic Black Hole',
    theme: 'Gargantua Accretion Disk, Orbital Probe & Relativity Slide',
    description: 'Cinematic 4K supermassive black hole with sweeping diagonal accretion disk, orbital exploration probe, interactive gravitational relativity slide, and Doppler beaming',
    sceneIndex: 5,
    fallbackGradient: 'radial-gradient(circle at 50% 35%, #000000 0%, #180902 35%, #4a2106 55%, #080301 85%)'
  }
};

// Backward compatibility alias
export const BACKGROUND_VIDEOS = PROCEDURAL_ENVIRONMENTS;
export const SEASON_MEDIA = PROCEDURAL_ENVIRONMENTS;

/* =========================================================================
   GLSL SHADERS (Universal Strict GLSL ES 1.00 / WebGL 1.0 / WebGL 2.0 Compliance)
   Architecture Rule: All uniforms and functions must precede void main().
   ========================================================================= */

const COMMON_HEAD = `#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec2 R;
uniform float T, uWind, uSh, uShS, uCnt, uFlash, uStorm, uLowQ, uTone;
uniform vec3 L;
uniform vec2 uRes;
uniform float uQuality;

float h21(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
vec2 h22(vec2 p){float n=h21(p);return vec2(n,h21(p+n+7.1));}
float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h21(i),h21(i+vec2(1,0)),f.x),mix(h21(i+vec2(0,1)),h21(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<5;i++){s+=a*vn(p);p=mat2(1.6,1.2,-1.2,1.6)*p;a*=.5;}return s;}
mat2 rot(float a){float c=cos(a),s=sin(a);return mat2(c,-s,s,c);}`;

// Shared autumn palette: crimson > orange > amber > gold > copper > brown > green
const PAL = `
vec3 pal(float s){
  vec3 c=vec3(.6,.06,.04);
  c=mix(c,vec3(.85,.32,.05),smoothstep(.12,.3,s));
  c=mix(c,vec3(.95,.6,.1),smoothstep(.3,.5,s));
  c=mix(c,vec3(.88,.74,.2),smoothstep(.5,.65,s));
  c=mix(c,vec3(.55,.28,.1),smoothstep(.65,.78,s));
  return mix(c,vec3(.3,.4,.08),smoothstep(.8,.92,s));
}`;

/* ---- Scene 0: Stormy Ocean & 4K Coral Reef (85% Storm Surface / 15% Underwater Reef) ---- */
const S0 = `
// Resolution-aware anti-aliased signed distance mask
float aaMask(float d, float w){
  return 1.0 - smoothstep(-w, w, d);
}

// 1. Albatross Seabirds (4 articulated albatross soaring with slow flapping, gliding and banking)
vec3 drawAlbatross(vec3 c, vec2 skyUV, float gPx){
  for(int b = 0; b < 4; b++){
    float fb = float(b);
    float bScale = 0.045 + fb * 0.012; // 0.045, 0.057, 0.069, 0.081
    float bSpeed = 0.16 + fb * 0.05;
    float bLoop = mod(T * bSpeed + fb * 2.3, 4.4) - 2.2;
    vec2 bPos = vec2(bLoop, 0.22 + fb * 0.13 + sin(T * 0.5 + fb * 1.6) * 0.05);
    
    vec2 bp = skyUV - bPos;
    float bank = sin(T * 0.8 + fb * 1.3) * 0.22;
    bp = rot(bank) * bp;
    
    // Bounding box early exit
    if(abs(bp.x) < bScale * 1.8 && abs(bp.y) < bScale * 0.9){
      vec2 nbp = bp / bScale;
      float bodyD = length(nbp * vec2(1.2, 4.0)) - 0.28;
      float headD = length((nbp - vec2(0.32, 0.0)) * vec2(3.0, 5.0)) - 0.15;
      
      // Articulated wings: inner and outer segment
      float flap = sin(T * 3.2 + fb * 1.8) * 0.32;
      float wingX = abs(nbp.x);
      float innerWingY = nbp.y - flap * wingX * 0.4;
      float outerWingY = nbp.y - flap * (0.4 + (wingX - 0.4) * 0.85) + max(0.0, wingX - 0.45) * 0.55;
      float wingY = mix(innerWingY, outerWingY, step(0.45, wingX));
      float wingD = max(abs(wingY) - (0.16 - wingX * 0.10), wingX - 1.45);
      
      float birdDist = min(min(bodyD, headD), wingD);
      float mask = aaMask(birdDist * bScale, gPx);
      
      if(mask > 0.0){
        vec3 birdCol = vec3(0.93, 0.95, 0.98);
        float darkTips = smoothstep(0.85, 1.45, wingX);
        birdCol = mix(birdCol, vec3(0.12, 0.14, 0.16), darkTips);
        if(nbp.x > 0.26 && abs(nbp.y) < 0.08){
          birdCol = vec3(0.96, 0.75, 0.35); // Beak
        }
        c = mix(c, birdCol, mask * 0.92);
      }
    }
  }
  return c;
}

// 2. Visible Jagged Lightning Bolts
vec3 drawLightning(vec3 c, vec2 skyUV, float gPx){
  if(uFlash > 0.25){
    float flashIntensity = smoothstep(0.25, 0.70, uFlash);
    float boltOriginX = sin(T * 0.07) * 0.35 + 0.08;
    float jagged = sin(skyUV.y * 35.0) * 0.038 + sin(skyUV.y * 95.0 + 1.7) * 0.018 + sin(skyUV.y * 220.0) * 0.007;
    float boltDist = abs(skyUV.x - (boltOriginX + jagged));
    
    float core = aaMask(boltDist - 0.0022, gPx);
    float glow = exp(-boltDist * 32.0) * 0.85 + exp(-boltDist * 10.0) * 0.35;
    
    vec3 boltCol = vec3(1.0, 1.0, 1.0) * core + vec3(0.55, 0.72, 1.0) * glow;
    c += boltCol * flashIntensity * smoothstep(-0.1, 0.25, skyUV.y);
  }
  return c;
}

// 3. Rain & Wave Spray Particles
vec3 drawRain(vec3 c, vec2 uv, float gPx){
  if(uStorm < 0.05) return c;
  
  float slant = 0.36 * uWind;
  vec2 rainUV1 = uv + vec2(-uv.y * slant + T * 3.6 * uWind, T * 9.0);
  vec2 rainUV2 = uv * 1.5 + vec2(-uv.y * slant * 1.2 + T * 4.9 * uWind, T * 13.0);
  
  float r1 = vn(vec2(rainUV1.x * 65.0, rainUV1.y * 3.2));
  float r2 = vn(vec2(rainUV2.x * 95.0, rainUV2.y * 4.6));
  
  float streak1 = smoothstep(0.72, 0.96, r1);
  float streak2 = smoothstep(0.75, 0.98, r2);
  
  float rainAlpha = (streak1 * 0.6 + streak2 * 0.4) * uStorm * 0.13 * (0.5 + uFlash * 0.7);
  c = mix(c, vec3(0.78, 0.86, 0.96), clamp(rainAlpha, 0.0, 0.8));
  return c;
}

// Sky function with golden sunrise / sunset radiance, clouds, lighting, albatross
vec3 sky(vec3 d, float gPx){
  float st = uStorm;
  // Golden Sunset / Sunrise Horizon & Dusk Twilight Palette
  vec3 sunsetHor = vec3(0.98, 0.58, 0.28);
  vec3 sunsetTop = vec3(0.16, 0.22, 0.45);
  vec3 hor = mix(sunsetHor, vec3(0.42, 0.32, 0.30), st * 0.6);
  vec3 top = mix(sunsetTop, vec3(0.06, 0.08, 0.14), st * 0.6);
  vec3 c = mix(hor, top, pow(max(d.y, 0.0), 0.55));
  
  vec2 q = d.xz / (d.y + 0.3) * 1.1 + vec2(T * 0.03 * uWind, T * 0.02);
  float cl = fbm(q * 1.5 + fbm(q * 3.0));
  vec3 cloudSunCol = vec3(1.0, 0.72, 0.45);
  vec3 cloudDarkCol = mix(vec3(0.12, 0.10, 0.15), vec3(0.06, 0.065, 0.08), st);
  vec3 cloudCol = mix(cloudSunCol, cloudDarkCol, st * 0.5 + (1.0 - cl) * 0.4);
  c = mix(c, cloudCol * (0.65 + cl * 0.5), smoothstep(0.28, 0.82, cl) * (0.35 + 0.65 * st));
  
  // Golden Sunset Sun Disc with warm atmospheric corona
  vec3 sunDir = normalize(vec3(0.35, 0.14, 0.92));
  float sunDot = max(dot(d, sunDir), 0.0);
  c += vec3(1.0, 0.88, 0.55) * pow(sunDot, 180.0) * (1.0 - st * 0.6) * 4.2;
  c += vec3(1.0, 0.55, 0.22) * pow(sunDot, 14.0) * (1.0 - st * 0.5) * 0.85;
  
  c += vec3(0.75, 0.65, 1.0) * uFlash * (0.3 + 1.6 * cl * cl) * (0.5 + 0.5 * exp(-abs(d.y) * 2.0));
  
  // Albatross in sky
  c = drawAlbatross(c, d.xy, gPx);
  
  // Visible lightning bolt
  c = drawLightning(c, d.xy, gPx);
  
  return c;
}

// Ocean Waves with Gerstner Horizontal Pinching & High-Frequency Micro-Capillaries
float so(vec2 uv, float c){
  uv += vn(uv) * 1.8 - 0.9;
  vec2 w = 1.0 - abs(sin(uv)), s = abs(cos(uv));
  w = mix(w, s, w);
  return pow(1.0 - pow(w.x * w.y, 0.65), c);
}

float amp0(){ return 0.55 + 0.9 * uStorm; }

float wh(vec2 p, int oct){
  int maxOct = uQuality < 0.5 ? 3 : 5;
  if(oct > maxOct) oct = maxOct;
  float fr = 0.16, am = amp0(), ch = 3.2 + 3.0 * uStorm, t = 1.0 + T * (0.6 + 0.8 * uStorm) * uWind;
  vec2 uv = vec2(p.x * 0.75, p.y);
  float h = 0.0;
  
  // Gerstner Horizontal Pinching: coordinates pull toward wave peaks to form sharp crests & flat troughs
  vec2 dP = vec2(0.0);
  for(int i = 0; i < 5; i++){
    if(i >= oct) break;
    float fi = float(i);
    vec2 dir = normalize(vec2(cos(fi * 1.6 + 0.2), sin(fi * 1.6 + 0.5)));
    float phase = dot(uv + dP, dir) * fr + t;
    dP += dir * cos(phase) * am * 0.26;
    
    float waveComp = pow(sin(phase) * 0.5 + 0.5, ch * 0.65);
    h += waveComp * am;
    
    uv = mat2(1.6, 1.2, -1.2, 1.6) * uv;
    fr *= 1.85;
    am *= 0.22;
    ch = mix(ch, 1.0, 0.22);
  }
  
  // High-Frequency Micro-Capillary Ripples (wind-driven micro glints)
  float capillary = fbm(p * 12.0 + vec2(T * 2.2 * uWind, T * 1.1));
  h += (capillary - 0.5) * 0.016 * (1.0 + uStorm * 0.7);
  
  return h;
}

float wf(vec3 p, int o){ return p.y - wh(p.xz, o); }

float trace(vec3 o, vec3 d){
  float tx = 400.0, tm = 0.0;
  float hx = wf(o + d * tx, 3);
  if(hx > 0.0) return tx;
  float hm = wf(o, 3);
  for(int i = 0; i < 8; i++){
    float tmid = mix(tm, tx, hm / (hm - hx));
    float hmid = wf(o + d * tmid, 3);
    if(hmid < 0.0){ tx = tmid; hx = hmid; } else { tm = tmid; hm = hmid; }
  }
  return mix(tm, tx, hm / (hm - hx));
}

// Coral Palettes (Pink, Orange, Lavender, Purple, Red, Blue, Yellow, Green)
vec3 coralPalette(float h){
  if(h < 0.125) return vec3(0.95, 0.35, 0.60); // pink
  if(h < 0.250) return vec3(0.96, 0.52, 0.12); // orange
  if(h < 0.375) return vec3(0.72, 0.55, 0.95); // lavender
  if(h < 0.500) return vec3(0.55, 0.20, 0.70); // purple
  if(h < 0.625) return vec3(0.90, 0.18, 0.25); // red
  if(h < 0.750) return vec3(0.15, 0.60, 0.85); // blue
  if(h < 0.875) return vec3(0.95, 0.85, 0.15); // yellow
  return vec3(0.18, 0.75, 0.42);                // green
}

// Renders one coral cell (Types 0: Brain, 1: Staghorn, 2: Sea Fan, 3: Tube Sponges, 4: Anemone)
vec4 evalCoralCell(vec2 p, float floorY, float coralH, float coralW, float cellRand, float gPx){
  if(p.y < 0.0 || p.y > coralH + 0.02 || abs(p.x) > coralW * 1.5) return vec4(0.0);
  
  int cType = int(mod(floor(cellRand * 5.0), 5.0));
  vec3 col = coralPalette(cellRand);
  float alpha = 0.0;
  
  if(cType == 0){
    // Type 0: Brain Coral (dome with labyrinth grooves and spherical shading)
    vec2 domeP = vec2(p.x / coralW, p.y / coralH);
    float d = length(domeP) - 1.0;
    alpha = aaMask(d * min(coralW, coralH), gPx);
    if(alpha > 0.0){
      float nz = sqrt(max(0.0, 1.0 - dot(domeP, domeP)));
      float diff = max(0.25, dot(normalize(vec3(domeP, nz)), vec3(0.3, 0.6, 0.74)));
      float groove = sin(fbm(p * 45.0) * 18.0);
      float grooveDark = smoothstep(-0.25, 0.35, groove);
      col = col * (0.55 + 0.45 * grooveDark) * (0.6 + 0.5 * diff);
    }
  } else if(cType == 1){
    // Type 1: Staghorn Coral (branching ridged structure thinning toward tips)
    float trunkW = coralW * 0.28 * (1.0 - p.y / (coralH * 1.25));
    float trunkD = abs(p.x) - trunkW;
    
    float b1Y = coralH * 0.45;
    float b1X = (p.y - b1Y) * 0.75;
    float b1D = abs(p.x - b1X) - trunkW * 0.65;
    
    float b2Y = coralH * 0.55;
    float b2X = -(p.y - b2Y) * 0.70;
    float b2D = abs(p.x - b2X) - trunkW * 0.65;
    
    float branchD = min(trunkD, min(p.y > b1Y ? b1D : 9.0, p.y > b2Y ? b2D : 9.0));
    alpha = aaMask(branchD, gPx);
    if(alpha > 0.0){
      float tipHighlight = smoothstep(coralH * 0.7, coralH, p.y);
      col = mix(col, vec3(0.96, 0.92, 0.85), tipHighlight * 0.75);
      float polyps = step(0.4, fract(p.y * 80.0));
      col *= (0.8 + 0.2 * polyps);
    }
  } else if(cType == 2){
    // Type 2: Sea Fan (upright fan with radial + concentric vein net, swaying)
    float fanY = coralH * 0.25;
    if(p.y < fanY){
      alpha = aaMask(abs(p.x) - coralW * 0.12, gPx);
      col = vec3(0.4, 0.25, 0.18);
    } else {
      vec2 fanP = vec2(p.x / coralW, (p.y - fanY) / (coralH - fanY));
      float fanD = length(fanP) - 1.0;
      alpha = aaMask(fanD * min(coralW, coralH), gPx);
      if(alpha > 0.0){
        float ang = atan(fanP.y, fanP.x);
        float radial = sin(ang * 22.0);
        float conc = sin(length(fanP) * 50.0);
        float net = smoothstep(0.1, 0.6, abs(radial * conc));
        col = mix(col * 0.5, col * 1.2, net);
      }
    }
  } else if(cType == 3){
    // Type 3: Tube Sponges (4 tubes with dark open mouths)
    float bestTubeD = 9.0;
    float mouthMask = 0.0;
    for(int tb = 0; tb < 4; tb++){
      float ft = float(tb);
      float tubeX = (ft - 1.5) * (coralW * 0.5);
      float tubeH = coralH * (0.65 + 0.35 * sin(ft * 2.1 + 1.2));
      float tubeR = coralW * 0.2;
      
      if(p.y <= tubeH){
        float td = abs(p.x - tubeX) - tubeR;
        if(td < bestTubeD) bestTubeD = td;
      }
      if(abs(p.y - tubeH) < tubeR * 0.6 && abs(p.x - tubeX) < tubeR){
        float mouthD = length(vec2((p.x - tubeX) / tubeR, (p.y - tubeH) / (tubeR * 0.5))) - 0.7;
        if(mouthD < 0.0) mouthMask = 1.0;
      }
    }
    alpha = aaMask(bestTubeD, gPx);
    if(alpha > 0.0){
      float pores = vn(p * 60.0);
      col = mix(col * (0.6 + 0.4 * pores), vec3(0.02, 0.03, 0.05), mouthMask);
    }
  } else {
    // Type 4: Anemone (11 tentacles with waving motion and glowing tips)
    float baseD = length(vec2(p.x / coralW, p.y / (coralH * 0.35))) - 0.8;
    float tentacleDist = 9.0;
    float tipGlow = 0.0;
    
    for(int tn = 0; tn < 11; tn++){
      float ft = float(tn);
      float tAngle = (ft / 10.0 - 0.5) * 1.5;
      float wave = sin(T * 3.0 + ft * 0.85) * 0.02 * (p.y / coralH);
      vec2 tDir = vec2(sin(tAngle), cos(tAngle));
      float proj = dot(vec2(p.x - wave, p.y), tDir);
      vec2 perp = vec2(p.x - wave, p.y) - tDir * proj;
      
      if(proj > 0.0 && proj < coralH){
        float tWidth = coralW * 0.09 * (1.0 - proj / (coralH * 1.3));
        float td = length(perp) - tWidth;
        if(td < tentacleDist){
          tentacleDist = td;
          if(proj > coralH * 0.75) tipGlow = (proj - coralH * 0.75) / (coralH * 0.25);
        }
      }
    }
    float d = min(baseD * min(coralW, coralH), tentacleDist);
    alpha = aaMask(d, gPx);
    if(alpha > 0.0){
      col = mix(col, vec3(1.0, 0.7, 0.85), tipGlow * 0.8);
    }
  }
  
  return vec4(col, alpha);
}

// Parallax reef layer renderer (floor sand, ripples, cell corals) with 0% baseline and sunset caustics
vec4 renderReefLayer(vec2 uv, float k, float floorY, float fogAmt, float layerSeed, float gPx){
  vec2 swayUV = uv;
  swayUV.x += sin(T * 1.1 + layerSeed * 3.5) * 0.007 * max(0.0, uv.y - floorY);
  
  float sandRipple = sin(swayUV.x * 35.0 + layerSeed * 12.0) * 0.003;
  float sandY = floorY + sandRipple;
  
  vec3 sandCol = mix(vec3(0.20, 0.32, 0.35), vec3(0.12, 0.22, 0.26), fogAmt);
  float sandAlpha = aaMask(-(swayUV.y - sandY), gPx);
  vec4 result = vec4(sandCol, sandAlpha);
  
  float cx = swayUV.x * k;
  float cellId = floor(cx);
  float fx = fract(cx) - 0.5;
  float cellRand = h21(vec2(cellId, layerSeed * 19.3));
  
  if(cellRand > 0.14){
    float maxTop = -0.745; // Guarantee never reaches 15% waterline at -0.70
    float maxAllowedH = max(0.02, maxTop - floorY);
    // Corals root directly at floorY and grow upwards up to 10-12% of screen height
    float coralH = 0.065 + cellRand * 0.15;
    if(coralH > maxAllowedH) coralH = maxAllowedH;
    float coralW = coralH * (0.55 + h21(vec2(cellId, layerSeed + 2.5)) * 0.55);
    
    vec2 localP = vec2(fx * (1.0 / k), swayUV.y - floorY);
    vec4 coral = evalCoralCell(localP, floorY, coralH, coralW, cellRand, gPx);
    if(coral.a > 0.0){
      // Feature 1: Sunset golden caustics shimmering directly over coral ridges
      float cCaust = pow(abs(fbm(swayUV * 22.0 + vec2(T * 0.22, T * 0.12)) * 2.0 - 1.0), 1.6);
      vec3 causticGlow = mix(vec3(0.2, 0.65, 0.8), vec3(1.0, 0.88, 0.52), 0.55) * cCaust * 0.45;
      coral.rgb += causticGlow * (1.0 - fogAmt * 0.7);
      
      vec3 fogCol = vec3(0.02, 0.22, 0.32);
      coral.rgb = mix(coral.rgb, fogCol, fogAmt);
      result.rgb = mix(result.rgb, coral.rgb, coral.a);
      result.a = max(result.a, coral.a);
    }
  }
  
  return result;
}

// Fish 1: Yellow Tang (Canary Yellow, blue eye ring, white tail spine, fin geometry)
vec4 drawYellowTang(vec2 uv, vec2 fishPos, float dir, float gPx){
  vec2 dp = uv - fishPos;
  if(abs(dp.x) > 0.08 || abs(dp.y) > 0.045) return vec4(0.0);
  
  dp.x *= dir;
  float wave = sin(T * 10.0 + dp.x * 35.0) * 0.004 * (dp.x > 0.0 ? 0.3 : 1.2);
  dp.y += wave;
  
  float bodyD = length(dp * vec2(1.8, 2.5)) - 0.032;
  float snoutD = length((dp - vec2(0.028, -0.002)) * vec2(3.5, 4.0)) - 0.012;
  float dorsalD = length((dp - vec2(-0.005, 0.022)) * vec2(2.0, 3.8)) - 0.015;
  float analD = length((dp - vec2(-0.008, -0.02)) * vec2(2.5, 4.2)) - 0.012;
  float tailD = max(abs(dp.y) - (-dp.x - 0.018) * 0.85, -dp.x - 0.048);
  if(dp.x > -0.02) tailD = 9.0;
  
  float fishSDF = min(min(min(bodyD, snoutD), min(dorsalD, analD)), tailD);
  float alpha = aaMask(fishSDF, gPx);
  if(alpha <= 0.0) return vec4(0.0);
  
  vec3 tangCol = vec3(0.98, 0.85, 0.06);
  tangCol = mix(tangCol, vec3(1.0, 0.95, 0.35), smoothstep(-0.01, 0.025, dp.y));
  
  vec2 eyeP = dp - vec2(0.022, 0.006);
  float eyeDist = length(eyeP);
  if(eyeDist < 0.0075){
    tangCol = vec3(0.12, 0.45, 0.95);
    if(eyeDist < 0.004) tangCol = vec3(0.02, 0.02, 0.03);
    if(length(eyeP - vec2(0.0015, 0.0015)) < 0.0012) tangCol = vec3(1.0);
  }
  
  if(abs(dp.x - (-0.022)) < 0.004 && abs(dp.y) < 0.003){
    tangCol = vec3(0.98, 0.98, 1.0);
  }
  
  float finStroke = sin(T * 8.0) * 0.004;
  if(length(dp - vec2(0.006, -0.006 + finStroke)) < 0.006){
    tangCol = mix(tangCol, vec3(1.0, 0.92, 0.4), 0.8);
  }
  
  return vec4(tangCol, alpha);
}

// Fish 2: Clownfish (Orange with 3 crisp white bands and dark borders)
vec4 drawClownfish(vec2 uv, vec2 fishPos, float dir, float gPx){
  vec2 dp = uv - fishPos;
  if(abs(dp.x) > 0.075 || abs(dp.y) > 0.04) return vec4(0.0);
  
  dp.x *= dir;
  float wave = sin(T * 11.0 + dp.x * 40.0) * 0.004 * (dp.x > 0.0 ? 0.3 : 1.2);
  dp.y += wave;
  
  float bodyD = length(dp * vec2(2.1, 3.2)) - 0.030;
  float dorsalD = length((dp - vec2(-0.004, 0.018)) * vec2(2.2, 3.5)) - 0.014;
  float analD = length((dp - vec2(-0.006, -0.016)) * vec2(2.8, 3.8)) - 0.011;
  float tailD = max(abs(dp.y) - (-dp.x - 0.014) * 0.75, -dp.x - 0.042);
  if(dp.x > -0.015) tailD = 9.0;
  
  float fishSDF = min(min(bodyD, min(dorsalD, analD)), tailD);
  float alpha = aaMask(fishSDF, gPx);
  if(alpha <= 0.0) return vec4(0.0);
  
  vec3 clownCol = vec3(0.96, 0.45, 0.08);
  
  float b1 = abs(dp.x - 0.013);
  float b2 = abs(dp.x - (-0.007));
  float b3 = abs(dp.x - (-0.025));
  float whiteBand = step(b1, 0.0035) + step(b2, 0.004) + step(b3, 0.003);
  float blackOutline = step(b1, 0.005) + step(b2, 0.0055) + step(b3, 0.0045);
  
  clownCol = mix(clownCol, vec3(0.05, 0.05, 0.06), min(1.0, blackOutline));
  clownCol = mix(clownCol, vec3(0.96, 0.96, 0.98), min(1.0, whiteBand));
  
  vec2 eyeP = dp - vec2(0.020, 0.004);
  float eyeDist = length(eyeP);
  if(eyeDist < 0.006){
    clownCol = vec3(0.96, 0.45, 0.08);
    if(eyeDist < 0.0035) clownCol = vec3(0.02, 0.02, 0.03);
    if(length(eyeP - vec2(0.001, 0.001)) < 0.001) clownCol = vec3(1.0);
  }
  
  return vec4(clownCol, alpha);
}

// Fish 3: Blue Chromis School (Electric blue body with yellow fork tail)
vec4 drawChromisSchool(vec2 uv, float gPx){
  vec2 schoolPos = vec2(0.95 - mod(T * 0.19, 2.9), -0.76 + sin(T * 0.7) * 0.015);
  int count = uQuality > 0.5 ? 7 : 4;
  vec4 result = vec4(0.0);
  
  for(int fi = 0; fi < 7; fi++){
    if(fi >= count) break;
    float ff = float(fi);
    vec2 offset = vec2(
      ff * 0.028 + sin(ff * 2.3) * 0.012,
      sin(ff * 3.1 + T * 1.5) * 0.015 + (ff - 3.0) * 0.006
    );
    vec2 fPos = schoolPos + offset;
    vec2 dp = uv - fPos;
    if(abs(dp.x) < 0.035 && abs(dp.y) < 0.02){
      dp.x = -dp.x;
      dp.y += sin(T * 12.0 + ff + dp.x * 45.0) * 0.003;
      
      float bodyD = length(dp * vec2(2.5, 4.0)) - 0.016;
      float tailD = max(abs(dp.y) - (-dp.x - 0.007) * 0.7, -dp.x - 0.024);
      if(dp.x > -0.006) tailD = 9.0;
      
      float d = min(bodyD, tailD);
      float alpha = aaMask(d, gPx);
      if(alpha > 0.0){
        vec3 col = vec3(0.12, 0.68, 0.96);
        if(dp.x < -0.006){
          col = vec3(0.98, 0.88, 0.12);
        }
        if(length(dp - vec2(0.011, 0.002)) < 0.0025){
          col = vec3(0.02, 0.02, 0.04);
        }
        result.rgb = mix(result.rgb, col, alpha);
        result.a = max(result.a, alpha);
      }
    }
  }
  return result;
}

// Sea Turtle (Top View: Voronoi scute shell, paddling front flippers, turning head)
vec4 drawSeaTurtle(vec2 uv, float gPx){
  float turtleX = -1.6 + mod(T * 0.075 + 1.1, 3.4);
  vec2 turtlePos = vec2(turtleX, -0.75 + sin(T * 0.5) * 0.010);
  vec2 tp = uv - turtlePos;
  
  if(length(tp) > 0.16) return vec4(0.0);
  
  tp = rot(sin(T * 0.7) * 0.05) * tp;
  
  float shellD = length(tp * vec2(1.6, 2.3)) - 0.068;
  
  float stroke = sin(T * 2.2) * 0.35;
  vec2 fFlapP1 = tp - vec2(0.025, 0.045);
  fFlapP1 = rot(-0.6 + stroke) * fFlapP1;
  float fFlip1 = length(fFlapP1 * vec2(1.2, 4.2)) - 0.038;
  
  vec2 fFlapP2 = tp - vec2(0.025, -0.045);
  fFlapP2 = rot(0.6 - stroke) * fFlapP2;
  float fFlip2 = length(fFlapP2 * vec2(1.2, 4.2)) - 0.038;
  
  vec2 rFlipP1 = tp - vec2(-0.045, 0.028);
  rFlipP1 = rot(-0.35) * rFlipP1;
  float rFlip1 = length(rFlipP1 * vec2(1.8, 3.2)) - 0.018;
  
  vec2 rFlipP2 = tp - vec2(-0.045, -0.028);
  rFlipP2 = rot(0.35) * rFlipP2;
  float rFlip2 = length(rFlipP2 * vec2(1.8, 3.2)) - 0.018;
  
  vec2 tailP = tp - vec2(-0.065, 0.0);
  float tailD = length(tailP * vec2(3.0, 5.0)) - 0.012;
  
  float headTurn = sin(T * 1.1) * 0.08;
  vec2 headP = tp - vec2(0.065, headTurn);
  float headD = length(headP * vec2(2.4, 3.2)) - 0.022;
  
  float turtleSDF = min(min(min(shellD, min(fFlip1, fFlip2)), min(rFlip1, rFlip2)), min(headD, tailD));
  float alpha = aaMask(turtleSDF, gPx);
  if(alpha <= 0.0) return vec4(0.0);
  
  vec3 col = vec3(0.28, 0.42, 0.22);
  
  if(shellD <= 0.0){
    float scuteGrid = length(sin(tp * 55.0) * cos(tp * 48.0));
    float scuteBorder = smoothstep(0.7, 0.95, scuteGrid);
    vec3 plateCol = mix(vec3(0.38, 0.28, 0.14), vec3(0.68, 0.54, 0.22), scuteGrid * 0.5);
    col = mix(plateCol, vec3(0.12, 0.10, 0.08), scuteBorder * 0.7);
    
    float marginalRing = smoothstep(-0.008, 0.0, shellD);
    col = mix(col, vec3(0.75, 0.62, 0.28), marginalRing * 0.65);
  } else {
    col = vec3(0.32, 0.46, 0.26);
    if(headD <= 0.0){
      if(length(headP - vec2(0.006, 0.007)) < 0.0035 || length(headP - vec2(0.006, -0.007)) < 0.0035){
        col = vec3(0.02, 0.02, 0.04);
      }
    }
  }
  
  return vec4(col, alpha);
}

// Giant Clam (Tridacna gigas) with fluted calcium shell, iridescent mantle, and breathing siphon
vec4 drawGiantClam(vec2 uv, vec2 clamPos, float gPx){
  vec2 cp = uv - clamPos;
  if(abs(cp.x) > 0.09 || abs(cp.y) > 0.055) return vec4(0.0);
  
  // Fluted calcium shell with undulating radial ribs
  float ang = atan(cp.y, cp.x);
  float dist = length(cp * vec2(1.2, 2.0));
  float flute = sin(ang * 12.0) * 0.0055;
  float shellD = dist - (0.042 + flute);
  float shellAlpha = aaMask(shellD, gPx);
  if(shellAlpha <= 0.0) return vec4(0.0);
  
  // Outer shell: aged ivory calcium with growth bands
  vec3 shellCol = mix(vec3(0.55, 0.52, 0.46), vec3(0.85, 0.82, 0.74), sin(dist * 90.0) * 0.5 + 0.5);
  shellCol = mix(shellCol, vec3(0.18, 0.22, 0.24), smoothstep(0.0, 0.015, shellD));
  
  // Inner iridescent mantle (electric cyan, indigo, and emerald zooxanthellae spots)
  float pulse = sin(T * 1.8) * 0.0025;
  float mantleD = length(cp * vec2(1.5, 2.6)) - (0.026 + flute * 0.8 + pulse);
  float mantleAlpha = aaMask(mantleD, gPx);
  
  if(mantleAlpha > 0.0){
    float mantleRing = length(cp * vec2(1.8, 3.0));
    vec3 mantleCol = mix(vec3(0.02, 0.88, 0.95), vec3(0.35, 0.12, 0.78), smoothstep(0.01, 0.035, mantleRing));
    // Glowing zooxanthellae eye-spots along scalloped mantle margin
    float spots = pow(max(0.0, sin(ang * 18.0) * sin(mantleRing * 110.0)), 2.5);
    mantleCol = mix(mantleCol, vec3(0.30, 0.98, 0.75), spots * 0.85);
    // Dark central incurrent/excurrent siphon aperture
    float siphonD = length(cp * vec2(2.8, 5.0)) - 0.006;
    mantleCol = mix(mantleCol, vec3(0.01, 0.02, 0.05), aaMask(siphonD, gPx));
    
    shellCol = mix(shellCol, mantleCol, mantleAlpha);
  }
  
  return vec4(shellCol, shellAlpha);
}

vec4 drawBubbles(vec2 uv, float wl, vec2 clamPos, float gPx){
  if(uv.y > wl || uv.y < -1.0) return vec4(0.0);
  vec4 res = vec4(0.0);
  for(int b = 0; b < 6; b++){
    float fb = float(b);
    float colX = -0.85 + fb * 0.34 + sin(fb * 3.7) * 0.08;
    float bSpeed = 0.08 + sin(fb * 2.1) * 0.022;
    float bPhase = fb * 1.618;
    
    float span = wl - (-1.0);
    float curY = -1.0 + mod(T * bSpeed + bPhase * span, span);
    float wobble = sin(curY * 26.0 + T * 3.2 + fb) * 0.005;
    vec2 bPos = vec2(colX + wobble, curY);
    float bRad = 0.0035 + sin(fb * 4.3) * 0.0012;
    float bDist = length(uv - bPos) - bRad;
    float bAlpha = aaMask(bDist, gPx);
    if(bAlpha > 0.0){
      vec2 specOff = (uv - bPos) / bRad - vec2(0.35, 0.35);
      float spec = smoothstep(0.4, 0.0, length(specOff));
      // Bubbles catch shimmering golden specular glints when crossing sunbeams
      float inRay = pow(fbm(vec2(bPos.x * 2.2 + (bPos.y - wl) * 1.5, T * 0.05) * 3.0), 2.0);
      vec3 bCol = mix(vec3(0.5, 0.85, 0.95), vec3(1.0, 0.94, 0.65), 0.35 + inRay * 0.5) * (0.65 + 0.65 * spec);
      res.rgb = mix(res.rgb, bCol, bAlpha * 0.85);
      res.a = max(res.a, bAlpha * 0.85);
    }
  }
  return res;
}

// Complete underwater composite (~bottom 15% from 0% baseline at -1.0 to 15% waterline at -0.70)
vec3 renderUnderwaterScene(vec2 uv, float wl, float gPx){
  float dFactor = clamp((wl - uv.y) / 0.30, 0.0, 1.0);
  // Luminous tropical turquoise water illuminated by golden sunset
  vec3 shallowWater = vec3(0.08, 0.52, 0.62);
  vec3 deepWater = vec3(0.015, 0.16, 0.24);
  vec3 water = mix(shallowWater, deepWater, dFactor);
  water *= mix(1.0, 0.65, uStorm);
  
  // Feature 1: Dancing caustics with warm sunset/sunrise golden reflections
  float caust1 = pow(abs(fbm(uv * 18.0 + vec2(T * 0.26, T * 0.12)) * 2.0 - 1.0), 1.8);
  float caust2 = (uQuality > 0.5) ? pow(abs(fbm(uv * 36.0 - vec2(T * 0.32, T * 0.08)) * 2.0 - 1.0), 1.8) : 0.0;
  float caust = (caust1 + caust2 * 0.6) * (1.0 - dFactor * 0.5);
  vec3 causticCol = mix(vec3(0.18, 0.48, 0.58), vec3(1.0, 0.88, 0.52), 0.42);
  water += causticCol * caust * 0.75;
  
  // Feature 3: Warm Sunset / Sunrise Angled Volumetric God-Rays
  float rayCoord = uv.x * 2.2 + (uv.y - wl) * 1.5 + T * 0.09;
  float rays1 = pow(fbm(vec2(rayCoord, T * 0.05) * 3.2), 2.2);
  float rays2 = pow(fbm(vec2(rayCoord * 1.7 + 2.1, -T * 0.04) * 3.0), 2.0) * 0.55;
  float rays = (rays1 + rays2) * (1.0 - dFactor * 0.55);
  vec3 sunRayCol = vec3(1.0, 0.84, 0.48);
  water += sunRayCol * rays * 0.88;
  
  // Bright underside near 15% waterline glowing with warm sunset radiance
  float underside = exp(-(wl - uv.y) / (8.0 * gPx + 0.018)) * 0.55;
  water += vec3(1.0, 0.78, 0.48) * underside;
  
  // Refraction wobble
  float wobbleStr = (1.0 - dFactor) * 0.008;
  vec2 wUv = uv + vec2(sin(uv.y * 55.0 + T * 4.0), cos(uv.x * 45.0 - T * 3.0)) * wobbleStr;
  
  // 1. Far Reef Layer: k=6.8, floorY=-1.015 (corals start right at 0% base), fog 0.50
  vec4 farReef = renderReefLayer(wUv, 6.8, -1.015, 0.50, 1.2, gPx);
  vec3 col = mix(water, farReef.rgb, farReef.a);
  
  // 2. Mid Reef Layer: k=4.6, floorY=-1.005, fog 0.26
  vec4 midReef = renderReefLayer(wUv, 4.6, -1.005, 0.26, 2.5, gPx);
  col = mix(col, midReef.rgb, midReef.a);
  
  // 3. Marine Life: Fish (Yellow Tangs, Clownfish, Chromis School)
  // Yellow Tang 1: cruising in upper water column
  float t1X = -1.2 + mod(T * 0.16, 2.6) - 0.2;
  vec4 tang1 = drawYellowTang(wUv, vec2(t1X, -0.77), 1.0, gPx);
  col = mix(col, tang1.rgb, tang1.a);
  
  // Yellow Tang 2
  float t2X = 1.2 - mod(T * 0.14 + 0.8, 2.6);
  vec4 tang2 = drawYellowTang(wUv, vec2(t2X, -0.80), -1.0, gPx);
  col = mix(col, tang2.rgb, tang2.a);
  
  // Feature 4: Clownfish darting around lower reef anemones (2% to 7% height)
  float cX = -0.8 + mod(T * 0.17 + 0.4, 2.0) - 0.2;
  vec4 clown = drawClownfish(wUv, vec2(cX, -0.93), 1.0, gPx);
  col = mix(col, clown.rgb, clown.a);
  
  float c2X = 0.6 - mod(T * 0.15 + 1.2, 2.0);
  vec4 clown2 = drawClownfish(wUv, vec2(c2X, -0.95), -1.0, gPx);
  col = mix(col, clown2.rgb, clown2.a);
  
  // Blue Chromis school in sunlit open water gap
  vec4 school = drawChromisSchool(wUv, gPx);
  col = mix(col, school.rgb, school.a);
  
  // Feature 4: Sea Turtle gliding in upper open water just under waves (12% to 14% height)
  vec4 turtle = drawSeaTurtle(wUv, gPx);
  col = mix(col, turtle.rgb, turtle.a);
  
  // 4. Foreground Reef Layer: k=3.2, floorY=-0.995 (rooted at 0% baseline), light fog 0.05
  vec4 foreReef = renderReefLayer(wUv, 3.2, -0.995, 0.05, 3.8, gPx);
  col = mix(col, foreReef.rgb, foreReef.a);
  
  // 5. Giant Clam (Tridacna gigas) anchored on the 0% coral bed with iridescent mantle
  vec2 clamPos = vec2(-0.42, -0.965);
  vec4 clam = drawGiantClam(wUv, clamPos, gPx);
  col = mix(col, clam.rgb, clam.a);
  
  // 6. Micro-Oxygen bubbles rising from 0% corals & Giant Clam up to 15% waterline
  vec4 bubbles = drawBubbles(wUv, wl, clamPos, gPx);
  col = mix(col, bubbles.rgb, bubbles.a);
  
  // Feature 5: Soft deep-cyan baseline vignette (0% to 2% screen height) for UI Dock contrast
  float bottomVignette = smoothstep(-0.95, -1.0, uv.y) * 0.35;
  col = mix(col, vec3(0.01, 0.05, 0.10), bottomVignette);
  
  return col;
}

// Main Split-Level Scene (85% Storm Surface / 15% Underwater Reef)
vec3 scene(vec2 uv){
  float gPx = 2.0 / max(uRes.y, 1.0);
  
  // Waterline formula (centre at -0.70 gives exact 15% underwater strip)
  float wl = -0.70 + 0.018 * sin(uv.x * 4.0 + T * 1.8) + 0.007 * cos(uv.x * 8.0 - T * 2.5) + 0.012 * uStorm * sin(uv.x * 2.3 + T * 2.9);
  
  // 3-pixel anti-aliased meniscus highlight line
  float distToWl = abs(uv.y - wl);
  float meniscus = smoothstep(3.0 * gPx, 0.0, distToWl);
  
  if(uv.y < wl){
    vec3 uw = renderUnderwaterScene(uv, wl, gPx);
    uw += vec3(1.0, 0.90, 0.72) * meniscus * 0.95;
    return uw;
  }
  
  // Surface and Sky
  vec2 su = uv;
  su *= rot(sin(T * 0.3) * 0.03 * uStorm);
  vec3 ro = vec3(0.0, 4.0 + 0.25 * sin(T * 0.5), 0.0);
  vec3 rd = normalize(vec3(su.x, su.y - 0.18, 1.6));
  float t = trace(ro, rd);
  
  vec3 col;
  if(t >= 399.0){
    col = sky(rd, gPx);
  } else {
    vec3 p = ro + rd * t;
    float e = max(0.04, 0.003 * t);
    float y = wh(p.xz, 5);
    vec3 n = normalize(vec3(-(wh(p.xz + vec2(e, 0.0), 5) - y), e * 1.2, -(wh(p.xz + vec2(0.0, e), 5) - y)));
    n = normalize(mix(n, vec3(0.0, 1.0, 0.0), smoothstep(0.0, 250.0, t) * 0.7));
    // Subsurface Scattering (SSS): Translucent emerald & seafoam teal at wave crests; midnight navy in troughs
    float hn = clamp(y / (amp0() * 2.2), 0.0, 1.0);
    vec3 deepTrough = vec3(0.008, 0.024, 0.06);
    vec3 sssCrest = vec3(0.03, 0.54, 0.44);
    vec3 sssSunGlow = vec3(0.12, 0.82, 0.62);
    vec3 waterBody = mix(deepTrough, sssCrest, pow(hn, 1.8) * 1.35);
    waterBody += sssSunGlow * pow(hn, 3.0) * max(dot(-rd, L), 0.0) * 0.75;
    
    // Fresnel Reflection (Schlick approximation)
    float fr = 0.025 + 0.975 * pow(1.0 - max(dot(n, -rd), 0.0), 5.0);
    vec3 rf = reflect(rd, n);
    rf.y = abs(rf.y);
    vec3 refl = sky(rf, gPx);
    col = mix(waterBody, refl, fr);
    
    // Anisotropic Highlights (Specular Stretch): sunlight stretches into a dancing golden path
    vec3 sunDir = normalize(vec3(0.35, 0.14, 0.92));
    vec3 waveFlank = normalize(cross(n, vec3(0.0, 1.0, 0.0)));
    float anisoDot = dot(rf, sunDir);
    float anisoStretch = max(0.0, anisoDot - 0.40 * abs(dot(rf, waveFlank)));
    col += vec3(1.0, 0.85, 0.45) * pow(anisoStretch, 75.0) * (1.0 - uStorm * 0.6) * 4.2;
    col += vec3(1.0, 0.55, 0.22) * pow(anisoStretch, 14.0) * (1.0 - uStorm * 0.5) * 0.85;
    
    vec3 L2 = normalize(vec3(-0.35, 0.5, 0.8));
    col += vec3(0.6, 0.7, 1.0) * pow(max(dot(rf, L2), 0.0), 40.0) * uFlash * 5.0;
    
    // Dynamic Foam Generation (Whitecaps): Jacobian peak turbulence thresholding with organic trailing bubbles
    float foamThreshold = 0.62;
    float peakPinch = smoothstep(foamThreshold, 0.96, hn + (fbm(p.xz * 3.2 + T * 0.7) - 0.5) * 0.42);
    float foamBubbleNoise = fbm(p.xz * 7.5 - vec2(T * 1.6 * uWind, 0.0));
    float foamTrail = smoothstep(0.42, 0.88, foamBubbleNoise) * peakPinch;
    vec3 foamColor = mix(vec3(0.94, 0.97, 0.99), vec3(0.85, 0.90, 0.94), uStorm);
    col = mix(col, foamColor, clamp(peakPinch * 0.82 + foamTrail * 0.50, 0.0, 1.0));
    
    // Wave spray particles flung off wave crests in storm
    if(uStorm > 0.3){
      float sprayNoise = fbm(p.xz * 6.0 + vec2(T * 2.0 * uWind, 0.0));
      float spray = smoothstep(0.75, 0.95, sprayNoise) * peakPinch * uStorm;
      col = mix(col, vec3(0.88, 0.93, 0.98), spray * 0.7);
    }
    
    // Atmospheric Rayleigh Scattering & Horizon Blending: far ocean boundary seamlessly melts into sky haze
    float horizonDist = smoothstep(70.0, 360.0, t);
    vec3 horizonHaze = sky(vec3(rd.x, 0.02, rd.z), gPx);
    col = mix(col, horizonHaze, horizonDist);
  }
  
  // Rain streaks over storm surface
  col = drawRain(col, uv, gPx);
  
  // Meniscus line at waterline boundary with warm sunset glint
  col += vec3(1.0, 0.90, 0.72) * meniscus * 0.95;
  
  return col;
}`;

/* ---- Scene 1: River & Rain (Luminous Turquoise Water, Highlighted Banks, Leaping Fish) ---- */
const S1 = `uniform float uPit;uniform vec3 uRo,uFogC;
float bnk(vec2 p){return .35*sin(p.x*.3)*sin(p.y*.21)+.15*sin(p.x*.9+p.y*.5);}
float cxf(float z){return sin(z*.09)*2.6+sin(z*.23)*1.1;}
float Wf(float z){return 4.2+sin(z*.15);}
float rockH(vec2 p){
  vec2 c=floor(p/4.5),f=p/4.5-c-.5,r=h22(c+9.1);
  float rad=.35+.4*r.y,d=length((f-(r-.5)*.5)*4.5);
  return r.x>.45?sqrt(max(rad*rad-d*d,0.))*2.6:0.;
}
float bedh(vec2 p){
  float W=Wf(p.y),d=abs(p.x-cxf(p.y));
  float h=-1.35*(1.-smoothstep(0.,W*.95,d))+smoothstep(W*.9,W*1.7,d)*(1.15+bnk(p)+.12*vn(p*.8));
  return h+rockH(p)*(1.-smoothstep(W*.5,W*1.,d));
}
vec3 skyO(vec3 d){
  vec3 c=mix(uFogC,vec3(.2,.28,.35),clamp(d.y*1.6,0.,1.));
  c*=(.8+.35*fbm(d.xz/(d.y+.3)*1.2+T*.01*uWind));
  for(int b=0;b<2;b++){
    float fb=float(b);
    vec2 bp=vec2(-.9+mod(T*(.4+fb*.1)+fb*2.2,2.8)-.5,.3+sin(T*1.2+fb)*.08);
    vec2 bd=d.xy-bp;
    if(abs(bd.x)<.03&&abs(bd.y)<.02){
      float wing=abs(bd.x)*.7-bd.y+sin(T*16.+fb)*abs(bd.x)*1.1;
      if(abs(wing)<.004)c=mix(c,vec3(.15,.18,.22),.75);
    }
  }
  return c;
}
float rh(vec2 q){
  q+=(vec2(fbm(q+T*.1),fbm(q+7.3-T*.08))-.5)*.9;
  return fbm(q*vec2(2.2,.9))*.6+(1.-abs(vn(q*vec2(5.,2.2)+T*.1)*2.-1.))*.25;
}
vec2 rip(vec2 p){
  vec2 o=vec2(0.);
  for(int k=0;k<3;k++){
    float fk=float(k);
    vec2 q=p*(2.2+fk*1.3)+fk*17.,id=floor(q),f=fract(q)-.5,r=h22(id);
    float ph=fract(T*(.6+.3*r.y)+r.x+fk*.37),d=length(f-(r-.5)*.5),rr=ph*(.3+.25*r.x);
    float on=step(1.-(.15+.7*uCnt),h21(id+5.+fk));
    o+=(f-(r-.5)*.5)/(d+1e-3)*sin((d-rr)*(35.+20.*r.y))*exp(-pow((d-rr)*12.,2.))*(1.-ph)*(1.-ph)*on*(.5+r.y);
  }

  // Jumping Fish Splash Ripples
  float jumpTime=mod(T*.18,1.);
  vec2 jumpCenter=vec2(.5,15.);
  float jd=length(p-jumpCenter);
  float splashRing=jumpTime*3.2;
  float sWave=sin((jd-splashRing)*22.)*exp(-pow(jd-splashRing,2.)*4.)*smoothstep(.8,0.,jumpTime);
  o+=normalize(p-jumpCenter+1e-4)*sWave*.4;

  return o;
}

vec3 scene(vec2 uv){
  vec3 r=normalize(vec3(uv,1.6));
  float cp=cos(uPit),sp=sin(uPit);
  vec3 rd=vec3(r.x,r.y*cp+r.z*sp,-r.y*sp+r.z*cp),ro=uRo;
  float tt=.3,hit=-1.;
  for(int i=0;i<90;i++){
    vec3 p=ro+rd*tt;
    float h=p.y-bedh(p.xz);
    if(h<.004*tt){hit=tt;break;}
    tt+=max(.03,h*.5);
    if(tt>90.)break;
  }
  float tw=rd.y<0.?-ro.y/rd.y:1e5;
  vec3 col;
  if(rd.y<0.&&(hit<0.||tw<hit)){
    vec3 pw=ro+rd*tw;
    float dep=clamp(-bedh(pw.xz),0.,3.),W=Wf(pw.z),d=abs(pw.x-cxf(pw.z));
    float spd=(.6+.9*(1.-smoothstep(0.,W,d)))*(.5+.5*uWind)*smoothstep(0.,.6,dep+.15);
    vec2 q=vec2(pw.x,pw.z+T*spd);
    float r0=rh(q),e=.04;
    vec2 g=vec2(rh(q+vec2(e,0.))-r0,rh(q+vec2(0.,e))-r0)/e;
    g*=(1.+2.*smoothstep(.7,0.,dep))/(1.+tw*.05);
    vec2 o=rip(pw.xz)*exp(-tw*.05);
    vec3 n=normalize(vec3(-g.x*.22-o.x*.3,1.,-g.y*.22-o.y*.3));
    vec2 pb=pw.xz-n.xz*dep*.8;
    
    // HIGHLIGHTED RIVER WATER: Luminous alpine turquoise with bright caustics
    vec3 bed=pow(mix(vec3(.15,.35,.32),vec3(.1,.45,.42),vn(pb*4.))*(.8+.4*fbm(pb*10.)),vec3(2.2))*1.4;
    vec2 cq=pb*1.8+vec2(0.,T*.15);
    bed*=1.+pow(1.-abs(fbm(cq+fbm(cq*2.)*1.5)*2.-1.),4.)*.75;
    
    // Underwater Freshwater Trout
    for(int fi=0;fi<2;fi++){
      float ffi=float(fi);
      vec2 fishP=vec2(cxf(12.+ffi*8.)+(ffi-.5)*1.8, 14.+ffi*9.-mod(T*(.8+ffi*.4),18.));
      float distFish=length(pw.xz-fishP);
      if(distFish<.8&&dep>.4){
        float fishWiggle=sin(T*7.+pw.z*4.)*.12;
        vec3 troutCol=mix(vec3(.12,.45,.35),vec3(.85,.85,.6),smoothstep(.3,0.,abs(pw.x-fishP.x+fishWiggle)));
        bed=mix(bed,troutCol,smoothstep(.7,.1,distFish)*.75);
      }
    }

    // High-contrast turquoise alpine water body
    vec3 ab=exp(-dep*vec3(.4,.25,.18)*1.1);
    vec3 wat=bed*ab+(1.-ab)*vec3(.03,.48,.56);
    float fr=.03+.97*pow(1.-max(dot(n,-rd),0.),5.);
    vec3 rf=reflect(rd,n);rf.y=abs(rf.y);
    vec3 refl=mix(skyO(rf),vec3(.04,.25,.22),smoothstep(.5,1.,d/W)*(1.-smoothstep(0.,.35,rf.y)));
    col=mix(wat,refl,fr*.82);
    
    // Playful River Otter swimming along the riverbank
    vec2 otterP=vec2(pw.x-(cxf(16.)+.7),pw.z-(16.2+sin(T*.8)*.45));
    float otterBody=length(otterP*vec2(2.4,1.3));
    if(otterBody<.55&&dep>.25){
      vec3 otterFur=vec3(.16,.11,.07);
      col=mix(col,otterFur,smoothstep(.55,.2,otterBody));
    }
    
    // Luminous river foam and flow wakes
    col=mix(col,vec3(.75,.92,.95),smoothstep(.18,0.,dep)*smoothstep(.38,.65,fbm(q*5.))*.7);
    col=mix(col,uFogC,1.-exp(-tw*.025));
  } else if(hit>0.){
    vec3 p=ro+rd*hit;
    vec2 e=vec2(.06,0.);
    vec3 n=normalize(vec3(bedh(p.xz-e.xy)-bedh(p.xz+e.xy),.12,bedh(p.xz-e.yx)-bedh(p.xz+e.yx)));
    float rk=smoothstep(.1,.4,rockH(p.xz)),gn=fbm(p.xz*1.5);
    
    // HIGHLIGHTED RIVERBANK LAND: Warm mossy earth and vivid shoreline grass
    vec3 a=mix(vec3(.28,.22,.15),vec3(.18,.48,.12),smoothstep(.05,.65,p.y+gn*.5));
    a=mix(a,vec3(.42,.42,.38)*(.6+.8*vn(p.xz*12.)),rk);
    
    // Shoreline wildflowers and ferns
    float floraDense=smoothstep(.55,.85,fbm(p.xz*2.5))*(1.-rk);
    vec3 flowerCol=mix(vec3(.95,.85,.2),vec3(.92,.45,.6),h21(floor(p.xz*3.)));
    a=mix(a,flowerCol,floraDense*.45);

    // Riverside Brown Bear observing the river
    vec2 bearP=p.xz-vec2(-4.2,11.8);
    float bearBody=length(bearP*vec2(1.1,1.6));
    if(bearBody<1.15&&rk>.1){
      vec3 bearFur=mix(vec3(.22,.13,.07),vec3(.36,.22,.12),vn(bearP*10.));
      a=mix(a,bearFur,smoothstep(1.15,.7,bearBody));
    }

    // Riverside Blue Heron poised on a river rock
    vec2 heronP=p.xz-vec2(3.8,10.2);
    float heronBody=length(heronP*vec2(2.5,1.2));
    if(heronBody<.55&&rk>.12){
      vec3 heronFeathers=mix(vec3(.38,.48,.58),vec3(.75,.82,.88),heronP.y+.2);
      a=mix(a,heronFeathers,smoothstep(.55,.2,heronBody));
    }

    float wet=smoothstep(.8,0.,p.y);
    a=pow(a,vec3(2.2))*(1.-.3*wet);
    col=a*(vec3(.55,.6,.65)*(.55+.45*n.y)+vec3(1.,.95,.9)*.45*max(dot(n,L),0.));
    vec3 rf=reflect(rd,n);
    float pud=smoothstep(.55,.7,fbm(p.xz*.8))*(1.-smoothstep(.2,.5,p.y));
    col=mix(col,skyO(vec3(rf.x,abs(rf.y),rf.z)),pow(1.-max(dot(n,-rd),0.),4.)*.8*(.2+.8*max(wet,pud)));
    col=mix(col,uFogC,1.-exp(-hit*.03));
  } else {
    col=uFogC;
  }

  // Leaping Fish Feature in 3D Air
  float jT=mod(T*.18,1.);
  if(jT<.4){
    float prog=jT/.4;
    vec3 fishPos=vec3(.5+sin(prog*3.14159)*.4, sin(prog*3.14159)*1.3-.1, 15.-prog*4.);
    vec3 rayToFish=fishPos-ro;
    float distProj=dot(rayToFish,rd);
    if(distProj>0.){
      vec3 closest=ro+rd*distProj;
      float dRay=length(closest-fishPos);
      if(dRay<.25){
        vec3 fishColor=mix(vec3(.92,.95,.98),vec3(.18,.55,.45),prog);
        col=mix(col,fishColor,smoothstep(.25,.08,dRay));
      }
    }
  }

  return col;
}`;

/* ---- Scenes 2-4: Canopy / Autumn / Sakura (Dense 80-95% Grass, Vibrant Sakura Pink, Flying Birds) ---- */
const S2 = `uniform float uSea,uNC,uPit;uniform vec3 uRo,uFogC;uniform vec4 uCan[16];
float cl(vec2 q,float c){return smoothstep(c,c+.28,fbm(q+fbm(q*2.+T*.01)*.8));}
vec3 sunC(){return uSea<.5?vec3(1.,.95,.85):uSea<1.5?vec3(1.,.74,.45):vec3(1.,.92,.88);}
vec3 skyW(vec3 d){
  vec3 zn=uSea<.5?vec3(.1,.28,.7):uSea<1.5?vec3(.18,.32,.6):vec3(.22,.42,.8);
  float cov=uSea<.5?.5:uSea<1.5?.52:.55;
  vec3 c=mix(uFogC,zn,pow(clamp(d.y,0.,1.),.5));
  vec2 q=d.xz/(d.y+.4)*1.2+vec2(T*.012*uWind,T*.005);
  float dn=cl(q,cov),dl=cl(q+L.xz*.15,cov);
  vec3 cc=mix(vec3(.5,.55,.65),sunC()*1.1,clamp(.6+(dn-dl)*3.,0.,1.));
  c=mix(c,cc,dn*smoothstep(-.02,.2,d.y)*.92);
  float sd=max(dot(d,L),0.);
  c+=sunC()*(pow(sd,600.)*6.+pow(sd,10.)*.18);

  // Flying Birds System across Canopy, Autumn, and Sakura
  for(int b=0;b<3;b++){
    float fb=float(b);
    float birdSpd=.28+fb*.09;
    vec2 bp=vec2(-1.1+mod(T*birdSpd+fb*1.6,2.6)-.2,.28+sin(T*.9+fb*2.)*.09+fb*.12);
    vec2 bd=d.xy-bp;
    if(abs(bd.x)<.038&&abs(bd.y)<.024){
      float flap=sin(T*14.+fb*4.)*.6;
      float wing=abs(bd.x)*.65-bd.y+flap*abs(bd.x)*.9;
      if(abs(wing)<.004&&abs(bd.x)<.03){
        vec3 birdCol=uSea>1.5?vec3(.96,.96,1.):(uSea>0.5?vec3(.2,.18,.16):vec3(.25,.22,.18));
        c=mix(c,birdCol,.85);
      }
    }
  }

  return c;
}
float canSh(vec3 g){
  float tr=1.;
  float nz=fbm(g.xz*(1.8-uShS)+vec2(T*.12*uWind,T*.07)+L.xz*2.+sin(T*.3+g.zx)*.3);
  float lf=smoothstep(.35,.6,nz);
  for(int i=0;i<16;i++){
    if(float(i)>=uNC)break;
    vec4 c=uCan[i];
    vec3 sc=vec3(c.w,c.w*.7,c.w),o=(g-c.xyz)/sc,d=L/sc;
    float a=dot(d,d),b=dot(o,d),cc=dot(o,o)-1.,ds=b*b-a*cc;
    if(ds>0.&&(-b+sqrt(ds))>0.)tr*=exp(-2.*sqrt(ds)/a*(.12+1.5*lf)*(.6+.4*uSh));
  }
  return tr;
}

// Ground Vegetation: Realistic Waving Grass, Daisies with Yellow Centers, Curled Autumn Leaf Litter, and Pink Sakura Petals
vec3 groundFlora(vec2 p, vec3 a, float sea){
  // Wind-driven undulating surface displacement for individual grass blades
  vec2 windWave = vec2(
    sin(T * 2.4 * uWind + p.x * 3.2 + p.y * 2.1) * 0.035,
    cos(T * 1.9 * uWind + p.y * 2.8 + p.x * 1.4) * 0.025
  );
  vec2 grassUV = p + windWave;
  
  // Layer 1: Dense multi-height grass with blade ridges
  float grassPattern = fbm(grassUV * 9.0);
  float bladeNoise = sin(grassUV.x * 65.0 + sin(grassUV.y * 45.0) * 2.2);
  float bladeHighlight = smoothstep(0.3, 0.85, bladeNoise);
  
  vec3 baseGrass;
  if(sea > 1.5){
    // Sakura: Fresh spring lawn underneath fallen blossom petals
    baseGrass = mix(vec3(0.06, 0.22, 0.04), vec3(0.12, 0.32, 0.07), grassPattern);
    baseGrass = mix(baseGrass, vec3(0.20, 0.44, 0.12), bladeHighlight * 0.35);
    a = mix(a, baseGrass, 0.90);
  } else if(sea < 0.5){
    // Canopy: Lush ancient woodland forest floor with individual waving blades
    vec3 deepShade = vec3(0.04, 0.17, 0.03);
    vec3 meadowGreen = vec3(0.11, 0.31, 0.05);
    vec3 sunlitLime = vec3(0.25, 0.48, 0.09);
    baseGrass = mix(deepShade, meadowGreen, grassPattern);
    baseGrass = mix(baseGrass, sunlitLime, bladeHighlight * 0.45);
    a = mix(a, baseGrass, 0.92);
  } else {
    // Autumn: Forest floor covered in moss, earth, and dry grass
    vec3 dryMoss = vec3(0.18, 0.18, 0.06);
    vec3 earthBrown = vec3(0.22, 0.13, 0.05);
    baseGrass = mix(earthBrown, dryMoss, grassPattern);
    a = mix(a, baseGrass, 0.85);
  }

  // Layer 2: Natural Flora & Ground Cover by Environment
  if(sea < 0.5){
    // CANOPY ENVIRONMENT: Realistic White Daisy Flowers with Gold Centers + Small Forest Wildflowers
    // Daisy cluster distribution via organic density mask
    float daisyClusterMask = fbm(p * 0.75 + 1.2);
    
    for(int d = 0; d < 3; d++){
      float fd = float(d);
      vec2 dq = p * (5.5 + fd * 3.8) + fd * 14.3;
      vec2 dId = floor(dq);
      vec2 df = fract(dq) - 0.5;
      vec2 dr = h22(dId + 3.1);
      
      // Wind-nodding motion for flowers
      df += vec2(sin(T * 2.0 + dr.x * 6.28) * 0.02, cos(T * 1.6 + dr.y * 6.28) * 0.015);
      df = rot(dr.x * 6.28) * (df - (dr - 0.5) * 0.42);
      
      // Organic placement: denser in natural sunlit clearings
      float clusterProb = smoothstep(0.35, 0.75, daisyClusterMask + dr.x * 0.3);
      if(clusterProb > 0.40){
        float flowerRad = 0.065 + dr.y * 0.045; // Varying flower sizes
        float dist = length(df);
        
        // Daisy Petals SDF: 12-lobed ray florets with delicate petal gaps
        float angle = atan(df.y, df.x);
        float rayLobe = sin(angle * 12.0) * (flowerRad * 0.22);
        float petalMask = smoothstep(flowerRad + rayLobe, flowerRad + rayLobe - 0.015, dist);
        
        // Yellow/Gold Disc Floret Center
        float centerRad = flowerRad * 0.34;
        float centerMask = smoothstep(centerRad, centerRad - 0.01, dist);
        
        // Soft ambient shadow cast onto grass underneath
        float shadowMask = smoothstep(flowerRad * 1.2, flowerRad * 0.5, length(df - vec2(0.012, -0.012))) * 0.4;
        a = mix(a, a * 0.65, shadowMask * (1.0 - petalMask));
        
        // White daisy petals with gentle natural shading
        vec3 petalCol = vec3(0.97, 0.98, 0.96);
        petalCol = mix(petalCol, vec3(0.85, 0.90, 0.82), smoothstep(centerRad, flowerRad, dist) * 0.3);
        
        // Bright golden center with subtle amber ring
        vec3 centerCol = mix(vec3(0.98, 0.82, 0.06), vec3(0.88, 0.56, 0.02), smoothstep(0.0, centerRad, dist));
        
        vec3 flowerCol = mix(petalCol, centerCol, centerMask);
        a = mix(a, flowerCol, petalMask * clusterProb);
      }
    }
  } else if(sea > 1.5){
    // SAKURA ENVIRONMENT: Fallen Cherry Blossom Petal Litter on Lawn
    float petalClusterMask = fbm(p * 0.85 + 2.4);
    
    for(int s = 0; s < 3; s++){
      float fs = float(s);
      vec2 sq = p * (6.2 + fs * 4.2) + fs * 11.7;
      vec2 sId = floor(sq);
      vec2 sf = fract(sq) - 0.5;
      vec2 sr = h22(sId + 7.4);
      
      // Gentle wind drift across the ground
      sf += vec2(sin(T * 1.5 + sr.x * 5.0) * 0.018, cos(T * 1.2 + sr.y * 5.0) * 0.012);
      sf = rot(sr.x * 6.28) * (sf - (sr - 0.5) * 0.45);
      
      float petalRad = 0.045 + sr.y * 0.035;
      // Notched cherry blossom petal geometry
      float pAngle = atan(sf.y, sf.x);
      float notch = abs(sin(pAngle)) * (petalRad * 0.25);
      float petalDist = length(sf * vec2(1.1, 1.7)) - (petalRad - notch);
      float pMask = smoothstep(0.01, -0.01, petalDist);
      
      float clusterProb = smoothstep(0.28, 0.80, petalClusterMask + sr.y * 0.4);
      if(pMask > 0.0 && clusterProb > 0.32){
        // Soft ground shadow under fallen petal
        float pShadow = smoothstep(petalRad * 1.3, petalRad * 0.4, length(sf - vec2(0.008, -0.008))) * 0.35;
        a = mix(a, a * 0.7, pShadow * (1.0 - pMask));
        
        // Rich cherry blossom pink & blushing white tones
        vec3 pCol = mix(vec3(1.0, 0.65, 0.80), vec3(0.98, 0.92, 0.95), sr.y);
        if(sr.x > 0.60) pCol = mix(pCol, vec3(0.95, 0.32, 0.60), 0.5);
        a = mix(a, pCol, pMask * clusterProb);
      }
    }
  } else {
    // AUTUMN ENVIRONMENT: Fallen Autumn Leaf Litter with Irregular Curled Lobes
    float leafLitterMask = fbm(p * 0.70 + 4.1);
    
    for(int al = 0; al < 3; al++){
      float fal = float(al);
      vec2 lq = p * (5.0 + fal * 3.5) + fal * 16.5;
      vec2 lId = floor(lq);
      vec2 lf = fract(lq) - 0.5;
      vec2 lr = h22(lId + 5.9);
      
      // Wind rustling across ground
      lf += vec2(sin(T * 1.8 + lr.x * 6.0) * 0.015, cos(T * 1.4 + lr.y * 6.0) * 0.010);
      lf = rot(lr.x * 6.28) * (lf - (lr - 0.5) * 0.4);
      
      float leafRad = 0.065 + lr.y * 0.045;
      // Curled maple/oak leaf lobes
      float lAngle = atan(lf.y, lf.x);
      float lobe = sin(lAngle * 3.0) * (leafRad * 0.35) + abs(cos(lAngle * 5.0)) * (leafRad * 0.15);
      float leafDist = length(lf * vec2(1.2, 1.8)) - (leafRad + lobe);
      float lMask = smoothstep(0.012, -0.012, leafDist);
      
      float litterProb = smoothstep(0.25, 0.75, leafLitterMask + lr.x * 0.35);
      if(lMask > 0.0 && litterProb > 0.30){
        // Ground shadow beneath fallen leaf
        float lShadow = smoothstep(leafRad * 1.4, leafRad * 0.4, length(lf - vec2(0.015, -0.015))) * 0.45;
        a = mix(a, a * 0.6, lShadow * (1.0 - lMask));
        
        // Autumn palette: amber, copper, russet, and dry ochre
        vec3 lCol = pal(lr.y * 0.85);
        // Leaf vein highlight
        float vein = 1.0 - smoothstep(0.0, 0.006, abs(lf.x));
        lCol = mix(lCol, lCol * 1.25, vein * 0.4);
        a = mix(a, lCol, lMask * litterProb);
      }
    }
  }

  return a;
}

vec3 scene(vec2 uv){
  vec3 r=normalize(vec3(uv,1.6));
  float cp=cos(uPit),sp=sin(uPit);
  vec3 rd=vec3(r.x,r.y*cp+r.z*sp,-r.y*sp+r.z*cp),ro=uRo,col;
  if(rd.y>=-.002){
    col=skyW(rd);
    float az=atan(rd.x,rd.z);
    for(int k=0;k<3;k++){
      float fk=float(k),rh=.012+.035*fbm(vec2(az*3.+fk*9.,fk))*(1.+.5*fk)+.008*fk;
      if(rd.y<rh){
        vec3 tn=uSea>1.5?vec3(.12,.28,.08):(uSea<.5?vec3(.06,.16,.05):vec3(.28,.13,.05));
        col=mix(uFogC,tn*(.75+.5*vn(vec2(az*90.,rd.y*120.+fk))),.3+.2*fk);
      }
    }
  } else {
    float t=-ro.y/rd.y;
    vec3 g=ro+rd*t,a;
    float gn=fbm(g.xz*1.3),dt=exp(-t*.1),fd=mix(.5,fbm(g.xz*12.),dt);
    
    vec3 baseGround=uSea<.5?vec3(.08,.22,.03):(uSea<1.5?vec3(.22,.15,.07):vec3(.09,.24,.05));
    a=groundFlora(g.xz,baseGround,uSea);

    // Authentic Seasonal Wildlife Systems (Deer, Bears, Mountain Lion, Stag)
    if(uSea>1.5){
      // SAKURA: Japanese Sika Deer grazing peacefully in the pink flower meadow
      vec2 deerP=g.xz-vec2(2.4,8.8);
      float deerBody=length(deerP*vec2(1.5,1.0));
      if(deerBody<.85){
        vec3 deerCoat=mix(vec3(.72,.44,.22),vec3(.86,.58,.32),vn(deerP*8.));
        float spots=smoothstep(.07,.0,length(fract(deerP*8.5)-.5)-.16);
        deerCoat=mix(deerCoat,vec3(.96,.94,.92),spots*.85);
        a=mix(a,deerCoat,smoothstep(.85,.55,deerBody));
      }
    } else if(uSea<.5){
      // CANOPY: Forest Elk / Red Deer grazing in the underbrush
      vec2 elkP=g.xz-vec2(-2.6,9.8);
      float elkBody=length(elkP*vec2(1.4,0.95));
      if(elkBody<.95){
        vec3 elkCoat=mix(vec3(.38,.24,.14),vec3(.55,.36,.18),vn(elkP*6.));
        a=mix(a,elkCoat,smoothstep(.95,.6,elkBody));
      }
      
      // Woodland Brown Bear resting in the shaded background
      vec2 bearP=g.xz-vec2(3.6,13.5);
      float bearBody=length(bearP*vec2(1.1,1.4));
      if(bearBody<1.15){
        vec3 bearFur=mix(vec3(.22,.14,.08),vec3(.32,.20,.10),vn(bearP*10.));
        a=mix(a,bearFur,smoothstep(1.15,.75,bearBody));
      }

      // Mountain Lion / Cougar perched alertly on a mossy woodland outcrop
      vec2 lionP=g.xz-vec2(-4.0,7.5);
      float lionBody=length(lionP*vec2(1.8,1.0));
      if(lionBody<.72){
        vec3 lionCoat=mix(vec3(.68,.48,.26),vec3(.84,.62,.38),vn(lionP*8.));
        a=mix(a,lionCoat,smoothstep(.72,.45,lionBody));
      }
    } else {
      // AUTUMN: Majestic Antlered Stag in golden foliage
      vec2 stagP=g.xz-vec2(2.0,9.0);
      float stagBody=length(stagP*vec2(1.4,1.0));
      if(stagBody<.92){
        vec3 stagCoat=mix(vec3(.52,.28,.12),vec3(.68,.38,.18),vn(stagP*7.));
        a=mix(a,stagCoat,smoothstep(.92,.55,stagBody));
        // Antlers
        vec2 antlerP=stagP-vec2(.0,-.4);
        float antlers=abs(sin(antlerP.x*22.)*cos(antlerP.y*18.));
        if(length(antlerP)<.42){
          a=mix(a,vec3(.85,.78,.65),antlers*.75);
        }
      }

      // Autumn Foraging Black Bear
      vec2 aBearP=g.xz-vec2(-2.8,12.2);
      float aBear=length(aBearP*vec2(1.2,1.5));
      if(aBear<1.05){
        vec3 aBearFur=mix(vec3(.15,.11,.09),vec3(.25,.18,.14),vn(aBearP*9.));
        a=mix(a,aBearFur,smoothstep(1.05,.7,aBear));
      }
    }
    
    a=pow(a,vec3(2.2));
    float sunFiltering=canSh(g);
    col=a*(sunC()*3.*max(L.y,.1)*sunFiltering+(uSea>1.5?vec3(.55,.58,.72):vec3(.4,.5,.75))*.45);
    
    if(uSea<.5){
      float shaft=pow(max(dot(rd,L),0.),16.)*sunFiltering*.35;
      col+=sunC()*shaft;
    }

    col=mix(col,uFogC,1.-exp(-t*(uSea>1.5?.015:.012)));
  }
  return col;
}`;

/* ---- Scene 5: Cosmic Black Hole (Gargantua 4K Relativistic Accretion Disk, Spacetime Fabric Bending & Theme-Adaptive Universe) ----
   Engineered to support:
   - Portrait phone centering (centered directly in upper viewport window)
   - Light Mode (celestial white cosmic universe with dark spacetime fabric and lensing) vs Dark Mode (obsidian void universe)
   - Relativistic Spacetime Fabric curvature grid lines dipping into the singularity
   - Multi-octave differential Keplerian rotation (Omega ~ r^-1.35) with sub-pixel micro-filaments for 4K crispness
   - Dual relativistic gravitational lensing & photon sphere ring
*/
const S_BLACKHOLE = `
vec3 scene(vec2 uv){
  // Portrait-adaptive centering: in portrait (phones), center high at (0.0, 0.22); in landscape, center at (0.28, 0.12)
  bool isPortrait = R.x < R.y;
  vec2 center = isPortrait ? vec2(0.0, 0.24) : vec2(0.28, 0.12);
  vec2 p = uv - center;

  // Diagonal tilt of accretion disk (~ -27.5 degrees)
  float tilt = -0.48;
  mat2 rotM = rot(tilt);
  vec2 pr = rotM * p;

  float r = length(p);
  float r_s = .43; // Schwarzschild event horizon radius

  // Light Mode Universe (uTone < 0.5) vs Dark Mode Universe (uTone >= 0.5)
  bool isLightMode = uTone < 0.5;

  // Pure pitch-black inside event horizon (singularity shadow)
  if(r < r_s * .93){
    return isLightMode ? vec3(0.02, 0.02, 0.04) : vec3(0.001, 0.0008, 0.002);
  }

  // General relativistic gravitational deflection
  float deflect = pow(r_s / max(r, .01), 2.25) * .54;
  vec2 pBent = p - normalize(p + 1e-4) * deflect;
  vec2 prBent = rotM * pBent;

  // Keplerian differential orbital frequencies
  float rDisk = length(vec2(pr.x, pr.y * 3.4));
  float rDiskBent = length(vec2(prBent.x, prBent.y * 3.0));

  float ang = atan(pr.y, pr.x);
  float angBent = atan(prBent.y, prBent.x);

  float omega1 = .75 * pow(max(rDisk, .18), -1.25);
  float omega2 = 1.25 * pow(max(rDiskBent, .16), -1.4);

  float swirl1 = ang - T * omega1;
  float swirl2 = angBent - T * omega2;

  // 4K Multi-frequency plasma micro-filaments
  float fil1 = fbm(vec2(rDisk * 26., swirl1 * 5.));
  float fil2 = vn(vec2(rDisk * 65., swirl1 * 14. + T * .2));
  float fil3 = abs(sin(rDisk * 160. + fil1 * 5. + swirl1 * 8.));
  float fil4 = vn(vec2(rDisk * 120., swirl2 * 18.));
  float microStriations = clamp(fil1 * .45 + fil2 * .35 + fil3 * .25 + fil4 * .2, 0., 1.8);

  float filBent1 = fbm(vec2(rDiskBent * 32., swirl2 * 7.));
  float filBent2 = vn(vec2(rDiskBent * 85., swirl2 * 16.));
  float bentMicro = clamp(filBent1 * .55 + filBent2 * .45, 0., 1.6);

  // Relativistic Doppler beaming
  float doppler = clamp(.58 - pr.x * 1.45, .15, 3.2);
  float dopplerBoost = pow(doppler, 1.6);

  // 1. Equatorial Primary Accretion Disk
  float innerISCO = smoothstep(r_s * .96, r_s * 1.45, rDisk);
  float outerDisk = smoothstep(3.2, .5, rDisk);
  float diskThickness = exp(-abs(pr.y) * 19.);
  float diskIntensity = diskThickness * innerISCO * outerDisk * (.6 + microStriations * .65);

  // 2. Gravitational Lensing Top Arc
  float topArcDist = abs(r - r_s * 1.28);
  float topArcMask = smoothstep(r_s * .92, r_s * 1.06, r) * smoothstep(.48, .0, topArcDist);
  float topArc = exp(-topArcDist * 18.) * (.65 + bentMicro * .6) * topArcMask;

  // 3. Gravitational Lensing Bottom Arc
  float bottomArcDist = abs(r - r_s * 1.18);
  float bottomArcMask = smoothstep(r_s * .92, r_s * 1.06, r) * smoothstep(.32, .0, bottomArcDist);
  float bottomArc = exp(-bottomArcDist * 24.) * bottomArcMask * .85;

  // 4. Ultra-Thin Photon Sphere Ring
  float photonDist = abs(r - r_s * 1.018);
  float photonRing = exp(-photonDist * 72.) * 3.4;

  float totalLum = (diskIntensity * 2.2 + topArc * 1.9 + bottomArc * 1.2 + photonRing) * dopplerBoost;

  // Relativistic Spacetime Fabric Grid Lines (Curving down into singularity)
  vec2 gridUV = pBent * (isPortrait ? 8.5 : 6.5);
  float gridLine = smoothstep(.04, .0, abs(fract(gridUV.x)-.5)) + smoothstep(.04, .0, abs(fract(gridUV.y)-.5));
  float fabricDistort = exp(-r * 1.8) * gridLine * .35;

  // Theme-Adaptive Colors (Light Celestial Universe vs Dark Obsidian Universe)
  vec3 finalColor;
  if(isLightMode){
    // LIGHT MODE: Celestial white universe with dark spacetime curvature and luminous gold halo
    vec3 whiteSpace = vec3(.95, .96, .98);
    vec3 darkFabric = vec3(.15, .12, .18) * fabricDistort;
    
    vec3 goldHalo = vec3(.92, .52, .12) * totalLum;
    finalColor = whiteSpace - darkFabric + goldHalo * .8;

    // Dark lensed stars against white canvas
    vec2 starGrid = floor(pBent * 45.);
    float starRand = h21(starGrid);
    if(starRand > .982 && r > r_s * 1.1){
      finalColor -= vec3(.4, .4, .45);
    }
  } else {
    // DARK MODE: Deep obsidian void with starlight white and blazing accretion gold
    vec3 coreWhite = vec3(1.35, 1.28, 1.12);
    vec3 solarGold = vec3(1.10, .85, .32);
    vec3 warmAmber = vec3(.96, .54, .12);
    vec3 deepVermilion = vec3(.72, .18, .03);

    vec3 diskCol = mix(deepVermilion, warmAmber, clamp(totalLum * .55, 0., 1.));
    diskCol = mix(diskCol, solarGold, clamp(totalLum * .35 - .35, 0., 1.));
    diskCol = mix(diskCol, coreWhite, clamp(totalLum * .25 - .7, 0., 1.));

    vec2 warpedDustUV = pBent * 1.6 + vec2(T * .006, T * .003);
    float cosmicDust = fbm(warpedDustUV * 2.5 + fbm(warpedDustUV * 5.)) * .32;
    vec3 bgHaze = vec3(.12, .045, .018) * cosmicDust + vec3(.008, .006, .012);
    bgHaze += vec3(.3, .4, .6) * fabricDistort * .4;

    vec2 starGrid = floor(pBent * 55.);
    float starRand = h21(starGrid);
    if(starRand > .978 && r > r_s * 1.08){
      float starLensed = sin(T * 3. + starRand * 30.) * .35 + .75;
      float stretch = clamp(1.8 - r * 1.2, 1., 2.5);
      bgHaze += vec3(.85, .92, 1.) * starLensed * .7 * stretch;
    }

    finalColor = bgHaze + diskCol * totalLum;
  }

  // Knife-edge event horizon shadow cutoff
  float shadowCutoff = smoothstep(r_s * .93, r_s * .98, r);
  finalColor *= shadowCutoff;

  return finalColor;
}`;

// Strict Common Fragment Main (Responsive UV scaling for portrait mobile and desktop)
const COMMON_MAIN = `
void main() {
  // Portrait-adaptive UV: if R.x < R.y (phones/tablets in portrait), scale by R.x * 1.18 to prevent horizontal cropping
  vec2 uv = (gl_FragCoord.xy * 2.0 - R) / (R.x < R.y ? R.x * 1.18 : R.y);
  vec3 c = scene(uv);
  #if LIN
  c = clamp((c * (2.51 * c + 0.03)) / (c * (2.43 * c + 0.59) + 0.14), 0.0, 1.0);
  c = pow(c, vec3(0.4545));
  #endif
  c *= 1.0 - 0.22 * dot(uv * 0.5, uv * 0.5);
  c += (h21(gl_FragCoord.xy + fract(T)) - 0.5) / 200.0;
  gl_FragColor = vec4(c, 1.0);
}`;

/* ---- Geometry Shaders (Instanced Branches, Leaves, Falling Particles, Ground Flora) ---- */
const VPRE = `precision highp float;uniform vec2 R;uniform float T,uWind,uPit;uniform vec3 uRo;
attribute vec2 aQ;varying vec2 vUV;varying vec3 vN,vV;varying vec4 vC;varying float vT,vD;
vec4 proj(vec3 p){
  vec3 q=p-uRo;
  float c=cos(uPit),s=sin(uPit);
  vec3 v=vec3(q.x,q.y*c-q.z*s,q.y*s+q.z*c);
  float n=.1,f=300.;
  float asp = R.x / R.y;
  float sx = asp < 1.0 ? 1.888 : (1.6 / asp);
  float sy = asp < 1.0 ? (1.888 * asp) : 1.6;
  return vec4(sx*v.x, sy*v.y, (f+n)/(f-n)*v.z-2.*f*n/(f-n), v.z);
}
vec3 wind(vec3 p,float fl,float fa,float ph){
 float g=.5+.5*sin(dot(p.xz,vec2(.31,.17))-T*.8)*sin(dot(p.xz,vec2(-.11,.23))-T*.5+1.);
 float a=(.5+1.5*g)*uWind*fl;
 vec3 d=vec3(sin(T*.9+p.x*.4+p.z*.2)+.5*sin(T*1.7+p.z*.6+ph*6.),0.,.4*sin(T*.7+p.x*.3))*a*.16;d.y-=abs(d.x)*.15;
 return d+vec3(sin(T*(6.+ph*4.)+ph*40.),sin(T*(8.+ph*3.)+ph*17.),cos(T*(5.+ph*3.)+ph*29.))*fa*.03*uWind*(.4+g);}`;

const VB = VPRE + `attribute vec4 aA,aB,aR;
void main(){vec3 a=aA.xyz+wind(aA.xyz,aA.w,0.,0.),b=aB.xyz+wind(aB.xyz,aB.w,0.,0.),pm=mix(a,b,aQ.y),ax=b-a,vd=normalize(uRo-pm);
 vec3 sd=normalize(cross(ax,vd)+1e-5);float r=mix(aR.x,aR.y,aQ.y);
 vN=normalize(sd*aQ.x+vd*sqrt(max(1.-aQ.x*aQ.x,0.)));vUV=vec2(aQ.x,aQ.y*length(ax));vC=vec4(aR.z,0.,aR.w,0.);vT=0.;vV=vd;vD=length(uRo-pm);
 gl_Position=proj(pm+sd*aQ.x*r);}`;

const VL = VPRE + `attribute vec4 aP,aN,aC;
void main(){vec3 n=normalize(aN.xyz),t=normalize(cross(n,vec3(.31,.93,.2))),b=cross(n,t);float c=cos(aN.w),s=sin(aN.w);vec3 t2=t*c+b*s,b2=-t*s+b*c;
 vec3 w=wind(aP.xyz,aC.y,aC.y,aC.x);bool lf=aC.w<1.5;
 vec3 off=lf?t2*aQ.x*.55+b2*aQ.y*1.1:(t2*aQ.x+b2*(aQ.y*2.-1.))*.8,p=aP.xyz+w+off*aP.w;
 vN=normalize(n+w*3.);vUV=lf?aQ:vec2(aQ.x,aQ.y*2.-1.);vC=vec4(aC.x,0.,aC.z,0.);vT=aC.w;vV=normalize(uRo-p);vD=length(uRo-p);gl_Position=proj(p);}`;

const VP = VPRE + `attribute float aId;uniform float uKind,uMax;
float hh(float x){return fract(sin(x*127.1+311.7)*43758.5453);}
void main(){vT=uKind>1.5?4.:(uKind>.5?3.:1.);
 if(aId>=uMax){gl_Position=vec4(2.,2.,2.,1.);return;}
 vec3 r=vec3(hh(aId),hh(aId+17.3),hh(aId+41.9));
 float P=uKind>1.5?.8+.6*r.x:(uKind>.5?15.+7.*r.x:11.+6.*r.x),age=mod(T+r.y*P,P),tau=uKind>1.5?.12:.7,top=uKind>1.5?10.:12.;
 float fd=(age-tau*(1.-exp(-age/tau)))/(P-tau);
 vec3 p=vec3(mix(-18.,18.,r.z)+uRo.x,max(top*(1.-fd),.03),mix(1.5,36.,pow(hh(aId+7.7),uKind>.5?1.5:1.)));
 if(uKind<1.5){float pe=uKind,fl=1.+.5*pe;
  p.x+=uWind*age*(.35+.6*r.x)*(1.-.4*pe)+sin(age*(1.1+r.y*1.4)+r.z*30.)*(.45+.35*pe)*fl+sin(age*.7+p.z*.2)*uWind*.8;
  p.z+=cos(age*(.8+r.z)+r.x*20.)*.5*fl;p.x=uRo.x+mod(p.x-uRo.x+18.,36.)-18.;
  float tilt=1.1*sin(age*(1.1+r.y*1.4)+r.z*9.)+step(.75,r.x)*age*1.4,az=age*(.5+r.z)*.8+r.x*6.28;
  vec3 n=vec3(sin(tilt)*cos(az),cos(tilt),sin(tilt)*sin(az)),t=normalize(cross(n,vec3(.31,.93,.2))),b=cross(n,t);
  float sp=age*(1.+3.*r.y)*(r.x>.5?1.:-1.)+r.z*6.28;vec3 t2=t*cos(sp)+b*sin(sp),b2=-t*sin(sp)+b*cos(sp);
  float sz=uKind<.5?.12+.07*r.x:.06+.05*r.y+.03*r.x;
  vec3 off=uKind<.5?t2*aQ.x*.55+b2*aQ.y*1.1:(t2*aQ.x+b2*(aQ.y*2.-1.))*.8,q=p+off*sz;
  vN=n;vUV=uKind<.5?aQ:vec2(aQ.x,aQ.y*2.-1.);vC=vec4(uKind<.5?r.z*.72:r.z,0.,1.,0.);vV=normalize(uRo-q);vD=length(uRo-q);gl_Position=proj(q);}
 else{p.x+=uWind*(top-p.y)*.12;vec4 c0=proj(p),c1=proj(p+vec3(uWind*.12,.45,0.));
  vec2 a0=c0.xy/c0.w,a1=c1.xy/c1.w,asp=vec2(R.x/R.y,1.),dr=normalize((a1-a0)*asp+1e-5),pp=vec2(-dr.y,dr.x)/asp;
  vec4 c=mix(c0,c1,aQ.y);vD=length(uRo-p);vUV=aQ;vC=vec4(.5*exp(-vD*.05)*(.4+.6*r.x),0.,1.,0.);vN=vec3(0,1,0);vV=vec3(0,1,0);
  gl_Position=c+vec4(pp*aQ.x*.0014*c.w,0.,0.);}}`;

const FG = 'precision highp float;' + PAL + `uniform vec2 R;uniform float T,uSea,uWet,uSunI,uFogD;uniform vec3 L,uFogC;
varying vec2 vUV;varying vec3 vN,vV;varying vec4 vC;varying float vT,vD;
float h21(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h21(i),h21(i+vec2(1,0)),f.x),mix(h21(i+vec2(0,1)),h21(i+vec2(1,1)),f.x),f.y);}

// Rich, vibrant, unmistakable cherry blossom pink palette
vec3 sak(float s){
  vec3 c = mix(vec3(1.0, 0.38, 0.65), vec3(0.96, 0.18, 0.52), smoothstep(0.1, 0.38, s));
  c = mix(c, vec3(1.0, 0.65, 0.82), smoothstep(0.4, 0.68, s));
  return mix(c, vec3(0.92, 0.10, 0.42), smoothstep(0.7, 0.98, s));
}

void main(){
 if(vT>3.5){gl_FragColor=vec4(.8,.86,.92,vC.x*(1.-abs(vUV.x))*smoothstep(0.,.25,vUV.y)*smoothstep(1.,.6,vUV.y));return;}
 vec3 N=normalize(vN),V=normalize(vV);if(dot(N,V)<0.)N=-N;vec3 alb;float tr=0.,sp=.1;
 if(vT<.5){float st=vn(vec2(vUV.x*5.,vUV.y*1.2+vC.x*20.)),rid=1.-abs(vn(vec2(vUV.x*9.+vC.x*9.,vUV.y*2.))*2.-1.);
  alb=mix(uSea>1.5?vec3(.1,.065,.07):vec3(.2,.13,.08),vec3(.34,.27,.2),st*.6)*(.5+.7*rid);sp=.03;}
 else if(vT<1.5){float tt=vUV.y,hw=.9*pow(sin(3.14159*pow(clamp(tt,0.,1.),.8)),.7)*(1.+.04*sin(tt*50.));
  if(abs(vUV.x)>hw||tt<.02)discard;float s=vC.x;
  alb=uSea<.5?mix(vec3(.04,.18,.02),vec3(.26,.45,.06),s):uSea<1.5?pal(s):mix(vec3(.2,.2,.06),vec3(.34,.22,.08),s);
  float mid=smoothstep(.07,0.,abs(vUV.x)),sv=smoothstep(.07,0.,abs(fract(tt*6.-abs(vUV.x)*1.2)-.5))*smoothstep(0.,.15,abs(vUV.x));
  alb=mix(alb,alb*1.5+.05,mid*.5+sv*.2)*(.8+.2*smoothstep(hw,hw*.6,abs(vUV.x)));tr=.55;}
 else{vec2 u=vUV;
  if(vT<2.5){float r=length(u),th=atan(u.y,u.x),sn=sin(2.5*th),R2=(.62+.36*abs(cos(2.5*th)))*(1.-.2*exp(-pow(sn*5.,2.)));if(r>R2)discard;
   vec3 pc=sak(vC.x);float e=r/R2;
   alb=mix(pc*.92,min(pc*1.08+.04,vec3(1.)),smoothstep(.3,1.,e));
   alb*=1.-.16*smoothstep(.1,0.,abs(sn))*smoothstep(.1,.5,r);
   alb=mix(alb,vec3(.85,.18,.45),smoothstep(.3,0.,r)*.85);
   float a2=mod(th,.6283)-.3141;vec2 sq=vec2(cos(a2),sin(a2))*r-vec2(.2,0.);
   alb=mix(alb,vec3(1.,.8,.3),smoothstep(.05,.02,length(sq))*step(r,.4));
   alb*=.82+.25*abs(cos(2.5*th))*smoothstep(0.,.8,e);N=normalize(N+vec3(0.,.25,0.)*(e-.5));}
  else{float as=mix(.5,.8,fract(vC.x*7.));if(length(u*vec2(1.,as))>.95||(u.y>.7&&abs(u.x)<.1*(1.5-as)))discard;
   vec3 pc=sak(vC.x);alb=mix(pc*.95,min(pc*1.1+.04,vec3(1.)),smoothstep(-1.,.8,u.y))*(.9+.1*vn(u*8.));
   alb*=1.-.12*smoothstep(.12,0.,abs(u.x))*step(0.,u.y+.2);}
  alb*=.82;tr=.7;}
 alb=pow(alb,vec3(2.2))*(1.-.35*uWet);
 float dl=dot(N,L),fr=max(dl,0.),bk=max(-dl,0.);
 vec3 sun=(uSea<.5?vec3(1.,.95,.85):uSea<1.5?vec3(1.,.76,.5):vec3(1.,.92,.88))*3.*uSunI;
 vec3 amb=uSea<.5?vec3(.35,.5,.8):uSea<1.5?vec3(.55,.5,.5):vec3(.55,.58,.72);
 float vis=mix(.1,1.,vC.z*vC.z),ao=mix(.25,1.,vC.z);
 vec3 col=alb*(sun*(fr+tr*bk)*vis+amb*ao*(.55+.45*N.y)*(uWet>.5?.9:.55));
 col+=sun*pow(max(dot(N,normalize(L+V)),0.),mix(24.,90.,uWet))*(sp+.25*uWet*step(.5,vT))*vis*fr;
 col=mix(col,uFogC,1.-exp(-vD*uFogD));
 col=clamp((col*(2.51*col+.03))/(col*(2.43*col+.59)+.14),0.,1.);col=pow(col,vec3(.4545));
 vec2 uv=(gl_FragCoord.xy*2.-R)/(R.x < R.y ? R.x * 1.18 : R.y);gl_FragColor=vec4(col*(1.-.22*dot(uv*.5,uv*.5)),1.);}`;

/* =========================================================================
   PROCEDURAL TREE SYNTHESIS (Deterministic PRNG & Canopy Bounding Volumes)
   ========================================================================= */
const mulberry = (a: number) => () => {
  a |= 0;
  a = (a + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const nrm = (a: number[]): number[] => {
  const l = Math.hypot(a[0], a[1], a[2]) || 1;
  return [a[0] / l, a[1] / l, a[2] / l];
};
const crs = (a: number[], b: number[]): number[] => [
  a[1] * b[2] - a[2] * b[1],
  a[2] * b[0] - a[0] * b[2],
  a[0] * b[1] - a[1] * b[0]
];
const ad = (a: number[], b: number[]): number[] => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const ml = (a: number[], s: number): number[] => [a[0] * s, a[1] * s, a[2] * s];
const cone = (d: number[], rng: () => number, ang: number): number[] => {
  const t = nrm(crs(d, [rng() - 0.5, rng() - 0.2, rng() - 0.5]));
  const b = crs(d, t);
  const az = rng() * 6.283;
  const sa = Math.sin(ang);
  return nrm(ad(ml(d, Math.cos(ang)), ad(ml(t, sa * Math.cos(az)), ml(b, sa * Math.sin(az)))));
};

function genTree(
  x: number,
  y0: number,
  z: number,
  rng: () => number,
  mode: number,
  S: number[],
  Lf: number[],
  Ld: number[],
  cans: number[][]
) {
  const D = 5;
  const H = (mode === 2 ? 4.5 : 5.2) + rng() * (mode === 2 ? 5.5 : 4.5);
  const tips: Array<{ p: number[]; d: number[]; hue: number; bare: boolean }> = [];
  const th = rng();

  function grow(p: number[], d: number[], len: number, r: number, dep: number, hue: number, bare: boolean) {
    let pos = p;
    let dir = d;
    const pts: number[][] = [];
    for (let i = 0; i < 3; i++) {
      dir = nrm(
        ad(dir, [
          (rng() - 0.5) * 0.35,
          (rng() - 0.5) * 0.2 - (dep > 1 ? 0.1 : 0) + (mode === 2 ? 0 : 0.04),
          (rng() - 0.5) * 0.35
        ])
      );
      const q = ad(pos, ml(dir, len / 3));
      const f0 = (dep + i / 3) / (D + 1);
      const f1 = (dep + (i + 1) / 3) / (D + 1);
      S.push(
        pos[0], pos[1], pos[2], i + dep ? Math.pow(f0, 1.7) : 0,
        q[0], q[1], q[2], Math.pow(f1, 1.7),
        r * (1 - 0.3 * (i / 3)), r * (1 - 0.3 * ((i + 1) / 3)) * 0.96,
        rng(), 0.5 + 0.5 * Math.min(1, (pos[1] - y0) / H)
      );
      pts.push(q);
      pos = q;
    }
    if (dep === D) {
      tips.push({ p: pos, d: dir, hue, bare });
      return;
    }
    const nk =
      dep === 0
        ? 3 + ((rng() * 2) | 0)
        : 2 + (rng() < 0.45 ? 1 : 0) + (mode === 2 && dep > 0 && rng() < 0.4 ? 1 : 0);
    for (let k = 0; k < nk; k++) {
      grow(
        dep < 2 && k > 0 ? pts[(rng() * 2) | 0] : pos,
        cone(dir, rng, (0.5 + rng() * 0.55) * (mode === 2 ? 1.2 : 1)),
        len * (0.6 + rng() * 0.22),
        r * 0.6,
        dep + 1,
        dep === 0 ? rng() : hue,
        dep === 0 ? rng() < 0.2 : bare
      );
    }
  }

  grow(
    [x, y0 - 0.1, z],
    nrm([(rng() - 0.5) * (mode === 2 ? 0.5 : 0.2), 1, (rng() - 0.5) * 0.2]),
    H * (mode === 2 ? 0.38 : 0.45),
    (mode === 2 ? 0.28 : 0.22) + rng() * 0.1,
    0,
    0,
    false
  );
  let c = [0, 0, 0];
  tips.forEach((t) => (c = ad(c, t.p)));
  c = ml(c, 1 / tips.length);
  let R = 0;
  tips.forEach((t) => (R = Math.max(R, Math.hypot(t.p[0] - c[0], t.p[1] - c[1], t.p[2] - c[2]))));
  R += 0.4;
  cans.push([c[0], c[1], c[2], R * 0.85, z]);

  for (const t of tips) {
    const nL = mode === 2 ? (z > 24 ? 12 : 20) : mode === 1 ? (t.bare ? 2 : 10) : 16;
    for (let i = 0; i < nL; i++) {
      const bl = mode === 2 && i < (z > 24 ? 10 : 16);
      const ps = ad(ad(t.p, ml(t.d, -rng() * (mode === 2 ? 0.9 : 0.5))), [
        (rng() - 0.5) * 0.7,
        (rng() - 0.5) * 0.5,
        (rng() - 0.5) * 0.7
      ]);
      const dv = [ps[0] - c[0], ps[1] - c[1], ps[2] - c[2]];
      const o = nrm(dv);
      const ex = Math.min(1.2, Math.hypot(dv[0], dv[1], dv[2]) / R);
      const n = nrm([(rng() - 0.5) * 1.6 + o[0] * 0.6, 0.5 + rng() * 0.6, (rng() - 0.5) * 1.6 + o[2] * 0.6]);
      const ao = Math.max(0.05, Math.min(1, 0.2 + 0.65 * ex + 0.25 * (o[0] * Ld[0] + o[1] * Ld[1] + o[2] * Ld[2])));
      let seed = rng();
      if (mode === 2) seed = Math.min(1, th * 0.45 + rng() * 0.55);
      if (mode === 1) {
        seed = Math.min(1, (th * 0.4 + t.hue * 0.35 + rng() * 0.25) * 0.75);
        if (rng() < 0.04) seed = 0.9;
      }
      Lf.push(
        ps[0], ps[1], ps[2], bl ? (0.07 + 0.07 * rng()) * (z > 24 ? 1.35 : 1) : 0.11 + 0.08 * rng(),
        n[0], n[1], n[2], rng() * 6.28,
        seed, 0.8 + 0.2 * rng(), ao, bl ? 2 : 1
      );
    }
  }
}

interface SceneDef {
  bg: number;
  river?: number;
  sea?: number;
  mode?: number;
  fog?: number[];
  fd?: number;
  wet?: number;
  sun?: number;
  pit?: number;
  kind?: number;
  pn?: number;
}

const SCN: SceneDef[] = [
  { bg: 0 }, // 0: Stormy Ocean
  { bg: 1, river: 1, sea: 0, mode: 0, fog: [0.5, 0.55, 0.6], fd: 0.03, wet: 1, sun: 0.45, pit: -0.14, kind: 2, pn: 3000 }, // 1: River & Rain
  { bg: 2, sea: 0, mode: 0, fog: [0.5, 0.66, 0.86], fd: 0.008, pit: 0.06 }, // 2: Canopy
  { bg: 2, sea: 1, mode: 1, fog: [0.7, 0.5, 0.34], fd: 0.011, pit: 0.06, kind: 0, pn: 900 }, // 3: Autumn
  { bg: 2, sea: 2, mode: 2, fog: [0.74, 0.76, 0.84], fd: 0.01, pit: 0.05, kind: 1, pn: 1600 }, // 4: Sakura
  { bg: 3 } // 5: Cosmic Black Hole
];

const ss = (a: number, b: number, x: number) => {
  x = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return x * x * (3 - 2 * x);
};

const weatherToSceneIdx = (mode: WeatherMode): number => {
  switch (mode) {
    case 'storming': return 0;
    case 'raining': return 1;
    case 'leaves': return 2;
    case 'autumn': return 3;
    case 'sakura': return 4;
    case 'blackhole': return 5;
    default: return 2;
  }
};

/* =========================================================================
   REACT COMPONENT INTEGRATION
   ========================================================================= */
const AmbientBackgroundBase: React.FC<AmbientBackgroundProps> = ({
  enabled = true,
  speed = 'slow',
  weatherMode = 'leaves',
  gustTrigger = 0,
  lowPowerMode = false,
  tone = 0
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const snapshotCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [initFailed, setInitFailed] = useState(false);

  const ctrlRef = useRef({
    sceneIdx: weatherToSceneIdx(weatherMode),
    enabled,
    speed,
    gustBonus: 0,
    gustTimer: null as any,
    lowPower: lowPowerMode,
    tone
  });

  useEffect(() => {
    ctrlRef.current.sceneIdx = weatherToSceneIdx(weatherMode);
    ctrlRef.current.enabled = enabled;
    ctrlRef.current.speed = speed;
    ctrlRef.current.lowPower = lowPowerMode;
    ctrlRef.current.tone = tone;
  }, [weatherMode, enabled, speed, lowPowerMode, tone]);

  useEffect(() => {
    if (gustTrigger > 0) {
      ctrlRef.current.gustBonus = 1.0;
      if (ctrlRef.current.gustTimer) clearTimeout(ctrlRef.current.gustTimer);
      ctrlRef.current.gustTimer = setTimeout(() => {
        ctrlRef.current.gustBonus = 0;
      }, 2200);
    }
    return () => {
      if (ctrlRef.current.gustTimer) clearTimeout(ctrlRef.current.gustTimer);
    };
  }, [gustTrigger]);

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;

    const gopt: WebGLContextAttributes = {
      antialias: false,
      alpha: true,
      depth: true,
      stencil: false,
      preserveDrawingBuffer: true,
      powerPreference: 'default'
    };

    let gl: WebGLRenderingContext | WebGL2RenderingContext | null = null;
    try {
      gl = (cv.getContext('webgl2', gopt) ||
        cv.getContext('webgl', gopt) ||
        cv.getContext('experimental-webgl', gopt)) as any;
    } catch (e) {
      console.warn('[Ambient3D] WebGL context acquisition threw:', e);
    }

    if (!gl) {
      console.warn('[Ambient3D] WebGL not supported or disabled. Using atmospheric CSS fallback.');
      setInitFailed(true);
      return;
    }

    const gl2 = typeof WebGL2RenderingContext !== 'undefined' && gl instanceof WebGL2RenderingContext;
    const iext = gl2 ? null : gl.getExtension('ANGLE_instanced_arrays');
    const canGeo = gl2 || !!iext;

    const vdiv = (i: number, d: number) => {
      if (gl2) {
        (gl as WebGL2RenderingContext).vertexAttribDivisor(i, d);
      } else if (iext) {
        iext.vertexAttribDivisorANGLE(i, d);
      }
    };

    const drawI = (c: number) => {
      if (gl2) {
        (gl as WebGL2RenderingContext).drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, c);
      } else if (iext) {
        iext.drawArraysInstancedANGLE(gl.TRIANGLE_STRIP, 0, 4, c);
      }
    };

    const UV = {
      R: [2, 2],
      uRes: [2, 2],
      uQuality: 1.0,
      T: 0,
      uWind: 1,
      uSh: 0.8,
      uShS: 0.6,
      uCnt: 0.6,
      uFlash: 0,
      uStorm: 0.5,
      uLowQ: 0,
      uTone: 0,
      L: [0, 1, 0],
      uSea: 0,
      uNC: 0,
      uPit: 0.05,
      uRo: [0, 1.7, 0],
      uCan: new Float32Array(64),
      uFogC: [0.5, 0.66, 0.86],
      uWet: 0,
      uSunI: 1,
      uFogD: 0.01,
      uKind: 0,
      uMax: 0
    };

    function compileShader(t: number, s: string, name: string) {
      const o = gl!.createShader(t);
      if (!o) return null;
      gl!.shaderSource(o, s);
      gl!.compileShader(o);
      if (!gl!.getShaderParameter(o, gl!.COMPILE_STATUS)) {
        const info = gl!.getShaderInfoLog(o);
        console.error(`[Ambient3D] Compilation error in ${name}:`, info);
        gl!.deleteShader(o);
        return null;
      }
      return o;
    }

    interface ProgData {
      p: WebGLProgram;
      l: Record<string, WebGLUniformLocation | null>;
    }

    function mk(v: string, f: string, binds: string[], name: string): ProgData | null {
      const vs = compileShader(gl!.VERTEX_SHADER, v, name + '_VS');
      const fs = compileShader(gl!.FRAGMENT_SHADER, f, name + '_FS');
      if (!vs || !fs) return null;

      const p = gl!.createProgram();
      if (!p) return null;

      gl!.attachShader(p, vs);
      gl!.attachShader(p, fs);

      binds.forEach((n, i) => gl!.bindAttribLocation(p, i, n));
      gl!.linkProgram(p);

      if (!gl!.getProgramParameter(p, gl!.LINK_STATUS)) {
        console.error(`[Ambient3D] Program link error in ${name}:`, gl!.getProgramInfoLog(p));
        gl!.deleteProgram(p);
        return null;
      }

      const l: Record<string, WebGLUniformLocation | null> = {};
      for (const k in UV) {
        l[k] = gl!.getUniformLocation(p, k);
      }
      return { p, l };
    }

    function setU(g: ProgData) {
      for (const k in UV) {
        const l = g.l[k];
        if (l == null) continue;
        const v = (UV as any)[k];
        if (typeof v === 'number') {
          gl!.uniform1f(l, v);
        } else if (v.length === 2) {
          gl!.uniform2fv(l, v);
        } else if (v.length === 3) {
          gl!.uniform3fv(l, v);
        } else if (v.length === 4 || v instanceof Float32Array) {
          gl!.uniform4fv(l, v);
        }
      }
    }

    const FSV = 'attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}';
    const P: Record<string, ProgData | null> = {};

    const bgP = (i: number) => {
      const key = 'b' + i;
      if (P[key] !== undefined) return P[key];
      const sceneBody = i === 5 ? S_BLACKHOLE : [S0, S1, S2][i === 0 ? 0 : i === 1 ? 1 : 2];
      const fullFrag = '#define LIN 1\n' + COMMON_HEAD + '\n' + PAL + '\n' + sceneBody + '\n' + COMMON_MAIN;
      P[key] = mk(FSV, fullFrag, ['a'], 'BG_' + i);
      return P[key];
    };

    const mkG = (k: string, v: string, attribs: string[]) => {
      if (P[k] !== undefined) return P[k];
      P[k] = mk(v, FG, attribs, 'GEO_' + k);
      return P[k];
    };

    const mkBuf = (d: Float32Array) => {
      const b = gl!.createBuffer()!;
      gl!.bindBuffer(gl!.ARRAY_BUFFER, b);
      gl!.bufferData(gl!.ARRAY_BUFFER, d, gl!.STATIC_DRAW);
      return b;
    };

    const triBuf = mkBuf(new Float32Array([-1, -1, 3, -1, -1, 3]));
    const quadBuf = mkBuf(new Float32Array([-1, 0, 1, 0, -1, 1, 1, 1]));
    const idBuf = mkBuf(new Float32Array(Array.from({ length: 3000 }, (_, i) => i)));
    const segBuf = gl!.createBuffer()!;
    const leafBuf = gl!.createBuffer()!;
    let nSeg = 0;
    let nLeaf = 0;

    function buildGeo(i: number) {
      const sc = SCN[i];
      nSeg = nLeaf = 0;
      UV.uNC = 0;
      UV.uCan.fill(0);
      if (!sc.river && sc.mode === undefined) return;

      const rng = mulberry(1234 + i * 77);
      const S: number[] = [];
      const Lf: number[] = [];
      const cans: number[][] = [];
      const Ld = nrm([0.45, 0.55, 0.35]);
      const placed: number[][] = [];
      
      const nT = sc.river ? 10 : sc.mode === 2 ? 16 : 12;

      for (let k = 0, tr = 0; k < nT && tr < 250; tr++) {
        let z = 0;
        let x = 0;
        let y0 = 0;
        const side = (k % 2 === 0 ? -1 : 1);

        if (sc.river) {
          // River & Rain: Natural riverbank trees placed nicely along both banks
          z = k < 4 ? 4.5 + (k / 4) * 3.5 + rng() * 1.5 : k < 8 ? 8.5 + ((k - 4) / 4) * 6.0 + rng() * 2.0 : 15.0 + rng() * 10.0;
          const W = 3.6 + Math.sin(z * 0.15) * 0.8;
          const cx = Math.sin(z * 0.09) * 2.2 + Math.sin(z * 0.23) * 0.9;
          const shoreDist = W + 0.8 + rng() * 2.2;
          x = cx + side * shoreDist;
          y0 = ss(W * 0.85, W * 1.5, shoreDist) * (1.15 + 0.35 * Math.sin(x * 0.3) * Math.sin(z * 0.21)) - 0.05;

          if (placed.some((q) => Math.hypot(q[0] - x, (q[1] - z) * 0.6) < 1.6)) continue;
          placed.push([x, z]);
          k++;
          genTree(x, y0, z, rng, 0, S, Lf, Ld, cans);
        } else if (sc.mode === 2) {
          // Sakura: 16 cherry blossom trees framing the edges and filling the mid-depth
          z = k < 6 ? 3.5 + (k / 6) * 4.5 + rng() * 1.2 : k < 12 ? 8.5 + ((k - 6) / 6) * 6.5 + rng() * 1.8 : 16.0 + rng() * 8.0;
          x = side * (1.2 + (k % 3) * 0.8 + rng() * 1.2);
          y0 = 0;

          const isBackgroundGreenTree = z > 20 && rng() < 0.35;
          const treeMode = isBackgroundGreenTree ? 0 : 2;

          if (placed.some((q) => Math.hypot(q[0] - x, (q[1] - z) * 0.6) < 1.6)) continue;
          placed.push([x, z]);
          k++;
          genTree(x, y0, z, rng, treeMode, S, Lf, Ld, cans);
        } else if (sc.mode === 1) {
          // Autumn: 12 golden foliage trees framing left and right with depth
          z = k < 4 ? 3.6 + (k / 4) * 4.2 + rng() * 1.4 : k < 8 ? 8.2 + ((k - 4) / 4) * 6.2 + rng() * 2.0 : 15.0 + rng() * 8.0;
          x = side * (1.1 + (k % 3) * 0.9 + rng() * 1.1);
          y0 = 0;

          if (placed.some((q) => Math.hypot(q[0] - x, (q[1] - z) * 0.6) < 1.6)) continue;
          placed.push([x, z]);
          k++;
          genTree(x, y0, z, rng, 1, S, Lf, Ld, cans);
        } else {
          // Canopy (mode 0): 12 lush green trees
          z = k < 4 ? 3.6 + (k / 4) * 4.2 + rng() * 1.4 : k < 8 ? 8.2 + ((k - 4) / 4) * 6.2 + rng() * 2.0 : 15.0 + rng() * 8.0;
          x = side * (1.1 + (k % 3) * 0.9 + rng() * 1.1);
          y0 = 0;

          if (placed.some((q) => Math.hypot(q[0] - x, (q[1] - z) * 0.6) < 1.6)) continue;
          placed.push([x, z]);
          k++;
          genTree(x, y0, z, rng, 0, S, Lf, Ld, cans);
        }
      }

      gl!.bindBuffer(gl!.ARRAY_BUFFER, segBuf);
      gl!.bufferData(gl!.ARRAY_BUFFER, new Float32Array(S), gl!.STATIC_DRAW);

      gl!.bindBuffer(gl!.ARRAY_BUFFER, leafBuf);
      gl!.bufferData(gl!.ARRAY_BUFFER, new Float32Array(Lf), gl!.STATIC_DRAW);

      nSeg = S.length / 12;
      nLeaf = Lf.length / 12;
      cans.sort((a, b) => a[4] - b[4]);
      UV.uNC = Math.min(16, cans.length);
      cans.slice(0, 16).forEach((c, j) => UV.uCan.set(c.slice(0, 4), j * 4));
    }

    let scale = /Mobi|Android/i.test(navigator.userAgent) ? 0.75 : 1.0;
    let W = 0;
    let H = 0;

    function resize() {
      if (!cv) return;
      const dpr = window.devicePixelRatio || 1;
      const isLow = ctrlRef.current.lowPower;
      const isBlackHole = ctrlRef.current.sceneIdx === 5;
      const rect = cv.getBoundingClientRect();
      const clientW = rect.width || window.innerWidth || document.documentElement.clientWidth || 800;
      const clientH = rect.height || window.innerHeight || document.documentElement.clientHeight || 600;
      
      const is4K = (clientW * dpr) >= 3000 || (clientH * dpr) >= 1800;
      const baseScale = isLow ? 0.5 : (isBlackHole ? 1.0 : (is4K ? Math.max(1.0, scale) : scale));
      const d = dpr * baseScale;

      const w = Math.max(32, Math.floor(clientW * d));
      const h = Math.max(32, Math.floor(clientH * d));
      if (w !== W || h !== H) {
        W = cv.width = w;
        H = cv.height = h;
        gl!.viewport(0, 0, W, H);
      }
    }

    let currentSceneIdx = -1;
    function setScene(i: number) {
      if (currentSceneIdx === i) return;
      currentSceneIdx = i;
      const sc = SCN[i];
      buildGeo(i);
      UV.uSea = sc.sea ?? 0;
      UV.uPit = sc.pit ?? 0.06;
      UV.uFogC = sc.fog || [0.5, 0.66, 0.86];
      UV.uFogD = sc.fd || 0.01;
      UV.uWet = sc.wet || 0;
      UV.uSunI = sc.sun || 1;
    }

    function attr(l: number, b: WebGLBuffer, sz: number, st: number, off: number, dv: number) {
      gl!.bindBuffer(gl!.ARRAY_BUFFER, b);
      gl!.enableVertexAttribArray(l);
      gl!.vertexAttribPointer(l, sz, gl!.FLOAT, false, st, off);
      vdiv(l, dv);
    }

    function inst(g: ProgData | null, n: number, list: Array<[WebGLBuffer, number, number?, number?]>) {
      if (!g || !n) return;
      gl!.useProgram(g.p);
      setU(g);
      attr(0, quadBuf, 2, 0, 0, 0);
      list.forEach((a, i) => attr(i + 1, a[0], a[2] || 4, a[3] || 48, a[1] * 4, 1));
      for (let i = list.length + 1; i < 4; i++) {
        gl!.disableVertexAttribArray(i);
        vdiv(i, 0);
      }
      drawI(n);
    }

    function renderScene(sc: SceneDef) {
      if (!gl) return;

      gl.disable(gl.DEPTH_TEST);
      gl.disable(gl.BLEND);

      const g = bgP(currentSceneIdx);
      if (g) {
        gl.useProgram(g.p);
        setU(g);
        attr(0, triBuf, 2, 0, 0, 0);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      }

      if (ctrlRef.current.lowPower || currentSceneIdx === 5 || !canGeo || (sc.mode === undefined && !sc.river)) return;

      gl.depthMask(true);
      gl.clear(gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.DEPTH_TEST);
      gl.depthFunc(gl.LEQUAL);

      // Instanced Branches
      inst(mkG('B', VB, ['aQ', 'aA', 'aB', 'aR']), nSeg * 1, [
        [segBuf, 0],
        [segBuf, 4],
        [segBuf, 8]
      ]);

      // Instanced Leaves & Blossoms
      inst(mkG('L', VL, ['aQ', 'aP', 'aN', 'aC']), nLeaf, [
        [leafBuf, 0],
        [leafBuf, 4],
        [leafBuf, 8]
      ]);

      // Instanced Precipitation / Drifting Petals & Leaves
      if (sc.kind !== undefined && sc.pn) {
        const gp = mkG('P', VP, ['aQ', 'aId']);
        UV.uKind = sc.kind;
        UV.uMax = Math.min(sc.pn, Math.floor(sc.pn * (sc.kind === 2 ? UV.uCnt : 0.35 + 0.65 * UV.uCnt)));
        if (sc.kind === 2) {
          gl.enable(gl.BLEND);
          gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
          gl.depthMask(false);
        }
        inst(gp, sc.pn, [[idBuf, 0, 1, 4]]);
        gl.depthMask(true);
        gl.disable(gl.BLEND);
      }

      for (let i = 0; i < 4; i++) {
        gl.disableVertexAttribArray(i);
        vdiv(i, 0);
      }
    }

    let T = 0;
    let last = performance.now();
    let strike = -99;
    let nextStrike = 2;
    let avg = 16;
    let frames = 0;
    let animId: number | null = null;
    let isDestroyed = false;

    const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x));

    function frame(now: number) {
      if (isDestroyed) return;
      animId = requestAnimationFrame(frame);

      const dtr = Math.min(Math.max(now - last, 1), 100);
      last = now;

      if (document.hidden || !ctrlRef.current.enabled) {
        return;
      }

      const spd = ctrlRef.current.speed;
      const speedMult = spd === 'fast' ? 1.3 : spd === 'medium' ? 1.0 : 0.75;
      const dt = (dtr / 1000) * speedMult;
      T = (T + dt) % 4000;

      avg = avg * 0.95 + dtr * 0.05;
      if (++frames % 45 === 0) {
        // Dynamic adaptive quality ladder with hysteresis
        if (avg > 48 && scale > 0.5) scale = Math.max(0.5, scale * 0.85);
        else if (avg < 20 && scale < 1.0 && !ctrlRef.current.lowPower) scale = Math.min(1.0, scale * 1.05);
      }

      resize();

      const targetIdx = ctrlRef.current.sceneIdx;
      setScene(targetIdx);

      const storm = clamp(0.55 + 0.45 * Math.sin(T * 0.06), 0, 1);
      let flash = 0;
      if (currentSceneIdx === 0 && storm > 0.35 && T > nextStrike) {
        strike = T;
        nextStrike = T + 3 + Math.random() * 8;
      }
      const s = T - strike;
      if (s >= 0 && s < 1.2) {
        flash =
          (Math.exp(-s * 7) * (0.6 + 0.4 * Math.abs(Math.sin(s * 40))) +
            (s > 0.25 && s < 0.6 ? 0.5 * Math.exp(-(s - 0.25) * 10) : 0)) *
          clamp((storm - 0.3) * 3, 0, 1);
      }

      const ld = nrm([0.45, 0.55, 0.35]);
      const sc = SCN[currentSceneIdx];

      const baseWind = currentSceneIdx === 1 ? 0.6 : currentSceneIdx === 4 ? 0.85 : 1.0;
      const activeWind = baseWind * speedMult + ctrlRef.current.gustBonus;

      UV.R = [W, H];
      UV.uRes = [W, H];
      UV.uQuality = (scale >= 0.85 && !ctrlRef.current.lowPower) ? 1.0 : (scale >= 0.65 ? 0.7 : 0.4);
      UV.T = T;
      UV.uWind = activeWind;
      UV.uSh = 0.8;
      UV.uShS = 0.6;
      UV.uCnt = 0.6;
      UV.uFlash = flash;
      UV.uStorm = currentSceneIdx === 0 ? storm : 0;
      UV.uLowQ = (ctrlRef.current.lowPower || scale < 0.65) ? 1 : 0;
      UV.uTone = (ctrlRef.current.tone ?? 0) / 100.0;
      UV.L = ld;
      UV.uSea = sc.sea ?? 0;
      UV.uPit = sc.pit ?? 0.06;
      UV.uFogC = sc.fog || [0.5, 0.66, 0.86];
      UV.uFogD = sc.fd || 0.01;
      UV.uWet = sc.wet || 0;
      UV.uSunI = sc.sun || 1;
      UV.uRo = sc.river ? [Math.sin(T * 0.06) * 0.3, 2.0, 0] : [Math.sin(T * 0.05) * 0.5, 1.7, 0];

      renderScene(sc);
    }

    const handleResize = () => {
      resize();
      if (currentSceneIdx >= 0) renderScene(SCN[currentSceneIdx]);
    };

    const handleVisibility = () => {
      last = performance.now();
      if (!document.hidden && currentSceneIdx >= 0) {
        resize();
        renderScene(SCN[currentSceneIdx]);
      }
    };

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => {
        handleResize();
      });
      ro.observe(cv);
    }

    window.addEventListener('resize', handleResize, { passive: true });
    document.addEventListener('visibilitychange', handleVisibility);

    let transitionRaf: number | null = null;
    const handleEnvTransition = (e: Event) => {
      const customEvent = e as CustomEvent<{
        originX?: number;
        originY?: number;
        targetMode?: WeatherMode;
      }>;
      const detail = customEvent.detail;
      if (!detail || !cv) return;

      const scv = snapshotCanvasRef.current;
      if (scv && cv.width > 0 && cv.height > 0) {
        scv.width = cv.width;
        scv.height = cv.height;
        const sctx = scv.getContext('2d');
        if (sctx) {
          sctx.drawImage(cv, 0, 0);
          scv.style.display = 'block';
          scv.style.opacity = '1';
        }
      }

      const ox = detail.originX ?? (window.innerWidth / 2);
      const oy = detail.originY ?? (window.innerHeight / 2);
      const maxR = Math.hypot(
        Math.max(ox, window.innerWidth - ox),
        Math.max(oy, window.innerHeight - oy)
      ) + 60;

      const targetIdx = detail.targetMode ? weatherToSceneIdx(detail.targetMode) : ctrlRef.current.sceneIdx;
      ctrlRef.current.sceneIdx = targetIdx;
      setScene(targetIdx);
      renderScene(SCN[targetIdx]);

      const prefersReduced =
        typeof window !== 'undefined' &&
        window.matchMedia &&
        window.matchMedia('(prefers-reduced-motion: reduce)').matches;

      if (prefersReduced) {
        cv.style.webkitMaskImage = 'none';
        cv.style.maskImage = 'none';
        if (scv) scv.style.display = 'none';
        return;
      }

      if (transitionRaf !== null) cancelAnimationFrame(transitionRaf);
      const startTime = performance.now();
      const duration = 1050; // 1050ms natural transition duration
      const feather = 35; // 35px soft feathered boundary

      const step = (now: number) => {
        if (isDestroyed) return;
        const elapsed = now - startTime;
        const p = Math.min(1, elapsed / duration);
        // Ease-out cubic: 1 - (1 - p)^3
        const ease = 1 - Math.pow(1 - p, 3);
        const curR = ease * maxR;

        const maskVal = `radial-gradient(circle at ${ox}px ${oy}px, black ${curR}px, rgba(0,0,0,0) ${curR + feather}px)`;
        cv.style.webkitMaskImage = maskVal;
        cv.style.maskImage = maskVal;

        if (p < 1) {
          transitionRaf = requestAnimationFrame(step);
        } else {
          cv.style.webkitMaskImage = 'none';
          cv.style.maskImage = 'none';
          if (scv) scv.style.display = 'none';
          transitionRaf = null;
        }
      };

      transitionRaf = requestAnimationFrame(step);
    };

    window.addEventListener('axis-env-transition', handleEnvTransition);

    setScene(ctrlRef.current.sceneIdx);
    resize();
    renderScene(SCN[ctrlRef.current.sceneIdx]);

    animId = requestAnimationFrame(frame);

    return () => {
      isDestroyed = true;
      if (animId !== null) cancelAnimationFrame(animId);
      if (transitionRaf !== null) cancelAnimationFrame(transitionRaf);
      if (ro) ro.disconnect();
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('axis-env-transition', handleEnvTransition);
      document.removeEventListener('visibilitychange', handleVisibility);

      try {
        gl!.deleteBuffer(triBuf);
        gl!.deleteBuffer(quadBuf);
        gl!.deleteBuffer(idBuf);
        gl!.deleteBuffer(segBuf);
        gl!.deleteBuffer(leafBuf);
        Object.values(P).forEach((item) => {
          if (item?.p) gl!.deleteProgram(item.p);
        });
      } catch {}
    };
  }, []);

  const currentEnv = PROCEDURAL_ENVIRONMENTS[weatherMode] || PROCEDURAL_ENVIRONMENTS.leaves;

  return (
    <div
      id="ambient-root"
      className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none transition-colors duration-700"
      aria-hidden="true"
      style={{
        filter: 'none',
        backdropFilter: 'none',
        background: initFailed ? currentEnv.fallbackGradient : undefined
      }}
    >
      {/* Tap-Origin Radial Reveal Snapshot Layer */}
      <canvas
        ref={snapshotCanvasRef}
        className="absolute inset-0 w-full h-full block pointer-events-none select-none z-0"
        style={{
          filter: 'none',
          backdropFilter: 'none',
          width: '100%',
          height: '100%',
          display: 'none'
        }}
      />

      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full block pointer-events-none select-none z-0"
        style={{
          filter: 'none',
          backdropFilter: 'none',
          width: '100%',
          height: '100%',
          display: initFailed ? 'none' : 'block'
        }}
      />

      {/* Traversal of Environment-Specific Migratory Birds */}
      <MigratoryBirds
        weatherMode={weatherMode}
        speed={speed}
        lowPowerMode={lowPowerMode}
      />

      <div
        className="absolute inset-0 bg-gradient-to-b from-black/15 via-transparent to-black/35 pointer-events-none z-1"
        style={{ filter: 'none', backdropFilter: 'none' }}
      />

      <div
        className="absolute inset-0 z-2 opacity-[0.03] dark:opacity-[0.05] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)`,
          backgroundSize: '24px 24px'
        }}
      />
    </div>
  );
};

const AmbientBackgroundComponent: React.FC<AmbientBackgroundProps> = (props) => {
  if (props.weatherMode === 'blackhole') {
    return (
      <div
        id="ambient-root"
        className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none bg-black"
        aria-hidden="true"
      >
        <CosmicBlackHole
          enabled={props.enabled}
          speed={props.speed}
          lowPowerMode={props.lowPowerMode}
          relativitySlide={props.relativitySlide}
        />
        <div
          className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/45 pointer-events-none z-1"
        />
      </div>
    );
  }
  return <AmbientBackgroundBase {...props} />;
};

export const AmbientBackground = memo(
  AmbientBackgroundComponent,
  (prev, next) =>
    prev.enabled === next.enabled &&
    prev.speed === next.speed &&
    prev.weatherMode === next.weatherMode &&
    prev.gustTrigger === next.gustTrigger &&
    prev.lowPowerMode === next.lowPowerMode &&
    prev.tone === next.tone &&
    prev.relativitySlide === next.relativitySlide
);
