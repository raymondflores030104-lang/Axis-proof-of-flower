import React, { useState } from 'react';

interface SubscriptionModalProps {
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ onToast }) => {
  const [isSubscribed, setIsSubscribed] = useState(true);
  const [planType] = useState('Axis Pro · Monthly');
  const [renewalDate] = useState('Oct 29, 2026');

  const handleCancel = () => {
    setIsSubscribed(false);
    onToast('✓ Subscription cancelled. You will keep Pro benefits until Oct 29.', 'good');
  };

  const handleReactivate = () => {
    setIsSubscribed(true);
    onToast('✓ Axis Pro reactivated with one tap!', 'good');
  };

  return (
    <div className="space-y-4 select-none">
      {/* Principle Badge */}
      <div className="p-3 rounded-2xl neu-inset flex items-center justify-between text-xs">
        <span className="font-extrabold text-emerald-700 dark:text-emerald-400 font-mono">
          ✓ Principle #2: Zero Dark Patterns
        </span>
        <span className="text-[10px] text-[var(--ink2)] font-mono">One-Tap Cancellation</span>
      </div>

      {/* Subscription Card Container */}
      <div className="p-5 rounded-3xl neu-flat space-y-4 border border-[var(--neu-border-dark)]">
        <div className="flex items-center justify-between pb-3 border-b border-[var(--neu-border-dark)]">
          <div className="space-y-0.5">
            <h3 className="font-extrabold text-base text-[var(--ink)]">
              Subscription
            </h3>
            <p className="text-xs text-[var(--ink2)]">
              Manage your premium network throughput
            </p>
          </div>
          <span className={`text-[10px] font-extrabold font-mono px-2.5 py-1 rounded-full ${
            isSubscribed ? 'neu-tab-active' : 'neu-inset text-[var(--ink2)]'
          }`}>
            {isSubscribed ? 'Active' : 'Cancelled'}
          </span>
        </div>

        {/* Subscription details box */}
        <div className="p-4 rounded-2xl neu-inset space-y-2">
          <div className="flex justify-between items-baseline">
            <b className="text-sm font-bold text-[var(--ink)]">{planType}</b>
            <span className="text-sm font-black font-mono text-[var(--ink)]">₱499 / mo</span>
          </div>
          <div className="flex justify-between text-xs text-[var(--ink2)]">
            <span>Status:</span>
            <span>{isSubscribed ? `Renews ${renewalDate}` : `Expires ${renewalDate}`}</span>
          </div>
        </div>

        {/* Action Button & Honest Transparency Microcopy */}
        <div className="space-y-2 pt-2">
          {isSubscribed ? (
            <>
              <button
                type="button"
                onClick={handleCancel}
                className="w-full py-3.5 px-4 rounded-2xl bg-[var(--tab-active-bg)] text-[var(--tab-active-ink)] font-extrabold text-xs shadow-md hover:opacity-95 active:scale-98 transition cursor-pointer btn-instant-tap"
              >
                Cancel subscription
              </button>
              <p className="text-[11px] text-center text-[var(--ink2)] leading-relaxed pt-1">
                You&apos;ll keep Pro until {renewalDate}.<br />
                <strong className="text-[var(--ink)]">One tap, no questions asked.</strong>
              </p>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={handleReactivate}
                className="w-full py-3.5 px-4 rounded-2xl neu-tab-active font-extrabold text-xs shadow-md active:scale-98 transition cursor-pointer btn-instant-tap"
              >
                Reactivate Axis Pro (One Tap)
              </button>
              <p className="text-[11px] text-center text-[var(--ink2)] pt-1">
                No setup fees. Cancel anytime instantly.
              </p>
            </>
          )}
        </div>
      </div>

      {/* Honest comparison callout */}
      <div className="p-3.5 rounded-2xl neu-inset text-xs space-y-1.5 text-[var(--ink2)]">
        <b className="text-[var(--ink)] block">Our Anti-Dark-Pattern Pledge:</b>
        <p className="text-[11px] leading-relaxed">
          We never hide cancellation buttons behind support phone calls, multi-page surveys, or artificial &quot;Wait, you&apos;ll lose everything 😢&quot; guilt screens. True retention is earned through trust.
        </p>
      </div>
    </div>
  );
};
