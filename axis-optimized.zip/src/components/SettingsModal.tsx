import React, { useState } from 'react';
import { AxisState } from '../types';
import { CURS } from '../constants';
import { copyText, soundEffects } from '../utils';
import {
  User,
  ShieldCheck,
  Scale,
  Globe,
  FileText,
  KeyRound,
  Lock,
  Play,
  Volume2,
  Vibrate,
  AlertTriangle,
  Copy,
  Sun,
  Moon,
  Sliders
} from 'lucide-react';
import { CustomDomainModal } from './CustomDomainModal';
import { WhitepaperModal } from './WhitepaperModal';
import { SecurityModal } from './SecurityModal';

interface SettingsModalProps {
  state: AxisState;
  onUpdateSettings: (updater: (prev: AxisState['settings']) => AxisState['settings']) => void;
  onUpdateSecurity?: (updater: (prev: NonNullable<AxisState['securitySettings']>) => NonNullable<AxisState['securitySettings']>) => void;
  onToggleLowPower?: (enabled: boolean) => void;
  onOpenScreen: (screen: string) => void;
  onTogglePin: (enable: boolean) => void;
  onResetData: () => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
  onTriggerGust?: () => void;
  initialTab?: 'preferences' | 'domain' | 'whitepaper' | 'security';
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  state,
  onUpdateSettings,
  onUpdateSecurity,
  onToggleLowPower,
  onOpenScreen,
  onTogglePin,
  onResetData,
  onToast,
  onTriggerGust,
  initialTab = 'preferences'
}) => {
  const [activeTab, setActiveTab] = useState<'preferences' | 'domain' | 'whitepaper' | 'security'>(initialTab);
  const settings = state.settings;
  const tone = settings.tone ?? 0;

  const handleSoundTest = () => {
    soundEffects.success(settings.fx.vol);
    onToast('Sound played', 'good');
  };

  const handleVibTest = () => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate([60, 50, 60, 50, 120]);
      onToast('Vibration triggered', 'good');
    } else {
      onToast('Vibration is not supported on this device/browser', 'err');
    }
  };

  const getToneLabel = (val: number) => {
    if (settings.weatherMode === 'blackhole') {
      if (val <= 20) return 'Light';
      if (val <= 65) return 'Balanced';
      return 'Dark Mode';
    }
    if (val <= 20) return 'Light';
    if (val <= 45) return 'Soft Green';
    if (val <= 65) return 'Balanced';
    if (val <= 85) return 'Deep Canopy';
    return 'Dark Mode';
  };

  return (
    <div className="space-y-4 text-xs select-none">
      {/* Settings Sub-Tabs - Darker UI Navigation Tabs */}
      <div className="flex rounded-2xl neu-tab-bar p-1.5 text-xs font-bold gap-1.5 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('preferences')}
          className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'preferences'
              ? 'neu-tab-active'
              : 'neu-tab-item'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Preferences</span>
        </button>

        <button
          onClick={() => setActiveTab('domain')}
          className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'domain'
              ? 'neu-tab-active'
              : 'neu-tab-item'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>Domain</span>
        </button>

        <button
          onClick={() => setActiveTab('whitepaper')}
          className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'whitepaper'
              ? 'neu-tab-active'
              : 'neu-tab-item'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Whitepaper</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`flex-1 min-w-[85px] py-2 px-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'security'
              ? 'neu-tab-active'
              : 'neu-tab-item'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>Security</span>
        </button>
      </div>

      {/* ======================================================== */}
      {/* 1. PREFERENCES TAB (Theme % slider, Currency, Audio, ID) */}
      {/* ======================================================== */}
      {activeTab === 'preferences' && (
        <div className="space-y-4">
          {/* Light Green to Dark Mode Slider */}
          <div className="p-4 rounded-2xl neu-flat space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sun className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
                  Appearance Tone (Light &amp; Dark Mode)
                </h4>
              </div>
              <span className="text-[11px] font-mono font-black neu-inset-sm px-2.5 py-0.5 rounded-md text-[var(--accent)]">
                {tone}% · {getToneLabel(tone)}
              </span>
            </div>

            <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
              Slide to edit the lightness percentage. Seamlessly transitions from crisp Light (0%) to deep obsidian Dark Mode (100%) while preserving soft dual-shadow extrusion.
            </p>

            {/* Slider track in Neumorphic Inset Well */}
            <div className="p-3 rounded-xl neu-inset flex items-center gap-3">
              <Sun className="w-4 h-4 text-emerald-600 shrink-0" />
              <input
                type="range"
                min="0"
                max="100"
                step="1"
                value={tone}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  onUpdateSettings((prev) => ({ ...prev, tone: val }));
                }}
                className="w-full accent-emerald-600 cursor-pointer h-2 bg-transparent"
                aria-label="Theme Tone Percentage"
              />
              <Moon className="w-4 h-4 text-emerald-400 shrink-0" />
            </div>

            {/* Quick Presets */}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => onUpdateSettings((prev) => ({ ...prev, tone: 0 }))}
                className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  tone === 0
                    ? 'neu-tab-active font-extrabold'
                    : 'neu-tab-item'
                }`}
              >
                <Sun className="w-3.5 h-3.5 text-amber-500 dark:text-emerald-400" />
                <span>Light</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateSettings((prev) => ({ ...prev, tone: 50 }))}
                className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  tone === 50
                    ? 'neu-tab-active font-extrabold'
                    : 'neu-tab-item'
                }`}
              >
                <span>Balanced (50%)</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateSettings((prev) => ({ ...prev, tone: 100 }))}
                className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  tone === 100
                    ? 'neu-tab-active font-extrabold'
                    : 'neu-tab-item'
                }`}
              >
                <Moon className="w-3.5 h-3.5 text-emerald-400" />
                <span>Dark Mode (100%)</span>
              </button>
            </div>
          </div>

          {/* Falling Leaves Ambient Atmosphere Card */}
          <div className="p-4 rounded-2xl neu-flat space-y-3.5 border border-[var(--neu-border-dark)]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-base">🍃</span>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
                  Background Falling Leaves Atmosphere
                </h4>
              </div>
              <button
                type="button"
                onClick={() =>
                  onUpdateSettings((prev) => ({
                    ...prev,
                    fallingLeaves: !(prev.fallingLeaves ?? true)
                  }))
                }
                className={`neu-toggle cursor-pointer transition ${
                  (settings.fallingLeaves ?? true) ? 'bg-emerald-600' : 'bg-zinc-300 dark:bg-zinc-700'
                }`}
                aria-label="Toggle falling leaves animation"
              >
                <span
                  className={`w-4 h-4 rounded-full bg-white shadow-xs transition-transform duration-200 block ${
                    (settings.fallingLeaves ?? true) ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
              Real-time procedural 3D nature environments rendered directly on the GPU in the <strong>background layer</strong>. All navigation tabs, action tiles, cards, and modal dialogs remain crisply elevated in the foreground.
            </p>

            {/* Atmospheric Weather / Falling Particles Mode */}
            {(settings.fallingLeaves ?? true) && (
              <div className="space-y-3 pt-2 border-t border-[var(--line)]">
                <div className="flex items-center justify-between text-[11px] font-bold text-[var(--ink2)]">
                  <span>3D Nature Environment:</span>
                  <span className="text-[10px] text-[var(--accent)] font-mono">
                    {settings.weatherMode === 'storming'
                      ? '🌊 Stormy Ocean'
                      : settings.weatherMode === 'raining'
                      ? '🌧️ River & Rain'
                      : settings.weatherMode === 'autumn'
                      ? '🍁 Autumn'
                      : settings.weatherMode === 'sakura'
                      ? '🌸 Sakura'
                      : settings.weatherMode === 'blackhole'
                      ? '🕳️ Cosmic Black Hole'
                      : '🌿 Green Canopy'}
                  </span>
                </div>

                <div className="grid grid-cols-5 gap-1.5 p-1 rounded-2xl neu-tab-bar text-xs font-bold">
                  {[
                    { id: 'storming', label: 'Ocean', icon: '🌊', full: 'Stormy Ocean' },
                    { id: 'leaves', label: 'Canopy', icon: '🌿', full: 'Green Canopy' },
                    { id: 'raining', label: 'River', icon: '🌧️', full: 'River & Rain' },
                    { id: 'autumn', label: 'Autumn', icon: '🍁', full: 'Autumn' },
                    { id: 'sakura', label: 'Sakura', icon: '🌸', full: 'Sakura' }
                  ].map((w) => {
                    const isSelected = settings.weatherMode === w.id;
                    return (
                      <button
                        key={w.id}
                        type="button"
                        onClick={(e) => {
                          const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                          const clickX = e.clientX || (rect.left + rect.width / 2);
                          const clickY = e.clientY || (rect.top + rect.height / 2);

                          if (typeof window !== 'undefined') {
                            window.dispatchEvent(
                              new CustomEvent('axis-env-transition', {
                                detail: {
                                  originX: clickX,
                                  originY: clickY,
                                  targetMode: w.id
                                }
                              })
                            );
                          }

                          onUpdateSettings((prev) => ({
                            ...prev,
                            weatherMode: w.id as any
                          }));
                          onToast(`Atmosphere switched to ${w.full}!`, 'good');
                        }}
                        className={`py-1.5 px-1 rounded-xl transition cursor-pointer text-[10px] font-bold flex flex-col items-center gap-0.5 ${
                          isSelected ? 'neu-tab-active font-extrabold' : 'neu-tab-item'
                        }`}
                        title={w.full}
                      >
                        <span className="text-xs">{w.icon}</span>
                        <span className="truncate max-w-[55px]">{w.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Separate Cosmic Environment (Independent from 5 Nature Seasons) */}
                <div className="p-2 rounded-xl neu-inset space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-[var(--ink2)]">
                    <span className="flex items-center gap-1.5">
                      <span>🕳️</span>
                      <span>Separate Special Environment</span>
                    </span>
                    <span className="text-[10px] font-mono text-amber-500">Relativistic Space</span>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      const next = settings.weatherMode === 'blackhole' ? 'leaves' : 'blackhole';
                      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                      const clickX = e.clientX || (rect.left + rect.width / 2);
                      const clickY = e.clientY || (rect.top + rect.height / 2);

                      if (typeof window !== 'undefined') {
                        window.dispatchEvent(
                          new CustomEvent('axis-env-transition', {
                            detail: {
                              originX: clickX,
                              originY: clickY,
                              targetMode: next
                            }
                          })
                        );
                      }

                      onUpdateSettings((prev) => ({
                        ...prev,
                        weatherMode: next
                      }));
                      onToast(
                        next === 'blackhole'
                          ? 'Transferred to Cosmic Black Hole Environment!'
                          : 'Returned to Green Forest Environment!',
                        'good'
                      );
                    }}
                    className={`w-full py-2 px-3 rounded-xl transition cursor-pointer text-xs font-bold flex items-center justify-between ${
                      settings.weatherMode === 'blackhole'
                        ? 'neu-tab-active font-extrabold text-amber-500'
                        : 'neu-tab-item'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm">🌌</span>
                      <div className="text-left">
                        <div className="text-xs font-bold">Cosmic Black Hole (Gargantua)</div>
                        <div className="text-[10px] opacity-75 font-normal">Diagonal accretion disk &amp; gravitational lensing</div>
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-md font-mono neu-inset-sm">
                      {settings.weatherMode === 'blackhole' ? 'Active' : 'Switch'}
                    </span>
                  </button>

                  {/* Gravitational Relativity Slide - Belongs strictly to Cosmic Black Hole Settings */}
                  {settings.weatherMode === 'blackhole' && (
                    <div className="p-3 rounded-xl bg-black/40 border border-amber-900/40 space-y-2 mt-2">
                      <div className="flex items-center justify-between text-[11px] font-bold">
                        <span className="text-amber-400 flex items-center gap-1.5">
                          <span>⏱️</span>
                          <span>Gravitational Relativity Slide:</span>
                        </span>
                        <span className="text-[10px] font-mono font-bold text-amber-400 px-2 py-0.5 rounded-md bg-amber-950/60 border border-amber-800/50">
                          {(settings.relativitySlide ?? 1.0).toFixed(1)}x Time Dilation
                        </span>
                      </div>
                      <p className="text-[10px] text-zinc-400 leading-relaxed">
                        Modulates observer distance from safe Keplerian orbit (1.0x) to relativistic ergosphere plunge (3.5x). Accelerates black hole rotation speed, synchrotron radiation glow, and gravitational matter suction.
                      </p>
                      <div className="flex items-center gap-2 pt-1">
                        <span className="text-[10px] font-bold text-zinc-400">Orbit (1.0x)</span>
                        <input
                          type="range"
                          min="1.0"
                          max="3.5"
                          step="0.1"
                          value={settings.relativitySlide ?? 1.0}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            onUpdateSettings((prev) => ({
                              ...prev,
                              relativitySlide: val
                            }));
                          }}
                          className="w-full accent-amber-500 cursor-pointer h-2 bg-zinc-800 rounded-lg"
                          aria-label="Gravitational Relativity Slide"
                        />
                        <span className="text-[10px] font-bold text-amber-400">Plunge (3.5x)</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Graphics Quality Scaling (High 3D vs Low Graphics for Smooth Devices) */}
                <div className="flex items-center justify-between text-[11px] font-bold text-[var(--ink2)] pt-1">
                  <span>Graphics Performance:</span>
                  <span className="text-[10px] text-[var(--accent)] font-mono">
                    {state.lowPowerMode ? 'Low Graphics (Smooth)' : 'High Graphics (Full 3D)'}
                  </span>
                </div>

                <div className="flex rounded-2xl neu-tab-bar p-1.5 text-xs font-bold gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      if (onToggleLowPower) onToggleLowPower(false);
                      onToast('High Graphics enabled (full 3D flora, birds, fish & particles)', 'good');
                    }}
                    className={`flex-1 py-1.5 px-2 rounded-xl transition cursor-pointer text-[11px] font-bold ${
                      !state.lowPowerMode ? 'neu-tab-active' : 'neu-tab-item'
                    }`}
                  >
                    High Graphics
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (onToggleLowPower) onToggleLowPower(true);
                      onToast('Low Graphics enabled (optimized for ultra-smooth framerate)', 'good');
                    }}
                    className={`flex-1 py-1.5 px-2 rounded-xl transition cursor-pointer text-[11px] font-bold ${
                      state.lowPowerMode ? 'neu-tab-active' : 'neu-tab-item'
                    }`}
                  >
                    Low Graphics (Smooth)
                  </button>
                </div>

                {/* Pace Controls */}
                <div className="flex items-center justify-between text-[11px] font-bold text-[var(--ink2)] pt-1">
                  <span>Descent Pace:</span>
                  <span className="text-[10px] text-[var(--accent)] font-mono capitalize">
                    {settings.fallingLeavesSpeed || 'slow'} (Serene Pace)
                  </span>
                </div>

                <div className="flex rounded-2xl neu-tab-bar p-1.5 text-xs font-bold gap-1.5">
                  {(['slow', 'medium', 'fast'] as const).map((spd) => {
                    const isSelected = (settings.fallingLeavesSpeed || 'slow') === spd;
                    const label = spd === 'slow' ? 'Tranquil (Slow)' : spd === 'medium' ? 'Balanced' : 'Brisk';
                    return (
                      <button
                        key={spd}
                        type="button"
                        onClick={() =>
                          onUpdateSettings((prev) => ({
                            ...prev,
                            fallingLeavesSpeed: spd
                          }))
                        }
                        className={`flex-1 py-1.5 px-2 rounded-xl transition cursor-pointer text-[11px] font-bold ${
                          isSelected ? 'neu-tab-active' : 'neu-tab-item'
                        }`}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>

                {/* Trigger Gentle Wind Gust Button */}
                <button
                  type="button"
                  onClick={() => {
                    if (onTriggerGust) onTriggerGust();
                    onToast('🍃 Gentle breeze swirled the background atmosphere!', 'good');
                  }}
                  className="w-full py-2 px-3 rounded-xl neu-btn text-[var(--ink)] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition hover:text-[var(--accent)]"
                >
                  <span>🌬️</span>
                  <span>Trigger Gentle Breeze Gust</span>
                </button>
              </div>
            )}
          </div>

          {/* Account Identity */}
          <div className="p-4 rounded-2xl neu-flat space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
                Account Identity
              </h4>
              <span className="text-[11px] font-mono neu-inset-sm px-2 py-0.5 rounded-md text-[var(--ink2)]">
                {state.accountId}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl neu-inset flex items-center justify-center text-xl overflow-hidden shrink-0">
                {state.profile.avatar && state.profile.avatar.startsWith('data:') ? (
                  <img src={state.profile.avatar} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-5 h-5 text-zinc-400" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <b className="text-sm font-bold block truncate text-[var(--ink)]">
                  {state.profile.name || 'Anonymous User'}
                </b>
                <p className="text-[11px] text-[var(--ink2)] font-mono truncate">
                  {state.address}
                </p>
              </div>
              <button
                onClick={() => {
                  copyText(state.address);
                  onToast('Copied address', 'good');
                }}
                className="p-2.5 rounded-xl neu-btn text-[var(--ink)] transition cursor-pointer"
                title="Copy address"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Currency Selection */}
          <div className="p-4 rounded-2xl neu-flat space-y-2">
            <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
              Base Fiat Currency
            </h4>
            <select
              value={settings.currency}
              onChange={(e) =>
                onUpdateSettings((prev) => ({ ...prev, currency: e.target.value }))
              }
              className="w-full p-2.5 rounded-xl neu-input text-[var(--ink)] font-bold text-xs cursor-pointer"
            >
              {Object.entries(CURS).map(([code, [sym, , name]]) => (
                <option key={code} value={code}>
                  {code} ({sym}) - {name}
                </option>
              ))}
            </select>
          </div>

          {/* Audio & Haptics */}
          <div className="p-4 rounded-2xl neu-flat space-y-3">
            <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
              Audio &amp; Vibration
            </h4>

            <div className="flex items-center justify-between">
              <span className="font-bold flex items-center gap-1.5 text-[var(--ink)]">
                <Volume2 className="w-3.5 h-3.5 text-emerald-500" /> Sound Effects
              </span>
              <input
                type="checkbox"
                checked={settings.fx.sound}
                onChange={(e) =>
                  onUpdateSettings((prev) => ({
                    ...prev,
                    fx: { ...prev.fx, sound: e.target.checked }
                  }))
                }
                className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="font-bold flex items-center gap-1.5 text-[var(--ink)]">
                <Vibrate className="w-3.5 h-3.5 text-emerald-500" /> Haptic Feedback
              </span>
              <input
                type="checkbox"
                checked={settings.fx.vib}
                onChange={(e) =>
                  onUpdateSettings((prev) => ({
                    ...prev,
                    fx: { ...prev.fx, vib: e.target.checked }
                  }))
                }
                className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
              />
            </div>

            <div className="flex gap-2.5 pt-1">
              <button
                onClick={handleSoundTest}
                className="flex-1 py-2.5 rounded-xl neu-btn font-bold text-xs transition cursor-pointer text-[var(--ink)]"
              >
                Test Audio
              </button>
              <button
                onClick={handleVibTest}
                className="flex-1 py-2.5 rounded-xl neu-btn font-bold text-xs transition cursor-pointer text-[var(--ink)]"
              >
                Test Vibration
              </button>
            </div>
          </div>

          {/* Category VII.4: Battery & Low-Power Auto-Throttle */}
          <div className="p-4 rounded-2xl neu-flat space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
                  Battery &amp; Low-Power Auto-Throttle
                </h4>
                <p className="text-[11px] text-[var(--ink2)]">
                  Throttles heavy canvas animations and blur filters to save battery
                </p>
              </div>
              <input
                type="checkbox"
                checked={state.lowPowerMode || false}
                onChange={(e) => {
                  onToggleLowPower?.(e.target.checked);
                  onToast(`Low-Power Throttle ${e.target.checked ? 'Enabled' : 'Disabled'}`, 'good');
                }}
                className="w-4 h-4 accent-emerald-600 rounded cursor-pointer shrink-0"
              />
            </div>
          </div>

          {/* Legal Compliance Shortcuts */}
          <div className="p-4 rounded-2xl neu-flat space-y-2.5">
            <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
              Compliance &amp; Policy
            </h4>

            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={() => onOpenScreen('privacy')}
                className="p-3 rounded-xl neu-btn text-left flex items-center gap-2.5 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                <div>
                  <b className="block text-[11px] text-[var(--ink)]">Privacy Policy</b>
                  <span className="text-[10px] text-[var(--ink2)]">Zero Telemetry</span>
                </div>
              </button>

              <button
                onClick={() => onOpenScreen('terms')}
                className="p-3 rounded-xl neu-btn text-left flex items-center gap-2.5 cursor-pointer"
              >
                <Scale className="w-4 h-4 text-amber-500 shrink-0" />
                <div>
                  <b className="block text-[11px] text-[var(--ink)]">Terms of Use</b>
                  <span className="text-[10px] text-[var(--ink2)]">Protocol Rules</span>
                </div>
              </button>
            </div>
          </div>

          {/* Startup Sequence */}
          <div className="p-4 rounded-2xl neu-flat space-y-2">
            <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
              Startup Sequence
            </h4>
            <p className="text-[11px] text-[var(--ink2)]">
              Replay the animated Axis splash screen and hardware ingestion sequencer.
            </p>
            <button
              onClick={() => onOpenScreen('loading')}
              className="w-full py-2.5 rounded-xl neu-btn text-[var(--ink)] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 text-emerald-500" /> Replay Splash Screen
            </button>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 2. CUSTOM DOMAIN ROUTING TAB */}
      {/* ======================================================== */}
      {activeTab === 'domain' && (
        <CustomDomainModal onToast={onToast} />
      )}

      {/* ======================================================== */}
      {/* 3. OFFICIAL TECHNICAL WHITEPAPER TAB */}
      {/* ======================================================== */}
      {activeTab === 'whitepaper' && (
        <WhitepaperModal onToast={onToast} />
      )}

      {/* ======================================================== */}
      {/* 4. SECURITY & PIN TAB */}
      {/* ======================================================== */}
      {activeTab === 'security' && (
        <div className="space-y-4">
          {/* Advanced Security Engine (WebAuthn, Anti-Spoofing, Attestation, Kill Switch) */}
          <SecurityModal
            state={state}
            onUpdateSecurity={onUpdateSecurity || (() => {})}
            onEmergencyKillSwitch={() => onToast('Emergency protocol lockdown activated', 'err')}
            onToast={onToast}
          />

          {/* Security & PIN Protection */}
          <div className="p-4 rounded-2xl neu-flat space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
                Security &amp; PIN Protection
              </h4>
              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md ${
                state.pinHash 
                  ? 'neu-inset-sm text-emerald-600 dark:text-emerald-400' 
                  : 'neu-inset-sm text-zinc-500'
              }`}>
                {state.pinHash ? 'PIN Enabled' : 'PIN Disabled'}
              </span>
            </div>

            <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
              {state.pinHash
                ? 'Cryptographic 4-digit PIN is required to authorize withdrawals and sensitive transactions.'
                : 'Turn PIN on to encrypt and protect high-value withdrawals and transfers.'}
            </p>

            {state.pinHash ? (
              <div className="flex gap-2.5">
                <button
                  onClick={() => onOpenScreen('pin')}
                  className="flex-1 py-2.5 px-3 rounded-xl neu-btn-accent bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <KeyRound className="w-3.5 h-3.5" /> Change PIN
                </button>
                <button
                  onClick={() => onTogglePin(false)}
                  className="flex-1 py-2.5 px-3 rounded-xl neu-btn text-rose-600 dark:text-rose-400 font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" /> Turn Off PIN
                </button>
              </div>
            ) : (
              <button
                onClick={() => onTogglePin(true)}
                className="w-full py-2.5 px-4 rounded-xl neu-btn-accent bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" /> Setup 4-Digit Security PIN
              </button>
            )}
          </div>

          {/* Danger Zone */}
          <div className="p-4 rounded-2xl neu-flat space-y-2">
            <div className="flex items-center gap-1.5 text-rose-600 dark:text-rose-400 font-extrabold text-xs uppercase tracking-wider">
              <AlertTriangle className="w-3.5 h-3.5" /> Danger Zone
            </div>
            <p className="text-[11px] text-[var(--ink2)]">
              Reset all stored balances, transaction records, offline scans, and settings on this device.
            </p>
            <button
              onClick={onResetData}
              className="w-full py-2.5 rounded-xl neu-btn-accent bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs transition cursor-pointer"
            >
              Erase All Local Data
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
