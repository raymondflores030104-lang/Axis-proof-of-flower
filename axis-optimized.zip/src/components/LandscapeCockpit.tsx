import React from 'react';
import { AxisState } from '../types';
import { DAILY_CAP } from '../constants';
import { curInfo, peso } from '../utils';
import {
  Trophy,
  Gift,
  Cpu,
  Wallet,
  TrendingUp,
  Building2,
  Target,
  Ticket,
  Users,
  Receipt,
  Settings,
  CircleDollarSign,
  Coins,
  Sparkles,
  Flame,
  Terminal,
  Grid
} from 'lucide-react';

interface LandscapeCockpitProps {
  state: AxisState;
  chg24: number;
  claimableMissionsCount: number;
  onOpenScreen: (screen: string) => void;
  onGuardScreen: (screen: string) => void;
}

export const LandscapeCockpit: React.FC<LandscapeCockpitProps> = ({
  state,
  chg24,
  claimableMissionsCount,
  onOpenScreen,
  onGuardScreen
}) => {
  const scansLeft = Math.max(0, DAILY_CAP - (state.day?.scans || 0));
  const activeCur = state.settings?.currency || 'PHP';
  const [curSym, curRate] = curInfo(activeCur);
  const claimedToday = Boolean(state?.claim?.last && state?.claim?.last === state?.day?.key);

  // Latest PoF verification or simulated live consensus stream
  const latestPending = state.pendingScans?.[0];
  const yieldStream = latestPending
    ? `+${(latestPending.flrxReward ?? 0.001).toFixed(4)} FLRX`
    : '+0.0000/s';

  return (
    <div className="w-full max-w-[1240px] mx-auto flex flex-col gap-2.5 sm:gap-3 select-none text-zinc-100 font-sans">
      {/* =========================================================================
          TOP HEADER: AXIS + Proof of Flower + DEMONSTRATION Badge + Profile Avatar
          ========================================================================= */}
      <header className="flex items-center justify-between gap-3 px-1 pt-1 pb-0.5">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div
            role="button"
            tabIndex={0}
            onClick={() => onOpenScreen('loading')}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') onOpenScreen('loading');
            }}
            className="flex items-baseline gap-2 cursor-pointer group focus-visible:outline-hidden"
            title="Axis Proof of Flower • Replay Intro"
          >
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-[#facc15] drop-shadow-[0_0_16px_rgba(250,204,21,0.65)] group-hover:brightness-110 transition-all font-sans leading-none">
              Axis
            </h1>
            <span className="text-xs sm:text-sm font-bold text-amber-500/90 tracking-wide drop-shadow-[0_0_8px_rgba(245,158,11,0.35)] hidden xs:inline">
              Proof of Flower
            </span>
          </div>

          {/* DEMONSTRATION Badge */}
          <div className="px-2.5 py-0.5 rounded-md border border-amber-500/60 bg-amber-950/40 text-[#fde047] font-extrabold text-[10px] sm:text-[11px] tracking-wider uppercase shadow-[0_0_10px_rgba(245,158,11,0.25)] shrink-0">
            Demonstration
          </div>
        </div>

        {/* Top-Right Profile / Avatar Badge with Warm Ember Aura */}
        <button
          onClick={() => onOpenScreen('profile')}
          title="Account Profile & Node Key"
          aria-label="Account Profile"
          className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-black/60 border border-amber-500/50 shadow-[0_0_12px_rgba(245,158,11,0.35)] flex items-center justify-center hover:scale-105 active:scale-95 transition-all cursor-pointer group shrink-0 overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-amber-500/20 via-orange-600/10 to-transparent pointer-events-none" />
          <Flame className="w-5 h-5 text-amber-400 group-hover:text-amber-300 drop-shadow-[0_0_6px_rgba(251,191,36,0.6)] transition-colors" />
          <span className="sr-only">Profile</span>
        </button>
      </header>

      {/* =========================================================================
          MAIN 3-COLUMN COCKPIT GRID
          Left: Fiat + Crypto + Surveillance Pods
          Center: Giant Nexus Scan Singularity Card
          Right: 2x2 Quick Action Grid + Wallet & Trading Cards
          ========================================================================= */}
      <div className="grid grid-cols-12 gap-2.5 sm:gap-3.5 items-stretch">
        {/* -----------------------------------------------------------------------
            LEFT COLUMN (3 Columns): PHP Balance + FLRX Token + Surveillance/History
            ----------------------------------------------------------------------- */}
        <div className="col-span-12 md:col-span-3 flex flex-col justify-between gap-2.5 sm:gap-3">
          {/* Card 1: PHP Liquidity */}
          <div
            role="button"
            tabIndex={0}
            onClick={() => onGuardScreen('wallet')}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') onGuardScreen('wallet');
            }}
            className="flex-1 rounded-2xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 p-3 sm:p-3.5 flex items-center justify-between gap-2 shadow-[0_0_15px_rgba(245,158,11,0.08)] transition-all hover:bg-black/75 cursor-pointer group"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-emerald-950/70 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                <CircleDollarSign className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="min-w-0">
                <div className="text-[11px] font-extrabold tracking-wider text-zinc-300 uppercase leading-tight truncate">
                  PHP
                </div>
                <div className="text-[9.5px] font-mono text-zinc-400 leading-tight truncate">
                  Liquidity
                </div>
              </div>
            </div>
            <div className="text-right">
              <span className="block text-base sm:text-lg font-black font-mono text-zinc-100 tracking-tight whitespace-nowrap">
                ₱{state.php.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Card 2: FLRX Token Balance */}
          <div
            role="button"
            tabIndex={0}
            onClick={() => onGuardScreen('trade')}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') onGuardScreen('trade');
            }}
            className="flex-1 rounded-2xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 p-3 sm:p-3.5 flex items-center justify-between gap-2 shadow-[0_0_15px_rgba(245,158,11,0.08)] transition-all hover:bg-black/75 cursor-pointer group"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-emerald-950/70 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                <Coins className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="min-w-0">
                <div className="text-[11px] font-extrabold tracking-wider text-zinc-300 uppercase leading-tight truncate">
                  FLRX
                </div>
                <div className="text-[9.5px] font-mono text-zinc-400 leading-tight truncate">
                  ≈ ₱{(state.flrx * state.price * 58.5).toFixed(2)}
                </div>
              </div>
            </div>
            <div className="text-right">
              <span className="block text-base sm:text-lg font-black font-mono text-[#22c55e] drop-shadow-[0_0_10px_rgba(34,197,94,0.6)] tracking-tight whitespace-nowrap">
                {state.flrx.toFixed(4)}
              </span>
            </div>
          </div>

          {/* Card 3: Surveillance / Network PoF Consensus */}
          <div className="flex-1 rounded-2xl bg-black/65 backdrop-blur-md border border-amber-500/35 p-3 flex items-center justify-between gap-2 shadow-[0_0_15px_rgba(245,158,11,0.08)]">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-7 h-7 rounded-xl bg-emerald-950/70 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
                <Grid className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div className="min-w-0">
                <div className="text-[11px] font-extrabold text-zinc-200 truncate leading-tight">
                  Surveil...
                </div>
                <div className="text-[9.5px] font-mono text-[#4ade80] truncate leading-tight">
                  {yieldStream}
                </div>
              </div>
            </div>
            <button
              onClick={() => onOpenScreen('history')}
              className="px-2.5 py-1 rounded-full bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-600/60 text-zinc-200 text-[11px] font-bold tracking-tight shadow-sm transition active:scale-95 cursor-pointer shrink-0"
            >
              History
            </button>
          </div>
        </div>

        {/* -----------------------------------------------------------------------
            CENTER HERO COLUMN (6 Columns): Nexus Scan Singularity Card
            ----------------------------------------------------------------------- */}
        <div
          role="button"
          tabIndex={0}
          onClick={() => onOpenScreen('scanner')}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') onOpenScreen('scanner');
          }}
          className="col-span-12 md:col-span-6 relative rounded-3xl bg-black/65 backdrop-blur-md border border-amber-500/40 hover:border-amber-500/70 shadow-[0_0_30px_rgba(245,158,11,0.18)] p-3 sm:p-4 flex flex-col justify-between items-center text-center cursor-pointer group min-h-[260px] sm:min-h-[290px] overflow-hidden transition-all duration-300"
        >
          {/* Subtle Accretion Lens Flare Radiant Aura */}
          <div
            aria-hidden="true"
            className="absolute inset-0 pointer-events-none opacity-45 group-hover:opacity-65 transition-opacity"
            style={{
              background:
                'radial-gradient(circle at 50% 50%, rgba(245,158,11,0.22) 0%, rgba(217,119,6,0.12) 40%, rgba(0,0,0,0) 70%)'
            }}
          />

          {/* Top Ticker Pill Inside Card */}
          <div
            onClick={(e) => {
              e.stopPropagation();
              onGuardScreen('trade');
            }}
            className="w-full relative z-10 flex items-center justify-between px-3.5 py-1 rounded-xl bg-black/75 border border-amber-500/25 hover:border-amber-500/50 text-xs font-mono transition shadow-inner"
            title="FLRX / USDT live simulated rate • Tap to trade"
          >
            <span className="text-[10px] font-extrabold uppercase text-amber-400 tracking-wider">
              FLRX/USDT:
            </span>
            <span className="text-xs sm:text-sm font-black text-amber-200 tracking-wide font-mono">
              ${state.price.toFixed(4)}
            </span>
            <span
              className={`text-[10.5px] font-bold font-mono ${
                chg24 >= 0 ? 'text-[#22c55e]' : 'text-rose-400'
              }`}
            >
              {chg24 >= 0 ? '+' : ''}
              {chg24.toFixed(1)}%
            </span>
          </div>

          {/* Central Cosmic Target Reticle & Nexus Scan Typography */}
          <div className="relative z-10 flex flex-col items-center justify-center my-auto py-2">
            {/* Singularity Halo Backing */}
            <div className="relative flex items-center justify-center mb-1">
              <div className="absolute w-20 h-20 rounded-full bg-amber-500/15 blur-lg group-hover:scale-125 transition-transform" />

              {/* Exact Pixel QR Target Reticle matching the reference image */}
              <div className="relative w-12 h-12 sm:w-14 sm:h-14 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <svg
                  viewBox="0 0 36 36"
                  className="w-10 h-10 sm:w-12 sm:h-12 text-zinc-100 drop-shadow-[0_0_10px_rgba(255,255,255,0.7)]"
                  fill="currentColor"
                >
                  {/* Top-Left Corner Box */}
                  <path d="M 4 4 h 10 v 10 h -10 Z M 6 6 v 6 h 6 v -6 Z M 8 8 h 2 v 2 h -2 Z" />
                  {/* Top-Right Corner Box */}
                  <path d="M 22 4 h 10 v 10 h -10 Z M 24 6 v 6 h 6 v -6 Z M 26 8 h 2 v 2 h -2 Z" />
                  {/* Bottom-Left Corner Box */}
                  <path d="M 4 22 h 10 v 10 h -10 Z M 6 24 v 6 h 6 v -6 Z M 8 26 h 2 v 2 h -2 Z" />
                  {/* Tactical Cyber Target Pixels */}
                  <rect x="22" y="22" width="3" height="3" />
                  <rect x="29" y="22" width="3" height="3" />
                  <rect x="22" y="29" width="3" height="3" />
                  <rect x="29" y="29" width="3" height="3" />
                  <rect x="16" y="16" width="4" height="4" fill="#38bdf8" />
                </svg>
              </div>
            </div>

            <h2 className="text-lg sm:text-xl font-black text-zinc-100 tracking-tight drop-shadow-[0_0_12px_rgba(255,255,255,0.45)] group-hover:text-amber-200 transition-colors">
              Nexus Scan
            </h2>

            {/* Quota Pill Button */}
            <div className="mt-2 px-3 py-1 rounded-md bg-black/80 border border-cyan-500/50 hover:border-cyan-400 text-cyan-300 font-mono text-[11px] font-bold shadow-[0_0_10px_rgba(6,182,212,0.25)] flex items-center gap-1.5 transition-transform group-hover:scale-105">
              <span className="w-2 h-2 rounded-[1px] bg-cyan-400 shadow-[0_0_6px_#22d3ee] inline-block shrink-0" />
              <span>
                {scansLeft} / {DAILY_CAP} scans left
              </span>
            </div>
          </div>

          {/* Bottom helper text */}
          <div className="relative z-10 text-[10px] text-zinc-400 font-mono">
            Tap anywhere on scanner to scan packaging
          </div>
        </div>

        {/* -----------------------------------------------------------------------
            RIGHT COLUMN (3 Columns): 2x2 Tactical Grid + Wallet & Trading Cards
            ----------------------------------------------------------------------- */}
        <div className="col-span-12 md:col-span-3 flex flex-col justify-between gap-2.5 sm:gap-3">
          {/* Top 2x2 Action Button Grid */}
          <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
            {/* 1. Trophy / Achievements */}
            <button
              onClick={() => onOpenScreen('achievements')}
              title="Achievements & Leaderboard"
              aria-label="Achievements & Leaderboard"
              className="h-16 sm:h-[70px] rounded-2xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 p-2 flex flex-col items-center justify-center gap-1 text-amber-400 hover:text-amber-300 hover:bg-black/75 active:scale-95 transition-all cursor-pointer shadow-[0_0_12px_rgba(245,158,11,0.1)] group"
            >
              <Trophy className="w-5 h-5 sm:w-6 sm:h-6 group-hover:scale-110 transition-transform drop-shadow-[0_0_8px_rgba(251,191,36,0.5)]" />
              <span className="text-[9.5px] font-bold text-zinc-300 group-hover:text-amber-200">
                Rankings
              </span>
            </button>

            {/* 2. Cyber Node / Architecture */}
            <button
              onClick={() => onOpenScreen('architecture')}
              title="Naturans Executive Architecture"
              aria-label="Executive Architecture"
              className="h-16 sm:h-[70px] rounded-2xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 p-2 flex flex-col items-center justify-center gap-1 text-cyan-400 hover:text-cyan-300 hover:bg-black/75 active:scale-95 transition-all cursor-pointer shadow-[0_0_12px_rgba(245,158,11,0.1)] group"
            >
              <Terminal className="w-5 h-5 sm:w-6 sm:h-6 group-hover:scale-110 transition-transform drop-shadow-[0_0_8px_rgba(6,182,212,0.5)]" />
              <span className="text-[9.5px] font-bold text-zinc-300 group-hover:text-cyan-200">
                Console
              </span>
            </button>

            {/* 3. Gift / Daily Streak */}
            <button
              onClick={() => onOpenScreen('daily')}
              title="Daily Check-in Reward"
              aria-label="Daily Check-in Reward"
              className="relative h-16 sm:h-[70px] rounded-2xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 p-2 flex flex-col items-center justify-center gap-1 text-orange-400 hover:text-orange-300 hover:bg-black/75 active:scale-95 transition-all cursor-pointer shadow-[0_0_12px_rgba(245,158,11,0.1)] group"
            >
              <Gift className="w-5 h-5 sm:w-6 sm:h-6 group-hover:scale-110 transition-transform drop-shadow-[0_0_8px_rgba(251,146,60,0.5)]" />
              <span className="text-[9.5px] font-bold text-zinc-300 group-hover:text-orange-200">
                Daily Drop
              </span>
              {!claimedToday && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 shadow-[0_0_6px_#f43f5e] animate-pulse" />
              )}
            </button>

            {/* 4. CPU / Node Staking */}
            <button
              onClick={() => onOpenScreen('staking')}
              title="Teraxiom Staking & Nodes"
              aria-label="Teraxiom Staking & Nodes"
              className="h-16 sm:h-[70px] rounded-2xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 p-2 flex flex-col items-center justify-center gap-1 text-[#22c55e] hover:text-[#4ade80] hover:bg-black/75 active:scale-95 transition-all cursor-pointer shadow-[0_0_12px_rgba(245,158,11,0.1)] group"
            >
              <Cpu className="w-5 h-5 sm:w-6 sm:h-6 group-hover:scale-110 transition-transform drop-shadow-[0_0_8px_rgba(34,197,94,0.5)]" />
              <span className="text-[9.5px] font-bold text-zinc-300 group-hover:text-emerald-200">
                Staking
              </span>
            </button>
          </div>

          {/* Bottom Row: 2 Taller Cards (Wallet & Trading) */}
          <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
            {/* Wallet Card */}
            <button
              onClick={() => onGuardScreen('wallet')}
              title="Open Wallet"
              aria-label="Open Wallet"
              className="h-20 sm:h-[84px] rounded-2xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 p-2 flex flex-col items-center justify-center gap-1.5 hover:bg-black/75 active:scale-95 transition-all cursor-pointer shadow-[0_0_12px_rgba(245,158,11,0.1)] group"
            >
              <div className="w-8 h-8 rounded-xl bg-emerald-950/70 border border-emerald-500/40 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Wallet className="w-4 h-4 text-emerald-400" />
              </div>
              <span className="text-xs font-bold text-zinc-200 group-hover:text-emerald-300">
                Wallet
              </span>
            </button>

            {/* Trading Card */}
            <button
              onClick={() => onGuardScreen('trade')}
              title="Open Trading Exchange"
              aria-label="Open Trading Exchange"
              className="h-20 sm:h-[84px] rounded-2xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 p-2 flex flex-col items-center justify-center gap-1.5 hover:bg-black/75 active:scale-95 transition-all cursor-pointer shadow-[0_0_12px_rgba(245,158,11,0.1)] group"
            >
              <div className="w-8 h-8 rounded-xl bg-blue-950/70 border border-blue-500/40 text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <TrendingUp className="w-4 h-4 text-blue-400" />
              </div>
              <span className="text-xs font-bold text-zinc-200 group-hover:text-blue-300">
                Trading
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* =========================================================================
          BOTTOM DOCK NAVIGATION: 6 TACTICAL PILL BUTTONS
          [ Companies ] [ Missions ] [ Rewards ] [ Contacts ] [ History ] [ Settings ]
          ========================================================================= */}
      <nav
        aria-label="Primary Navigation"
        className="w-full grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 sm:gap-2.5 mt-0.5"
      >
        {/* 1. Companies */}
        <button
          onClick={() => onOpenScreen('companies')}
          className="h-11 sm:h-12 rounded-xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 px-3 flex items-center justify-center gap-2 text-xs font-bold text-zinc-200 hover:text-cyan-300 hover:bg-black/75 active:scale-95 transition shadow-[0_0_10px_rgba(245,158,11,0.08)] cursor-pointer group"
        >
          <Building2 className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform shrink-0" />
          <span className="truncate">Companies</span>
        </button>

        {/* 2. Missions */}
        <button
          onClick={() => onOpenScreen('missions')}
          className="relative h-11 sm:h-12 rounded-xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 px-3 flex items-center justify-center gap-2 text-xs font-bold text-zinc-200 hover:text-amber-300 hover:bg-black/75 active:scale-95 transition shadow-[0_0_10px_rgba(245,158,11,0.08)] cursor-pointer group"
        >
          <Target className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform shrink-0" />
          <span className="truncate">Missions</span>
          {claimableMissionsCount > 0 && (
            <span className="absolute top-1 right-2 min-w-[16px] h-4 px-1 rounded-full bg-rose-600 text-white font-mono text-[9px] font-black flex items-center justify-center shadow-sm animate-pulse">
              {claimableMissionsCount}
            </span>
          )}
        </button>

        {/* 3. Rewards */}
        <button
          onClick={() => onGuardScreen('store')}
          className="h-11 sm:h-12 rounded-xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 px-3 flex items-center justify-center gap-2 text-xs font-bold text-zinc-200 hover:text-amber-300 hover:bg-black/75 active:scale-95 transition shadow-[0_0_10px_rgba(245,158,11,0.08)] cursor-pointer group"
        >
          <Ticket className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform shrink-0" />
          <span className="truncate">Rewards</span>
        </button>

        {/* 4. Contacts */}
        <button
          onClick={() => onOpenScreen('social')}
          className="h-11 sm:h-12 rounded-xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 px-3 flex items-center justify-center gap-2 text-xs font-bold text-zinc-200 hover:text-cyan-300 hover:bg-black/75 active:scale-95 transition shadow-[0_0_10px_rgba(245,158,11,0.08)] cursor-pointer group"
        >
          <Users className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform shrink-0" />
          <span className="truncate">Contacts</span>
        </button>

        {/* 5. History */}
        <button
          onClick={() => onOpenScreen('history')}
          className="h-11 sm:h-12 rounded-xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 px-3 flex items-center justify-center gap-2 text-xs font-bold text-zinc-200 hover:text-indigo-300 hover:bg-black/75 active:scale-95 transition shadow-[0_0_10px_rgba(245,158,11,0.08)] cursor-pointer group"
        >
          <Receipt className="w-4 h-4 text-indigo-400 group-hover:scale-110 transition-transform shrink-0" />
          <span className="truncate">History</span>
        </button>

        {/* 6. Settings */}
        <button
          onClick={() => onOpenScreen('settings')}
          className="h-11 sm:h-12 rounded-xl bg-black/65 backdrop-blur-md border border-amber-500/35 hover:border-amber-500/60 px-3 flex items-center justify-center gap-2 text-xs font-bold text-zinc-200 hover:text-zinc-100 hover:bg-black/75 active:scale-95 transition shadow-[0_0_10px_rgba(245,158,11,0.08)] cursor-pointer group"
        >
          <Settings className="w-4 h-4 text-zinc-400 group-hover:text-zinc-200 group-hover:rotate-45 transition-transform shrink-0" />
          <span className="truncate">Settings</span>
        </button>
      </nav>
    </div>
  );
};
