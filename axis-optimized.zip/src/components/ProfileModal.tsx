import React, { useState } from 'react';
import { AxisState } from '../types';
import { copyText } from '../utils';

interface ProfileModalProps {
  state: AxisState;
  onSaveProfile: (name: string, email: string, avatar: string) => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
  onLogout?: () => void;
}

const EMOJIS = ['👤', '🌼', '🦊', '🐼', '🦁', '🐢', '🌴', '⭐'];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  state,
  onSaveProfile,
  onToast,
  onLogout
}) => {
  const [name, setName] = useState(state.profile.name || 'Axis User');
  const [email, setEmail] = useState(state.profile.email || '');
  const [avatar, setAvatar] = useState(state.profile.avatar || '👤');

  const handleAvatarFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 96;
      canvas.height = 96;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const s = Math.min(img.width, img.height);
        ctx.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 96, 96);
        setAvatar(canvas.toDataURL('image/jpeg', 0.85));
      }
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim().length < 2) {
      onToast('Enter a valid name', 'err');
      return;
    }
    onSaveProfile(name.trim(), email.trim(), avatar);
    onToast('Profile updated!', 'good');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 select-none">
      {/* Avatar preview & emoji picker - Neumorphic Extruded Plate */}
      <div className="p-4 rounded-2xl neu-flat text-center space-y-3">
        <div className="w-20 h-20 rounded-full neu-inset mx-auto flex items-center justify-center text-3xl overflow-hidden">
          {avatar.startsWith('data:') ? (
            <img src={avatar} alt="Avatar" className="w-full h-full object-cover" />
          ) : (
            avatar
          )}
        </div>

        <div className="flex gap-2 justify-center flex-wrap">
          {EMOJIS.map((emoji) => (
            <button
              type="button"
              key={emoji}
              onClick={() => setAvatar(emoji)}
              className="w-8 h-8 rounded-lg neu-btn text-base flex items-center justify-center cursor-pointer"
            >
              {emoji}
            </button>
          ))}
          <label className="px-3 h-8 rounded-lg neu-btn text-xs font-bold flex items-center justify-center cursor-pointer">
            <span>Custom Photo</span>
            <input type="file" accept="image/*" hidden onChange={handleAvatarFile} />
          </label>
        </div>
      </div>

      {/* Fields - Neumorphic Extruded Card */}
      <div className="p-4 rounded-2xl neu-flat space-y-3 text-xs">
        <div>
          <label className="block font-bold text-[var(--ink)] mb-1">Display Name</label>
          <input
            type="text"
            required
            maxLength={40}
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl neu-input text-[var(--ink)] text-sm"
          />
        </div>

        <div>
          <label className="block font-bold text-[var(--ink)] mb-1">Email Address</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="w-full px-3.5 py-2.5 rounded-xl neu-input text-[var(--ink)] text-sm"
          />
        </div>

        {/* Axis App User ID (Identity Anchor for TERRA Website) */}
        <div className="p-3 rounded-xl neu-inset-sm flex items-center justify-between">
          <div>
            <b className="block text-[var(--ink)]">Axis App User ID</b>
            <small className="text-[var(--ink2)]">Teraxiom Website Identity Anchor</small>
          </div>
          <button
            type="button"
            onClick={() => {
              const id = state.identityAnchor?.axisUserId || state.axisUserId || state.profile.axisUserId || state.accountId;
              copyText(id, () => onToast(`Axis User ID copied: ${id}`, 'good'));
            }}
            className="px-2.5 py-1 rounded-md neu-inset-sm text-emerald-600 dark:text-emerald-400 font-extrabold text-[11px] font-mono cursor-pointer active:scale-95 transition"
            title="Click to copy official Axis ID for Teraxiom Website"
          >
            {state.identityAnchor?.axisUserId || state.axisUserId || state.profile.axisUserId || state.accountId}
          </button>
        </div>

        {/* KYC verification badge */}
        <div className="p-3 rounded-xl neu-inset-sm flex items-center justify-between">
          <div>
            <b className="block text-[var(--ink)]">KYC Identity Tier</b>
            <small className="text-[var(--ink2)]">Tier 1 · Basic Local Pass</small>
          </div>
          <span className="px-2.5 py-0.5 rounded-md neu-inset-sm text-emerald-600 dark:text-emerald-400 font-extrabold text-[10px] font-mono">
            Active
          </span>
        </div>
      </div>

      <div className="space-y-2 pt-1">
        <button
          type="submit"
          className="w-full py-3 rounded-xl neu-btn-accent font-extrabold text-sm shadow-xs transition cursor-pointer"
        >
          Save Changes
        </button>

        {onLogout && (
          <button
            type="button"
            onClick={onLogout}
            className="w-full py-2.5 rounded-xl neu-btn text-rose-600 dark:text-rose-400 font-bold text-xs transition cursor-pointer hover:bg-rose-500/10 active:scale-98"
          >
            Sign Out of Axis Account
          </button>
        )}
      </div>
    </form>
  );
};
