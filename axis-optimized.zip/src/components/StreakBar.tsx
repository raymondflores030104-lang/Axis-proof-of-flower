import React from 'react';
import { AxisState } from '../types';
import { Flame, Sparkles, ChevronRight, Check } from 'lucide-react';

interface StreakBarProps {
  state: AxisState;
  onOpenDaily: () => void;
  onOpenRewards?: () => void;
}

const STREAK_BONUSES = [0.5, 1.0, 1.5, 2.0, 3.0, 4.5, 10.0];

export const StreakBar: React.FC<StreakBarProps> = ({ state, onOpenDaily }) => {
  const curStreak = state?.claim?.streak || 1;
  const streakDayIndex = ((curStreak - 1) % 7);
  const claimedToday = Boolean(state?.claim?.last && state?.claim?.last === state?.day?.key);
  const nextReward = STREAK_BONUSES[streakDayIndex];

  return (
    <div
      data-zone="streak-bar"
      role="button"
      tabIndex={0}
      onClick={onOpenDaily}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onOpenDaily();
        }
      }}
      aria-label={`Daily Streak Bar: Day ${curStreak} streak. ${claimedToday ? 'Claimed for today' : `Claim ready: +${nextReward} FLRX`}. Tap to view daily bonuses.`}
      className="w-full mt-2.5 sm:mt-3 landscape:mt-1.5 p-2.5 sm:p-3 landscape:p-2 rounded-2xl neu-flat hover:neu-flat-lg transition-all duration-200 cursor-pointer select-none group border border-white/10 dark:border-white/10 focus-visible:ring-2 focus-visible:ring-amber-500 overflow-hidden relative"
    >
      {/* Subtle background glow highlight */}
      <div className="absolute -right-8 -top-8 w-24 h-24 rounded-full bg-amber-500/10 dark:bg-amber-400/10 blur-xl pointer-events-none" />

      {/* Top Row: Streak Counter & Status */}
      <div className="flex items-center justify-between gap-2 mb-1.5 sm:mb-2 landscape:mb-1 relative z-10">
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
          <div className="w-7 h-7 sm:w-8 sm:h-8 landscape:w-6 landscape:h-6 rounded-xl neu-inset flex items-center justify-center shrink-0 text-amber-500 dark:text-amber-400">
            <Flame className="w-4 h-4 sm:w-4.5 sm:h-4.5 landscape:w-3.5 landscape:h-3.5 animate-pulse" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xs sm:text-sm landscape:text-xs text-[var(--ink)] tracking-tight">
                Day {curStreak} Streak
              </span>
              <span className="text-[10px] landscape:text-[9px] font-mono font-bold text-amber-600 dark:text-amber-400 neu-inset-sm px-1.5 py-0.5 rounded-md leading-none">
                {curStreak >= 7 ? 'MAX 🔥' : `x${(1 + curStreak * 0.1).toFixed(1)}`}
              </span>
            </div>
            <p className="text-[10px] landscape:text-[8.5px] text-[var(--ink2)] font-mono truncate leading-tight mt-0.5">
              {claimedToday
                ? 'Streak secured for today'
                : `Reward ready: +${nextReward} FLRX bonus!`}
            </p>
          </div>
        </div>

        {/* Action Button Badge */}
        <div className="flex items-center gap-1 shrink-0">
          <span
            className={`text-[10.5px] landscape:text-[9.5px] font-bold px-2 py-0.5 sm:py-1 rounded-lg flex items-center gap-1 transition-colors ${
              claimedToday
                ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                : 'bg-amber-500/20 text-amber-600 dark:text-amber-300 border border-amber-500/30 shadow-xs'
            }`}
          >
            {claimedToday ? (
              <>
                <Check className="w-3 h-3 stroke-[3]" />
                <span>Claimed</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3 h-3 animate-spin" style={{ animationDuration: '4s' }} />
                <span>Claim</span>
              </>
            )}
            <ChevronRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
          </span>
        </div>
      </div>

      {/* 7-Day Milestone Progress Pips */}
      <div className="grid grid-cols-7 gap-1 sm:gap-1.5 pt-1 border-t border-black/5 dark:border-white/5 relative z-10">
        {[1, 2, 3, 4, 5, 6, 7].map((day) => {
          const isPassed = day < (streakDayIndex + 1) || (day === (streakDayIndex + 1) && claimedToday);
          const isToday = day === (streakDayIndex + 1) && !claimedToday;
          const bonus = STREAK_BONUSES[day - 1];

          return (
            <div
              key={day}
              className={`flex flex-col items-center justify-center py-1 sm:py-1.5 landscape:py-0.5 px-0.5 rounded-lg text-center transition-all ${
                isPassed
                  ? 'bg-emerald-500/15 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400'
                  : isToday
                  ? 'bg-amber-500/20 border border-amber-500/40 text-amber-600 dark:text-amber-300 ring-1 ring-amber-500/30'
                  : 'bg-black/5 dark:bg-white/5 border border-transparent text-[var(--ink2)] opacity-60'
              }`}
            >
              <span className="text-[8.5px] sm:text-[9px] landscape:text-[8px] font-bold tracking-tight uppercase">
                D{day}
              </span>
              <span className="text-[9px] sm:text-[9.5px] landscape:text-[8px] font-mono font-black leading-tight">
                +{bonus}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
