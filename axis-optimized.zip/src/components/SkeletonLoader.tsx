import React from 'react';

export const SkeletonLoader: React.FC = () => {
  return (
    <div className="relative z-10 max-w-md mx-auto p-3.5 pb-8 space-y-3.5 select-none animate-fade-in">
      {/* 1. Header Skeleton */}
      <header className="p-2 rounded-2xl neu-flat flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl skeleton-shimmer shrink-0" />
          <div className="space-y-1.5">
            <div className="w-20 h-3.5 rounded-md skeleton-shimmer" />
            <div className="w-28 h-2.5 rounded-md skeleton-shimmer" />
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="w-8 h-8 rounded-xl skeleton-shimmer shrink-0" />
          ))}
        </div>
      </header>

      {/* 2. Dual Balance Card Skeleton */}
      <div className="p-2 rounded-2xl neu-flat flex gap-2.5">
        <div className="flex-1 p-3.5 rounded-xl neu-inset space-y-2 flex flex-col items-center">
          <div className="w-16 h-3 rounded-md skeleton-shimmer" />
          <div className="w-24 h-6 rounded-md skeleton-shimmer" />
          <div className="w-14 h-2.5 rounded-md skeleton-shimmer" />
        </div>
        <div className="flex-1 p-3.5 rounded-xl neu-inset space-y-2 flex flex-col items-center">
          <div className="w-16 h-3 rounded-md skeleton-shimmer" />
          <div className="w-24 h-6 rounded-md skeleton-shimmer" />
          <div className="w-14 h-2.5 rounded-md skeleton-shimmer" />
        </div>
      </div>

      {/* 3. Post-Scan HUD Banner Skeleton */}
      <div className="p-3 rounded-2xl neu-flat flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 flex-1">
          <div className="w-8 h-8 rounded-xl skeleton-shimmer shrink-0" />
          <div className="space-y-1 flex-1">
            <div className="w-3/4 h-3 rounded-md skeleton-shimmer" />
            <div className="w-1/2 h-2 rounded-md skeleton-shimmer" />
          </div>
        </div>
        <div className="w-14 h-6 rounded-xl skeleton-shimmer shrink-0" />
      </div>

      {/* 4. Action Tiles Grid Skeleton (Exact geometry match) */}
      <div className="grid grid-cols-4 gap-2.5">
        {/* Large Hero Scanner 2x2 */}
        <div className="col-span-2 row-span-2 p-4 rounded-2xl neu-flat min-h-[175px] flex flex-col items-center justify-center gap-3">
          <div className="w-20 h-4 rounded-md skeleton-shimmer self-start" />
          <div className="w-14 h-14 rounded-2xl skeleton-shimmer" />
          <div className="w-24 h-4 rounded-md skeleton-shimmer" />
          <div className="w-20 h-3 rounded-md skeleton-shimmer" />
        </div>

        {/* 2 Tile Blocks on right */}
        <div className="p-3 rounded-2xl neu-flat min-h-[84px] flex flex-col items-center justify-center gap-2">
          <div className="w-8 h-8 rounded-xl skeleton-shimmer" />
          <div className="w-12 h-2.5 rounded-md skeleton-shimmer" />
        </div>
        <div className="p-3 rounded-2xl neu-flat min-h-[84px] flex flex-col items-center justify-center gap-2">
          <div className="w-8 h-8 rounded-xl skeleton-shimmer" />
          <div className="w-12 h-2.5 rounded-md skeleton-shimmer" />
        </div>
        <div className="p-3 rounded-2xl neu-flat min-h-[84px] flex flex-col items-center justify-center gap-2">
          <div className="w-8 h-8 rounded-xl skeleton-shimmer" />
          <div className="w-12 h-2.5 rounded-md skeleton-shimmer" />
        </div>
        <div className="p-3 rounded-2xl neu-flat min-h-[84px] flex flex-col items-center justify-center gap-2">
          <div className="w-8 h-8 rounded-xl skeleton-shimmer" />
          <div className="w-12 h-2.5 rounded-md skeleton-shimmer" />
        </div>

        {/* Bottom row of 4 tiles */}
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="p-3 rounded-2xl neu-flat min-h-[84px] flex flex-col items-center justify-center gap-2">
            <div className="w-8 h-8 rounded-xl skeleton-shimmer" />
            <div className="w-12 h-2.5 rounded-md skeleton-shimmer" />
          </div>
        ))}
      </div>
    </div>
  );
};
