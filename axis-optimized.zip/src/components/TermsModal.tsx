import React from 'react';
import { FileText } from 'lucide-react';

export const TermsModal: React.FC = () => {
  return (
    <div className="space-y-3 text-xs leading-relaxed text-[var(--ink)] select-none max-h-[60vh] overflow-y-auto pr-1">
      <div className="flex items-center gap-2 text-emerald-600">
        <FileText className="w-5 h-5" />
        <h4 className="font-extrabold text-sm text-[var(--ink)]">Terms of Service</h4>
      </div>
      <p>
        By participating in the Axis Proof-of-Scan Network, users agree to the following terms:
      </p>
      <ul className="list-disc pl-5 space-y-1 text-[var(--ink2)]">
        <li>Rewards are distributed based on genuine consumer interactions with verified product packaging.</li>
        <li>Automated barcode spamming, emulated camera scripts, or artificial replay attacks will trigger protocol cooling-off limits.</li>
        <li>FLRX token redemptions are subject to liquidity pool availability and partner store voucher validation.</li>
      </ul>
    </div>
  );
};
