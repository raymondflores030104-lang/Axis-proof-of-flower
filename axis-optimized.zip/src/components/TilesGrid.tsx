import React, { useState, useEffect } from 'react';
import { AxisState } from '../types';
import { DAILY_CAP } from '../constants';
import { curInfo } from '../utils';
import {
  QrCode,
  Wallet,
  TrendingUp,
  Building2,
  Target,
  Ticket,
  Users,
  Receipt,
  Settings
} from 'lucide-react';

interface TilesGridProps {
  state: AxisState;
  chg24: number;
  claimableMissionsCount: number;
  onOpenScreen: (screen: string) => void;
  onGuardScreen: (screen: string) => void;
  isLoaded?: boolean;
  entranceSettled?: boolean;
}

export const TilesGrid: React.FC<TilesGridProps> = ({
  state,
  chg24,
  claimableMissionsCount,
  onOpenScreen,
  onGuardScreen,
  isLoaded = true,
  entranceSettled = false
}) => {
  const scansLeft = Math.max(0, DAILY_CAP - (state.day?.scans || 0));

  // Dynamic currency-adaptive market pair and price (FlowerXcoin / FLWRX)
  const activeCur = state.settings?.currency || 'PHP';
  const [curSym, curRate] = curInfo(activeCur);
  const pairLabel = `FLWRX/${activeCur}:`;
  const displayPrice = activeCur === 'USD'
    ? `$${state.price.toFixed(4)}`
    : `${curSym}${(state.price * curRate).toFixed(2)}`;

  // Staggered entrance animation state
  const [inView, setInView] = useState(false);
  const [hasAnimated, setHasAnimated] = useState(false);

  useEffect(() => {
    // Respect accessibility settings
    const prefersReduced =
      typeof window !== 'undefined' &&
      typeof window.matchMedia === 'function' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (prefersReduced) {
      setInView(true);
      setHasAnimated(true);
      return;
    }

    if (isLoaded) {
      // Trigger entrance transition once the app unveils
      const rafId = requestAnimationFrame(() => {
        setInView(true);
      });

      // Clear inline transitions after sequence finishes (180ms base + 8 * 45ms + 520ms ~ 1060ms)
      // so normal hover & active transforms function with zero lingering transition-delay
      const timer = setTimeout(() => {
        setHasAnimated(true);
      }, 1150);

      return () => {
        cancelAnimationFrame(rafId);
        clearTimeout(timer);
      };
    } else {
      setInView(false);
      setHasAnimated(false);
    }
  }, [isLoaded]);

  /**
   * Staggered entrance style per tile index
   * Uses a premium spring-like cubic-bezier ease-out (0.16, 1, 0.3, 1)
   * Base delay coordinates seamlessly with the left column waterfall animation
   */
  const getTileStyle = (_index: number): React.CSSProperties => {
    // Once settled, let CSS handle all normal interactions and hovers cleanly
    if (hasAnimated || entranceSettled) {
      return {};
    }
    return {};
  };

  return (
    <div className="tiles-grid grid grid-cols-3 gap-[clamp(0.45rem,1.4vh,0.85rem)] select-none flex-1">
      {/* 1. Large Scanner Hero Tile (Stage 3: Main dashboard action) */}
      <div
        data-zone="hero"
        data-stage="3"
        role="button"
        tabIndex={0}
        style={getTileStyle(0)}
        onClick={() => onOpenScreen('scanner')}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onOpenScreen('scanner');
          }
        }}
        aria-label={`Nexus Scan, ${scansLeft} of ${DAILY_CAP} daily scans left`}
        className={`group col-span-2 row-span-2 relative p-2.5 sm:p-3 rounded-2xl neu-flat hover:neu-flat-lg text-[var(--ink)] flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl active:scale-[0.98] h-[160px] min-h-[160px] overflow-hidden focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden tiles-grid-item axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
      >
        {/* Dynamic Currency-Adaptive Market Ticker Chip - Unclipped */}
        <div
          role="button"
          tabIndex={0}
          onClick={(e) => {
            e.stopPropagation();
            onGuardScreen('trade');
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              e.stopPropagation();
              onGuardScreen('trade');
            }
          }}
          className="absolute top-2 left-2 right-2 sm:top-2.5 sm:left-2.5 sm:right-2.5 neu-inset-sm rounded-lg px-2 sm:px-2.5 py-1 text-left flex items-center justify-between gap-1.5 overflow-hidden z-10 hover:bg-black/8 dark:hover:bg-white/8 active:scale-[0.97] transition-all cursor-pointer focus-visible:ring-1 focus-visible:ring-emerald-500"
          title={`${pairLabel} ${displayPrice} • Tap to trade`}
          aria-label={`${pairLabel} price is ${displayPrice}, ${chg24 >= 0 ? '+' : ''}${chg24.toFixed(1)}%`}
        >
          <span className="text-[9px] font-extrabold text-[var(--accent)] uppercase leading-none shrink-0">
            {pairLabel}
          </span>
          <span className="text-[10px] font-bold font-mono text-[var(--ink)] leading-none shrink-0">
            {displayPrice}
          </span>
          <span className={`text-[9px] font-bold font-mono leading-none shrink-0 ${chg24 >= 0 ? 'text-[var(--accent)]' : 'text-rose-600'}`}>
            {chg24 >= 0 ? '+' : ''}{chg24.toFixed(1)}%
          </span>
        </div>

        {/* QR Scan Glyph Container with subtle hover elevation */}
        <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl neu-inset flex items-center justify-center mt-3 text-[var(--accent)] group-hover:scale-105 group-hover:shadow-xs transition-transform duration-250">
          <QrCode className="w-5.5 h-5.5 group-hover:text-emerald-500 transition-colors" />
        </div>
        
        <span className="font-extrabold text-sm sm:text-base tracking-tight text-[var(--ink)] group-hover:text-[var(--accent)] transition-colors leading-tight">
          Nexus Scan
        </span>
        <span className="text-[9.5px] sm:text-[10px] font-semibold text-[var(--ink2)] neu-inset-sm px-2 py-0.5 rounded-md font-mono flex items-center gap-1.5 whitespace-nowrap leading-none">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0" aria-hidden="true" />
          <span>{scansLeft} / {DAILY_CAP} scans left</span>
        </span>
      </div>

      {/* 2. Wallet Tile (Stage 4: Primary lower content) */}
      <button
        data-zone="tile"
        data-slot="side"
        data-stage="4"
        style={getTileStyle(1)}
        onClick={() => onGuardScreen('wallet')}
        className={`group col-span-1 p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1 h-[80px] min-h-[80px] cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden tiles-grid-item axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
        aria-label="Open Wallet"
      >
        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl neu-inset text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
          <Wallet className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </div>
        <span className="text-[11px] sm:text-xs group-hover:text-[var(--accent)] transition-colors duration-150">Wallet</span>
      </button>

      {/* 3. Trade Tile (Stage 4: Primary lower content) - With Mini Sparkline Trend */}
      <button
        data-zone="tile"
        data-slot="side"
        data-stage="4"
        style={getTileStyle(2)}
        onClick={() => onGuardScreen('trade')}
        className={`group col-span-1 p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1 h-[80px] min-h-[80px] cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden tiles-grid-item axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
        aria-label="Open Trading Exchange"
      >
        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl neu-inset text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
          <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </div>
        <span className="text-[11px] sm:text-xs group-hover:text-[var(--accent)] transition-colors duration-150">Trading</span>
        {/* Subtle mini trend curve */}
        <div className="w-8 h-1.5 opacity-60 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <svg className="w-full h-full text-blue-500 dark:text-blue-400" viewBox="0 0 28 8" fill="none">
            <path d="M1 7 L7 5 L13 6 L19 2 L23 3 L27 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </button>

      {/* 4. Companies Tile (Stage 4: Primary lower content) */}
      <button
        data-zone="tile"
        data-slot="dock"
        data-stage="4"
        style={getTileStyle(3)}
        onClick={() => onOpenScreen('companies')}
        className={`group col-span-1 p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1 h-[80px] min-h-[80px] cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden tiles-grid-item axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
        aria-label="View Verified Companies"
      >
        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl neu-inset text-teal-600 dark:text-teal-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
          <Building2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </div>
        <span className="text-[11px] sm:text-xs group-hover:text-[var(--accent)] transition-colors duration-150">Companies</span>
      </button>

      {/* 5. Missions Tile (Stage 4: Primary lower content) - With Active Mini Progress Bar */}
      <button
        data-zone="tile"
        data-slot="dock"
        data-stage="4"
        style={getTileStyle(4)}
        onClick={() => onOpenScreen('missions')}
        className={`group col-span-1 relative p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1 h-[80px] min-h-[80px] cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden tiles-grid-item axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
        aria-label="Open Missions and Quests"
      >
        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl neu-inset text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
          <Target className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </div>
        <span className="text-[11px] sm:text-xs group-hover:text-[var(--accent)] transition-colors duration-150">Missions</span>
        {claimableMissionsCount > 0 ? (
          <span className="absolute top-1.5 right-1.5 min-w-[17px] h-[17px] px-1 rounded-full bg-rose-600 text-white font-extrabold text-[9px] flex items-center justify-center shadow-xs animate-pulse ring-2 ring-white/50 dark:ring-black/50">
            {claimableMissionsCount}
          </span>
        ) : (
          <div className="w-8 h-1 rounded-full bg-black/10 dark:bg-white/10 overflow-hidden">
            <div className="h-full bg-amber-500 rounded-full w-2/3" />
          </div>
        )}
      </button>

      {/* 6. Rewards Store Tile (Stage 4: Primary lower content) */}
      <button
        data-zone="tile"
        data-slot="dock"
        data-stage="4"
        style={getTileStyle(5)}
        onClick={() => onGuardScreen('store')}
        className={`group col-span-1 p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1 h-[80px] min-h-[80px] cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden tiles-grid-item axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
        aria-label="Open Rewards Store"
      >
        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl neu-inset text-orange-600 dark:text-orange-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
          <Ticket className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </div>
        <span className="text-[11px] sm:text-xs group-hover:text-[var(--accent)] transition-colors duration-150">Rewards</span>
      </button>

      {/* 7. Social / Contacts Tile (Stage 5: Navigation & secondary dock) */}
      <button
        data-zone="tile"
        data-slot="dock"
        data-stage="5"
        style={getTileStyle(6)}
        onClick={() => onOpenScreen('social')}
        className={`group col-span-1 p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1 h-[80px] min-h-[80px] cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden tiles-grid-item axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
        aria-label="Open Contacts and Social Network"
      >
        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl neu-inset text-cyan-600 dark:text-cyan-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
          <Users className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </div>
        <span className="text-[11px] sm:text-xs group-hover:text-[var(--accent)] transition-colors duration-150">Contacts</span>
      </button>

      {/* 8. History Tile (Stage 5: Navigation & secondary dock) */}
      <button
        data-zone="tile"
        data-slot="dock"
        data-stage="5"
        style={getTileStyle(7)}
        onClick={() => onOpenScreen('history')}
        className={`group col-span-1 relative p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1 h-[80px] min-h-[80px] cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden tiles-grid-item axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
        aria-label="Open Scan and Transaction History"
      >
        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl neu-inset text-indigo-600 dark:text-indigo-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
          <Receipt className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </div>
        <span className="text-[11px] sm:text-xs group-hover:text-[var(--accent)] transition-colors duration-150">History</span>
      </button>

      {/* 9. Settings Tile (Stage 5: Navigation & secondary dock) */}
      <button
        data-zone="tile"
        data-slot="dock"
        data-stage="5"
        style={getTileStyle(8)}
        onClick={() => onOpenScreen('settings')}
        className={`group col-span-1 p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1 h-[80px] min-h-[80px] cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden tiles-grid-item axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
        aria-label="Open System Settings"
      >
        <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl neu-inset text-zinc-600 dark:text-zinc-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
          <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </div>
        <span className="text-[11px] sm:text-xs group-hover:text-[var(--accent)] transition-colors duration-150">Settings</span>
      </button>
    </div>
  );
};

/* =========================================================================
   ZONE B (CENTER COLUMN): NEXUS SCAN HERO CARD
   ========================================================================= */

interface NexusScanHeroCardProps {
  state: AxisState;
  chg24?: number;
  onOpenScanner: () => void;
  onOpenTrade: () => void;
  isLoaded?: boolean;
}

export const NexusScanHeroCard: React.FC<NexusScanHeroCardProps> = ({
  state,
  chg24 = 2.45,
  onOpenScanner,
  onOpenTrade
}) => {
  const scansLeft = Math.max(0, DAILY_CAP - (state.day?.scans || 0));

  return (
    <div
      data-zone="hero"
      role="button"
      tabIndex={0}
      onClick={onOpenScanner}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onOpenScanner();
        }
      }}
      aria-label={`Nexus Scan, ${scansLeft} of ${DAILY_CAP} daily scans left`}
      className="group relative p-3 sm:p-3.5 rounded-2xl neu-flat hover:neu-flat-lg text-[var(--ink)] flex flex-col items-center justify-between cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl active:scale-[0.98] h-full min-h-0 overflow-hidden focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden select-none w-full"
    >
      {/* Top Bar: Scan Quota & Network Mode */}
      <div className="w-full flex items-center justify-between gap-2 px-1">
        <div className="neu-inset-sm px-2.5 py-0.5 rounded-full flex items-center gap-1.5 text-[10px] font-mono text-[var(--ink2)]">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" aria-hidden="true" />
          <span className="font-semibold whitespace-nowrap">{scansLeft} / {DAILY_CAP} scans left</span>
        </div>
        <span className="hidden sm:inline-block text-[9.5px] uppercase font-extrabold tracking-wider text-[var(--accent)] font-mono shrink-0">
          Primary Action
        </span>
      </div>

      {/* Center: Prominent QR Scan Viewfinder Reticle */}
      <div className="relative flex flex-col items-center justify-center my-auto">
        <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-2xl neu-inset flex items-center justify-center text-[var(--accent)] group-hover:scale-105 group-hover:shadow-md transition-all duration-250">
          <QrCode className="w-7 h-7 sm:w-8 sm:h-8 group-hover:text-emerald-500 transition-colors" />
          {/* Subtle animated laser line */}
          <div className="absolute inset-x-2 top-2 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent opacity-80 animate-pulse" />
        </div>
      </div>

      {/* Bottom: Scan Label & Hint */}
      <div className="w-full flex flex-col items-center gap-0.5">
        <span className="font-black text-sm sm:text-base tracking-tight text-[var(--ink)] group-hover:text-[var(--accent)] transition-colors leading-tight">
          Nexus Scan
        </span>
        <span className="text-[10px] sm:text-[11px] text-[var(--ink2)] font-mono text-center">
          Tap to scan flower QR codes
        </span>
      </div>
    </div>
  );
};

/* =========================================================================
   ZONE B (RIGHT COLUMN): PRIMARY FEATURES 2X2 GRID
   ========================================================================= */

interface PrimaryFeaturesGridProps {
  claimableMissionsCount: number;
  onOpenScreen: (screen: string) => void;
  onGuardScreen: (screen: string) => void;
}

export const PrimaryFeaturesGrid: React.FC<PrimaryFeaturesGridProps> = ({
  claimableMissionsCount,
  onOpenScreen,
  onGuardScreen
}) => {
  return (
    <div className="grid grid-cols-2 [grid-template-rows:1fr_1fr] gap-0 h-full w-full select-none">
      {/* 1. Wallet */}
      <button
        data-zone="tile"
        data-slot="side"
        onClick={() => onGuardScreen('wallet')}
        className="group p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1.5 h-full min-h-0 min-w-0 w-full overflow-hidden cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden"
        aria-label="Open Wallet"
      >
        <div className="w-8 h-8 rounded-xl neu-inset text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200 shrink-0">
          <Wallet className="w-4 h-4" />
        </div>
        <span className="text-xs group-hover:text-[var(--accent)] transition-colors duration-150 leading-tight">Wallet</span>
      </button>

      {/* 2. Trading */}
      <button
        data-zone="tile"
        data-slot="side"
        onClick={() => onGuardScreen('trade')}
        className="group p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1.5 h-full min-h-0 min-w-0 w-full overflow-hidden cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden"
        aria-label="Open Trading Exchange"
      >
        <div className="w-8 h-8 rounded-xl neu-inset text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200 shrink-0">
          <TrendingUp className="w-4 h-4" />
        </div>
        <span className="text-xs group-hover:text-[var(--accent)] transition-colors duration-150 leading-tight">Trading</span>
      </button>

      {/* 3. Companies */}
      <button
        data-zone="tile"
        data-slot="dock"
        onClick={() => onOpenScreen('companies')}
        className="group p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1.5 h-full min-h-0 min-w-0 w-full overflow-hidden cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden"
        aria-label="View Verified Companies"
      >
        <div className="w-8 h-8 rounded-xl neu-inset text-teal-600 dark:text-teal-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200 shrink-0">
          <Building2 className="w-4 h-4" />
        </div>
        <span className="text-xs group-hover:text-[var(--accent)] transition-colors duration-150 leading-tight">Companies</span>
      </button>

      {/* 4. Missions */}
      <button
        data-zone="tile"
        data-slot="dock"
        onClick={() => onOpenScreen('missions')}
        className="group relative p-2 sm:p-2.5 rounded-2xl neu-btn text-[var(--ink)] font-extrabold text-xs flex flex-col items-center justify-center gap-1.5 h-full min-h-0 min-w-0 w-full overflow-hidden cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:scale-[0.95] focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:outline-hidden"
        aria-label="Open Missions and Quests"
      >
        <div className="w-8 h-8 rounded-xl neu-inset text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-200 shrink-0">
          <Target className="w-4 h-4" />
        </div>
        <span className="text-xs group-hover:text-[var(--accent)] transition-colors duration-150 leading-tight">Missions</span>
        {claimableMissionsCount > 0 && (
          <span className="absolute top-1.5 right-1.5 min-w-[17px] h-[17px] px-1 rounded-full bg-rose-600 text-white font-extrabold text-[9px] flex items-center justify-center shadow-xs animate-pulse ring-2 ring-white/50 dark:ring-black/50">
            {claimableMissionsCount}
          </span>
        )}
      </button>
    </div>
  );
};

/* =========================================================================
   ZONE C: BOTTOM QUICK NAVIGATION DOCK
   ========================================================================= */

interface BottomQuickDockProps {
  onOpenScreen: (screen: string) => void;
  onGuardScreen: (screen: string) => void;
}

export const BottomQuickDock: React.FC<BottomQuickDockProps> = ({
  onOpenScreen,
  onGuardScreen
}) => {
  return (
    <nav
      aria-label="Quick Navigation Dock"
      className="axis-landscape-dock w-full p-2 rounded-2xl neu-flat flex items-center justify-between gap-2 sm:gap-2.5 h-[85px] min-h-[85px] select-none"
    >
      {/* 1. Rewards */}
      <button
        onClick={() => onGuardScreen('store')}
        className="flex-1 p-2 rounded-xl neu-btn text-[var(--ink)] font-extrabold text-xs flex items-center justify-center gap-2 h-[60px] min-h-[60px] cursor-pointer hover:-translate-y-0.5 active:scale-95 transition-all focus-visible:ring-2 focus-visible:ring-emerald-500"
        aria-label="Rewards Store"
      >
        <div className="w-8 h-8 rounded-lg neu-inset text-orange-600 dark:text-orange-400 flex items-center justify-center shrink-0">
          <Ticket className="w-4 h-4" />
        </div>
        <span className="text-xs truncate">Rewards</span>
      </button>

      {/* 2. Contacts */}
      <button
        onClick={() => onOpenScreen('social')}
        className="flex-1 p-2 rounded-xl neu-btn text-[var(--ink)] font-extrabold text-xs flex items-center justify-center gap-2 h-[60px] min-h-[60px] cursor-pointer hover:-translate-y-0.5 active:scale-95 transition-all focus-visible:ring-2 focus-visible:ring-emerald-500"
        aria-label="Contacts and Social"
      >
        <div className="w-8 h-8 rounded-lg neu-inset text-cyan-600 dark:text-cyan-400 flex items-center justify-center shrink-0">
          <Users className="w-4 h-4" />
        </div>
        <span className="text-xs truncate">Contacts</span>
      </button>

      {/* 3. History */}
      <button
        onClick={() => onOpenScreen('history')}
        className="flex-1 p-2 rounded-xl neu-btn text-[var(--ink)] font-extrabold text-xs flex items-center justify-center gap-2 h-[60px] min-h-[60px] cursor-pointer hover:-translate-y-0.5 active:scale-95 transition-all focus-visible:ring-2 focus-visible:ring-emerald-500"
        aria-label="Scan & Transaction History"
      >
        <div className="w-8 h-8 rounded-lg neu-inset text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
          <Receipt className="w-4 h-4" />
        </div>
        <span className="text-xs truncate">History</span>
      </button>

      {/* 4. Settings */}
      <button
        onClick={() => onOpenScreen('settings')}
        className="flex-1 p-2 rounded-xl neu-btn text-[var(--ink)] font-extrabold text-xs flex items-center justify-center gap-2 h-[60px] min-h-[60px] cursor-pointer hover:-translate-y-0.5 active:scale-95 transition-all focus-visible:ring-2 focus-visible:ring-emerald-500"
        aria-label="System Settings & Atmospheres"
      >
        <div className="w-8 h-8 rounded-lg neu-inset text-zinc-600 dark:text-zinc-400 flex items-center justify-center shrink-0">
          <Settings className="w-4 h-4" />
        </div>
        <span className="text-xs truncate">Settings</span>
      </button>
    </nav>
  );
};
