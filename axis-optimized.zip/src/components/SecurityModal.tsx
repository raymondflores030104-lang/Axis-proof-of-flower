import React from 'react';
import { AxisState } from '../types';
import { ShieldCheck, Lock, Fingerprint, AlertTriangle, Key, Layers, Shield } from 'lucide-react';
import { TransactionRiskEngine } from '../blockchain/riskEngine';
import { OPERATIONAL_MODE_CONFIG } from '../blockchain/modeConfig';

export interface SecurityModalProps {
  state: AxisState;
  onOpenPinSetup?: () => void;
  onTogglePin?: (enable: boolean) => void;
  onUpdateSecurity?: (updater: (prev: NonNullable<AxisState['securitySettings']>) => NonNullable<AxisState['securitySettings']>) => void;
  onToggleCustodyMode?: (mode: 'SELF_CUSTODY' | 'AXIS_MANAGED') => void;
  onEmergencyKillSwitch?: () => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const SecurityModal: React.FC<SecurityModalProps> = ({
  state,
  onOpenPinSetup,
  onTogglePin,
  onUpdateSecurity,
  onToggleCustodyMode,
  onEmergencyKillSwitch,
  onToast
}) => {
  const hasPin = Boolean(state.pinHash && state.pinSalt);
  const currentCustody = state.custodyMode || 'SELF_CUSTODY';
  const opMode = state.operationalMode || 'PRODUCTION';

  const sec = state.securitySettings || {
    biometrics: false,
    requirePinForTrade: false,
    requirePinForTransfer: false,
    antiPhishingCode: 'AXIS-SAFE'
  };

  const handleToggle = (key: 'biometrics' | 'requirePinForTrade' | 'requirePinForTransfer') => {
    if (!onUpdateSecurity) return;
    onUpdateSecurity((prev) => {
      const updated = {
        ...prev,
        [key]: !prev[key]
      };
      onToast(
        `${key === 'biometrics' ? 'Biometrics' : key === 'requirePinForTrade' ? 'Trade PIN check' : 'Transfer PIN check'} ${
          updated[key] ? 'enabled' : 'disabled'
        }`,
        'good'
      );
      return updated;
    });
  };

  const handleEmergencyLockdown = () => {
    TransactionRiskEngine.triggerEmergencyHalt('Manual activation via User Security Console');
    if (onEmergencyKillSwitch) {
      onEmergencyKillSwitch();
    }
    onToast('CRITICAL: Emergency Circuit Breaker Activated! Financial queues frozen.', 'err');
  };

  return (
    <div className="space-y-4 select-none">
      {/* 1. Operational Mode Delineation Badge */}
      <div className="p-4 rounded-2xl neu-flat space-y-2 border border-emerald-500/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-500" />
            <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink)]">
              Network Status: FLRXCORE Secured
            </h4>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Active Consensus
          </span>
        </div>
        <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
          {OPERATIONAL_MODE_CONFIG.demoDisclaimer}
        </p>
      </div>

      {/* 2. Hybrid Custody Architecture Selection */}
      <div className="p-4 rounded-2xl neu-flat space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-600" />
            <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink)]">
              Wallet Custody Architecture
            </h4>
          </div>
          <div className="flex gap-1.5 p-1 rounded-xl neu-inset">
            <button
              onClick={() => onToggleCustodyMode && onToggleCustodyMode('SELF_CUSTODY')}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold cursor-pointer transition-all ${
                currentCustody === 'SELF_CUSTODY' ? 'neu-tab-active font-extrabold text-emerald-600' : 'text-[var(--ink2)]'
              }`}
            >
              Self-Custody
            </button>
            <button
              onClick={() => onToggleCustodyMode && onToggleCustodyMode('AXIS_MANAGED')}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold cursor-pointer transition-all ${
                currentCustody === 'AXIS_MANAGED' ? 'neu-tab-active font-extrabold text-teal-600' : 'text-[var(--ink2)]'
              }`}
            >
              AXIS-Managed
            </button>
          </div>
        </div>
        <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
          {currentCustody === 'SELF_CUSTODY'
            ? 'Self-Custody Mode: Keys are stored exclusively in your on-device StrongBox / Keystore. AXIS servers never possess unilateral access.'
            : 'AXIS-Managed Mode: Assets are protected in institutional segregated MPC/HSM custody with address whitelisting and 24h withdrawal cooldowns.'}
        </p>
      </div>

      {/* 3. Master PIN Protection (Salted PBKDF2) */}
      <div className="p-4 rounded-2xl neu-flat space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-600" />
            <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink)]">
              Master Device PIN Protection
            </h4>
          </div>
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${hasPin ? 'neu-tab-active' : 'neu-inset text-[var(--ink2)]'}`}>
            {hasPin ? 'Salted Hash Active' : 'Not Configured'}
          </span>
        </div>

        <p className="text-[11px] text-[var(--ink2)] leading-relaxed">
          Secures fiat withdrawals, large crypto transfers, and critical settings with a salted PBKDF2 cryptographic hash. Never stored in plaintext.
        </p>

        <div className="flex gap-2">
          <button
            onClick={() => onOpenPinSetup ? onOpenPinSetup() : onTogglePin ? onTogglePin(!hasPin) : null}
            className="flex-1 py-2.5 rounded-xl neu-btn font-extrabold text-xs cursor-pointer text-[var(--ink)] active:scale-98 transition-transform"
          >
            {hasPin ? 'Change Master PIN' : 'Enroll New Master PIN'}
          </button>
          {hasPin && onTogglePin && (
            <button
              onClick={() => onTogglePin(false)}
              className="py-2.5 px-3 rounded-xl neu-btn font-bold text-xs cursor-pointer text-rose-500 active:scale-98 transition-transform"
              title="Disable PIN"
            >
              Disable
            </button>
          )}
        </div>
      </div>

      {/* 4. Policy & Verification Checks */}
      <div className="p-4 rounded-2xl neu-flat space-y-3">
        <h4 className="font-extrabold text-xs uppercase tracking-wider text-[var(--ink2)]">
          Policy &amp; Verification Checks
        </h4>

        <div className="flex items-center justify-between">
          <span className="font-bold text-[var(--ink)]">Biometric Authentication (WebAuthn / Passkey)</span>
          <input
            type="checkbox"
            checked={Boolean(sec.biometrics)}
            onChange={() => handleToggle('biometrics')}
            className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
          />
        </div>

        <div className="flex items-center justify-between">
          <span className="font-bold text-[var(--ink)]">Require PIN for Market Trades</span>
          <input
            type="checkbox"
            checked={Boolean(sec.requirePinForTrade)}
            onChange={() => handleToggle('requirePinForTrade')}
            className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
          />
        </div>

        <div className="flex items-center justify-between">
          <span className="font-bold text-[var(--ink)]">Require PIN for External Transfers</span>
          <input
            type="checkbox"
            checked={Boolean(sec.requirePinForTransfer)}
            onChange={() => handleToggle('requirePinForTransfer')}
            className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
          />
        </div>

        {sec.antiPhishingCode && (
          <div className="pt-2 border-t border-[var(--c-border)] flex items-center justify-between text-[11px]">
            <span className="text-[var(--ink2)]">Anti-Phishing Anti-Spoof Code:</span>
            <span className="font-mono font-bold text-emerald-600 neu-inset-sm px-2 py-0.5 rounded">
              {sec.antiPhishingCode}
            </span>
          </div>
        )}
      </div>

      {/* 5. Emergency Protocol Lockdown (Circuit Breaker) */}
      <div className="p-4 rounded-2xl neu-flat space-y-2 border border-rose-500/30">
        <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <h4 className="font-extrabold text-xs uppercase tracking-wider">
            Emergency Protocol Lockdown
          </h4>
        </div>
        <p className="text-[11px] text-[var(--ink2)]">
          Instantly trips the transaction risk circuit breaker, freezes pending withdrawal queues, and locks financial execution.
        </p>
        <button
          onClick={handleEmergencyLockdown}
          className="w-full py-2.5 rounded-xl neu-btn text-rose-600 dark:text-rose-400 font-extrabold text-xs cursor-pointer active:scale-98 transition-transform"
        >
          Activate Emergency Lockdown
        </button>
      </div>

      {/* 6. Cryptographic Safeguards Notice */}
      <div className="p-4 rounded-2xl neu-flat space-y-2 text-xs">
        <div className="flex items-center gap-2 text-emerald-600">
          <ShieldCheck className="w-4 h-4" />
          <b className="text-[var(--ink)]">FIPS 180-4 &amp; RFC 8032 Controls Active</b>
        </div>
        <p className="text-[11px] text-[var(--ink2)]">
          Operating under non-bypassable Ed25519 digital signatures, Merkle-root transaction verification, and dual-custody segregation.
        </p>
      </div>
    </div>
  );
};
