import React, { useState } from 'react';
import { AxisState, ContactItem } from '../types';
import { Users, UserPlus, Send, Trash2 } from 'lucide-react';

interface SocialModalProps {
  state: AxisState;
  onRedeemReferral: (code: string) => void;
  onAddContact: (c: ContactItem) => void;
  onRemoveContact: (index: number) => void;
  onSendToContact: (c: ContactItem) => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const SocialModal: React.FC<SocialModalProps> = ({
  state,
  onAddContact,
  onRemoveContact,
  onSendToContact,
  onToast
}) => {
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !address) {
      onToast('Enter a name and address', 'err');
      return;
    }
    onAddContact({ name, address, since: Date.now() });
    setName('');
    setAddress('');
  };

  return (
    <div className="space-y-4 select-none">
      {/* Add New Contact Form */}
      <form onSubmit={handleAdd} className="p-4 rounded-2xl neu-flat space-y-3">
        <h4 className="text-xs font-extrabold uppercase tracking-wider text-[var(--ink2)] flex items-center gap-1.5">
          <UserPlus className="w-4 h-4 text-emerald-600" />
          <span>Save P2P Mining Contact</span>
        </h4>

        <div className="space-y-2">
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Contact Name (e.g., Alice)"
            className="w-full px-3.5 py-2.5 rounded-xl neu-input text-xs text-[var(--ink)]"
          />
          <input
            type="text"
            required
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Hex Wallet Address (0x...)"
            className="w-full px-3.5 py-2.5 rounded-xl neu-input text-xs font-mono text-[var(--ink)]"
          />
        </div>

        <button
          type="submit"
          className="w-full py-2.5 rounded-xl neu-btn-accent font-extrabold text-xs cursor-pointer shadow-xs"
        >
          Save Contact
        </button>
      </form>

      {/* Contacts List */}
      <div className="space-y-2">
        <h4 className="text-xs font-extrabold uppercase tracking-wider text-[var(--ink2)]">
          Saved Mining Buddies ({state.friends?.length || 0})
        </h4>

        {(!state.friends || state.friends.length === 0) ? (
          <p className="text-xs text-[var(--ink2)] text-center py-6">
            No contacts saved yet. Add your friends to send instant FLRX tips.
          </p>
        ) : (
          state.friends.map((f, idx) => (
            <div key={idx} className="p-3 rounded-2xl neu-flat flex items-center justify-between gap-3">
              <div>
                <b className="text-xs font-bold block text-[var(--ink)]">{f.name}</b>
                <span className="text-[10px] text-[var(--ink2)] font-mono block">
                  {f.address.slice(0, 16)}...
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => onSendToContact(f)}
                  className="p-2 rounded-xl neu-tab-item text-emerald-600 hover:text-emerald-700 cursor-pointer"
                  title="Send FLRX"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => onRemoveContact(idx)}
                  className="p-2 rounded-xl neu-btn text-rose-500 hover:text-rose-600 cursor-pointer"
                  title="Delete Contact"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
