import React from 'react';
import { AxisState } from '../types';
import { STORE_ITEMS, Company } from '../constants';
import { fmtF } from '../utils';
import { Ticket, ShoppingBag, Sparkles } from 'lucide-react';

interface StoreModalProps {
  state: AxisState;
  sponsoredCompany: Company;
  onRedeem: (item: typeof STORE_ITEMS[0]) => void;
  onToast: (msg: string, type?: 'good' | 'err') => void;
}

export const StoreModal: React.FC<StoreModalProps> = ({
  state,
  onRedeem,
  onToast
}) => {
  return (
    <div className="space-y-4 select-none">
      <div className="p-3.5 rounded-2xl neu-flat flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold uppercase text-[var(--ink2)] block">
            Redeemable Balance
          </span>
          <b className="text-lg font-black font-mono text-emerald-600 dark:text-emerald-400">
            {fmtF(state.flrx)} FLWRX
          </b>
        </div>
        <div className="text-right">
          <span className="text-[10px] font-bold text-[var(--ink2)] block">
            Active Vouchers:
          </span>
          <b className="text-sm font-mono font-bold text-[var(--ink)]">
            {state.vouchers?.length || 0}
          </b>
        </div>
      </div>

      {/* Teraxiom Treasury Reserve Backing */}
      <div className="p-3 rounded-2xl neu-inset-sm flex items-center justify-between text-xs">
        <div>
          <span className="text-[10px] font-bold text-[var(--ink2)] block">
            Teraxiom Corporate Treasury Reserve
          </span>
          <b className="font-mono font-extrabold text-emerald-600 dark:text-emerald-400">
            {fmtF(state.flwrxReservePool || 1000000)} FLWRX Backed
          </b>
        </div>
        <div className="text-right">
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-bold text-[10px] font-mono">
            ✓ 100% Collateralized
          </span>
        </div>
      </div>

      <div className="space-y-2">
        <h4 className="text-xs font-extrabold uppercase tracking-wider text-[var(--ink2)]">
          Real-World Rewards Catalog
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 landscape:grid-cols-2 gap-2.5">
          {STORE_ITEMS.map((item) => {
            const canAfford = state.flrx >= item.cost;

            return (
              <div key={item.id} className="p-3 rounded-2xl neu-flat flex flex-col justify-between gap-2.5">
                <div className="flex items-start gap-2.5">
                  <div className="w-10 h-10 rounded-xl neu-inset flex items-center justify-center text-xl shrink-0">
                    {item.icon}
                  </div>
                  <div>
                    <b className="text-xs font-bold block text-[var(--ink)]">{item.name}</b>
                    <span className="text-[10px] text-[var(--ink2)] font-mono">
                      Partner: {item.partner}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-[var(--neu-border-dark)]">
                  <span className="text-xs font-black font-mono text-emerald-600 dark:text-emerald-400">
                    {item.cost} FLWRX
                  </span>
                  <button
                    onClick={() => {
                      if (!canAfford) {
                        onToast('Insufficient FLWRX balance', 'err');
                        return;
                      }
                      onRedeem(item);
                    }}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs cursor-pointer transition ${
                      canAfford ? 'neu-tab-active' : 'neu-tab-item opacity-50 cursor-not-allowed'
                    }`}
                  >
                    Redeem
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
