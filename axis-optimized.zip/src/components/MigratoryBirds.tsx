import React, { useEffect, useRef, memo } from 'react';
import { WeatherMode } from './AmbientBackground';

interface MigratoryBirdsProps {
  weatherMode?: WeatherMode;
  speed?: 'slow' | 'medium' | 'fast';
  lowPowerMode?: boolean;
}

interface BirdIndividual {
  relX: number; // offset relative to flock leader
  relY: number;
  phaseOffset: number;
  scale: number;
}

interface FlightTraverse {
  active: boolean;
  startX: number;
  startY: number;
  currentX: number;
  currentY: number;
  targetX: number;
  targetY: number;
  speed: number;
  direction: 1 | -1; // 1 = flying right, -1 = flying left
  species: 'geese' | 'heron' | 'hawk' | 'swallow' | 'petrel';
  formation: 'v' | 'single' | 'pair' | 'cluster';
  birds: BirdIndividual[];
  wingFrequency: number;
  glideRatio: number;
  color: string;
  altitudeSin: number;
}

export const MigratoryBirds: React.FC<MigratoryBirdsProps> = memo(({
  weatherMode = 'leaves',
  speed = 'medium',
  lowPowerMode = false
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const stateRef = useRef({
    weatherMode,
    speed,
    lowPower: lowPowerMode,
    traverse: null as FlightTraverse | null,
    nextSpawnTime: 0
  });

  useEffect(() => {
    stateRef.current.weatherMode = weatherMode;
    stateRef.current.speed = speed;
    stateRef.current.lowPower = lowPowerMode;

    // Reset current traversal on environment shift to spawn native species
    stateRef.current.traverse = null;
    stateRef.current.nextSpawnTime = performance.now() + 800;
  }, [weatherMode, speed, lowPowerMode]);

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;

    const ctx = cv.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animId: number | null = null;
    let isDestroyed = false;
    let lastTime = performance.now();

    function resize() {
      if (!cv) return;
      const rect = cv.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, stateRef.current.lowPower ? 1.0 : 1.5);
      const w = Math.max(32, Math.floor((rect.width || window.innerWidth) * dpr));
      const h = Math.max(32, Math.floor((rect.height || window.innerHeight) * dpr));
      if (cv.width !== w || cv.height !== h) {
        cv.width = w;
        cv.height = h;
      }
    }

    function spawnTraverse(now: number, width: number, height: number): FlightTraverse | null {
      const mode = stateRef.current.weatherMode;
      if (mode === 'blackhole') return null;

      // Choose environment-specific species and flight formation
      // Autumn: Classic Canada Geese migrating in majestic V-formation
      // Lake / River (raining): Great Blue Heron / Sandhill Crane in slow, graceful solitary or pair flight
      // Canopy (leaves): Woodland Hawks & Swifts darting across canopy openings
      // Sakura (spring): Agile Barn Swallows swooping with forked tails
      // Storming (ocean): Wandering Albatross & Storm Petrels banking dynamically
      const dir: 1 | -1 = Math.random() > 0.5 ? 1 : -1;
      const startX = dir === 1 ? -160 : width + 160;
      const targetX = dir === 1 ? width + 220 : -220;

      let species: FlightTraverse['species'] = 'hawk';
      let formation: FlightTraverse['formation'] = 'single';
      let wingFrequency = 4.0;
      let glideRatio = 0.4;
      let color = 'rgba(28, 38, 32, 0.88)';
      let numBirds = 1;

      // Vertical altitude range (mostly in upper 12% - 45% of the sky)
      const startY = height * (0.12 + Math.random() * 0.32);
      const targetY = startY + (Math.random() - 0.5) * height * 0.22;

      if (mode === 'autumn') {
        species = 'geese';
        formation = 'v';
        numBirds = stateRef.current.lowPower ? 5 : 7;
        wingFrequency = 2.6; // Measured, majestic wingbeat cadence
        glideRatio = 0.25;
        color = 'rgba(38, 22, 12, 0.92)'; // Autumn umber-charcoal silhouette
      } else if (mode === 'raining') {
        species = 'heron';
        formation = Math.random() > 0.4 ? 'single' : 'pair';
        numBirds = formation === 'pair' ? 2 : 1;
        wingFrequency = 1.8; // Very slow, majestic wings
        glideRatio = 0.55;
        color = 'rgba(24, 34, 42, 0.86)'; // Misty slate silhouette
      } else if (mode === 'leaves') {
        species = 'hawk';
        formation = Math.random() > 0.6 ? 'pair' : 'single';
        numBirds = formation === 'pair' ? 2 : 1;
        wingFrequency = 3.6;
        glideRatio = 0.65; // High soaring glide ratio
        color = 'rgba(20, 32, 24, 0.9)'; // Deep forest canopy silhouette
      } else if (mode === 'sakura') {
        species = 'swallow';
        formation = 'cluster';
        numBirds = stateRef.current.lowPower ? 2 : 4;
        wingFrequency = 6.8; // Rapid, acrobatic flutter
        glideRatio = 0.35;
        color = 'rgba(46, 22, 38, 0.88)'; // Rose-tinted spring charcoal
      } else {
        // storming ocean
        species = 'petrel';
        formation = 'single';
        numBirds = 1;
        wingFrequency = 2.2;
        glideRatio = 0.75;
        color = 'rgba(20, 28, 38, 0.85)';
      }

      // Generate formation offset geometry
      const birds: BirdIndividual[] = [];
      if (formation === 'v') {
        // Classic symmetrical V-formation
        birds.push({ relX: 0, relY: 0, phaseOffset: 0, scale: 1.05 });
        for (let i = 1; i <= Math.floor(numBirds / 2); i++) {
          const spacingX = 42 * i;
          const spacingY = 26 * i;
          // Left wing of the V
          birds.push({
            relX: -dir * spacingX,
            relY: -spacingY + (Math.random() - 0.5) * 6,
            phaseOffset: i * 0.35,
            scale: 0.98 - i * 0.04
          });
          // Right wing of the V
          birds.push({
            relX: -dir * spacingX,
            relY: spacingY + (Math.random() - 0.5) * 6,
            phaseOffset: i * 0.35 + 0.15,
            scale: 0.98 - i * 0.04
          });
        }
      } else if (formation === 'pair') {
        birds.push({ relX: 0, relY: 0, phaseOffset: 0, scale: 1.0 });
        birds.push({
          relX: -dir * (35 + Math.random() * 20),
          relY: 18 + (Math.random() - 0.5) * 16,
          phaseOffset: 0.45,
          scale: 0.92
        });
      } else if (formation === 'cluster') {
        // Loose agile flock
        for (let i = 0; i < numBirds; i++) {
          birds.push({
            relX: -dir * i * (22 + Math.random() * 18),
            relY: (Math.random() - 0.5) * 45,
            phaseOffset: i * 0.5,
            scale: 0.85 + Math.random() * 0.25
          });
        }
      } else {
        // Solitary
        birds.push({ relX: 0, relY: 0, phaseOffset: 0, scale: 1.1 });
      }

      const spdFactor = stateRef.current.speed === 'fast' ? 1.35 : stateRef.current.speed === 'slow' ? 0.75 : 1.0;
      const baseSpeed = (species === 'swallow' ? 95 : species === 'geese' ? 70 : 60) * spdFactor;

      return {
        active: true,
        startX,
        startY,
        currentX: startX,
        currentY: startY,
        targetX,
        targetY,
        speed: baseSpeed,
        direction: dir,
        species,
        formation,
        birds,
        wingFrequency,
        glideRatio,
        color,
        altitudeSin: Math.random() * Math.PI * 2
      };
    }

    // Anatomical species silhouette rendering
    function drawBird(
      c: CanvasRenderingContext2D,
      x: number,
      y: number,
      species: FlightTraverse['species'],
      direction: 1 | -1,
      flapCycle: number,
      scale: number,
      color: string
    ) {
      c.save();
      c.translate(x, y);
      c.scale(direction * scale, scale);

      // Flap position: -1 (wings fully raised) to +1 (wings fully down)
      const flap = Math.sin(flapCycle);
      const wingTipY = flap * 12;

      c.fillStyle = color;
      c.beginPath();

      if (species === 'geese') {
        // Canada Geese: Distinct long outstretched neck, wedge tail, broad swept wings
        // Head & outstretched neck
        c.moveTo(18, -1);
        c.lineTo(8, -1.5);
        // Body
        c.lineTo(-10, 0);
        // Tail wedge
        c.lineTo(-17, 0);
        c.lineTo(-10, 2);
        // Underbody
        c.lineTo(6, 2);
        c.closePath();
        c.fill();

        // Upper & lower wings with joint articulation
        c.beginPath();
        // Near wing
        c.moveTo(2, -0.5);
        c.quadraticCurveTo(-2, -6 + wingTipY * 0.5, -6, -18 + wingTipY);
        c.quadraticCurveTo(-2, -10 + wingTipY * 0.6, 2, 0);
        // Far wing (subtle offset)
        c.moveTo(0, 0);
        c.quadraticCurveTo(-4, 6 - wingTipY * 0.5, -8, 16 - wingTipY);
        c.quadraticCurveTo(-3, 8 - wingTipY * 0.6, 0, 1.5);
        c.closePath();
        c.fill();
      } else if (species === 'heron') {
        // Great Blue Heron: Curved 'S' neck, broad arched wings, long trailing legs
        // Head with long sharp bill
        c.moveTo(20, -1);
        c.lineTo(13, -2);
        // Arched neck folded in flight
        c.quadraticCurveTo(8, -5, 4, -1);
        // Body
        c.lineTo(-8, 0);
        // Long trailing legs
        c.lineTo(-24, 2.5);
        c.lineTo(-8, 2);
        c.closePath();
        c.fill();

        // Broad arched wings
        c.beginPath();
        c.moveTo(0, -1);
        c.quadraticCurveTo(-4, -10 + wingTipY * 0.6, -10, -22 + wingTipY * 0.9);
        c.quadraticCurveTo(-2, -12 + wingTipY * 0.5, 3, 0);
        c.closePath();
        c.fill();
      } else if (species === 'swallow') {
        // Barn Swallow: Deeply forked tail, streamlined agile torpedo body
        // Head
        c.moveTo(12, 0);
        c.lineTo(5, -1.5);
        c.lineTo(-6, -1);
        // Iconic deeply forked tail
        c.lineTo(-18, -4);
        c.lineTo(-10, 0);
        c.lineTo(-18, 4);
        c.lineTo(-6, 1);
        c.closePath();
        c.fill();

        // Pointed scythe wings
        c.beginPath();
        c.moveTo(2, -0.5);
        c.quadraticCurveTo(0, -8 + wingTipY * 0.7, -4, -16 + wingTipY);
        c.quadraticCurveTo(-1, -6 + wingTipY * 0.4, 3, 0.5);
        c.closePath();
        c.fill();
      } else {
        // Hawk / Petrel: Classic soaring raptor silhouette
        c.moveTo(14, 0);
        c.lineTo(4, -2);
        c.lineTo(-8, -1.5);
        c.lineTo(-14, 0);
        c.lineTo(-8, 1.5);
        c.lineTo(4, 2);
        c.closePath();
        c.fill();

        // Long cambered wings
        c.beginPath();
        c.moveTo(1, -0.5);
        c.quadraticCurveTo(-3, -8 + wingTipY * 0.6, -8, -20 + wingTipY);
        c.quadraticCurveTo(-1, -9 + wingTipY * 0.5, 4, 0);
        c.closePath();
        c.fill();
      }

      c.restore();
    }

    function frame(now: number) {
      if (isDestroyed) return;
      animId = requestAnimationFrame(frame);

      const dt = Math.min(Math.max((now - lastTime) / 1000, 0.001), 0.1);
      lastTime = now;

      if (document.hidden || stateRef.current.weatherMode === 'blackhole') {
        ctx!.clearRect(0, 0, cv!.width, cv!.height);
        return;
      }

      resize();
      const W = cv!.width;
      const H = cv!.height;

      ctx!.clearRect(0, 0, W, H);

      let trav = stateRef.current.traverse;

      // Check if time to spawn new traverse
      if (!trav || !trav.active) {
        if (now >= stateRef.current.nextSpawnTime) {
          trav = spawnTraverse(now, W, H);
          stateRef.current.traverse = trav;
          // Next traversal occurs 7 to 15 seconds after this one starts
          stateRef.current.nextSpawnTime = now + (7000 + Math.random() * 8000);
        }
      }

      if (trav && trav.active) {
        // Progress traverse along horizontal direction
        trav.currentX += trav.direction * trav.speed * dt;
        trav.altitudeSin += dt * 1.2;

        // Subtle undulating altitude path
        const totalDistX = Math.abs(trav.targetX - trav.startX);
        const traveledDistX = Math.abs(trav.currentX - trav.startX);
        const progress = Math.min(Math.max(traveledDistX / Math.max(totalDistX, 1), 0), 1);
        const baseCurY = trav.startY + (trav.targetY - trav.startY) * progress;
        trav.currentY = baseCurY + Math.sin(trav.altitudeSin) * (H * 0.025);

        // Check completion bounds
        const isPastTarget =
          (trav.direction === 1 && trav.currentX > trav.targetX) ||
          (trav.direction === -1 && trav.currentX < trav.targetX);

        if (isPastTarget) {
          trav.active = false;
          stateRef.current.traverse = null;
        } else {
          // Render each individual bird in the formation
          const flapBase = now * 0.001 * trav.wingFrequency * Math.PI * 2;

          for (let i = 0; i < trav.birds.length; i++) {
            const b = trav.birds[i];
            const birdX = trav.currentX + b.relX;
            const birdY = trav.currentY + b.relY;

            // Only draw if within reasonable bounds
            if (birdX > -100 && birdX < W + 100) {
              const flapPhase = flapBase + b.phaseOffset;
              drawBird(
                ctx!,
                birdX,
                birdY,
                trav.species,
                trav.direction,
                flapPhase,
                b.scale,
                trav.color
              );
            }
          }
        }
      }
    }

    resize();
    stateRef.current.nextSpawnTime = performance.now() + 1200; // First traversal shortly after mount
    animId = requestAnimationFrame(frame);

    const handleResize = () => resize();
    window.addEventListener('resize', handleResize, { passive: true });

    return () => {
      isDestroyed = true;
      if (animId !== null) cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  if (weatherMode === 'blackhole') {
    return null;
  }

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full block pointer-events-none select-none z-1"
      style={{
        width: '100%',
        height: '100%'
      }}
      aria-hidden="true"
    />
  );
});
