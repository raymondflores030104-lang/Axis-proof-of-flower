import React from 'react';
import { ShieldCheck } from 'lucide-react';

export const PrivacyPolicyModal: React.FC = () => {
  return (
    <div className="space-y-3 text-xs leading-relaxed text-[var(--ink)] select-none max-h-[60vh] overflow-y-auto pr-1">
      <div className="flex items-center gap-2 text-emerald-600">
        <ShieldCheck className="w-5 h-5" />
        <h4 className="font-extrabold text-sm text-[var(--ink)]">Privacy &amp; Data Security</h4>
      </div>
      <p>
        Axis is engineered with zero-knowledge telemetry principles. When scanning retail product packaging:
      </p>
      <ul className="list-disc pl-5 space-y-1 text-[var(--ink2)]">
        <li>Video feeds are processed strictly in local browser RAM using client-side WebAssembly computer vision.</li>
        <li>No raw image files or camera video frames are uploaded to external servers.</li>
        <li>Only authenticated barcode hashes and timestamp nonces are transmitted to verify campaign validation pools.</li>
      </ul>
      <p className="text-[var(--ink2)]">
        Users retain full autonomy to clear local cache data or export their activity ledger at any time.
      </p>
    </div>
  );
};
