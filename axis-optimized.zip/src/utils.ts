import { CURS } from './constants';

export const r2 = (n: number) => Math.round(n * 100) / 100;
export const r4 = (n: number) => Math.round(n * 10000) / 10000;
export const r6 = (n: number) => Math.round(n * 1000000) / 1000000;

export const rnd = (len = 8) => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let out = '';
  for (let i = 0; i < len; i++) {
    out += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return out;
};

export const curInfo = (c = 'PHP'): [string, number, string] => {
  return CURS[c] || CURS['PHP'];
};

/**
 * Converts a PHP value to the specified target currency with formatting
 * Formula: (phpVal / 58.5) * rate(targetCur)
 */
export const formatFiat = (phpVal: number, cur = 'PHP'): string => {
  const [sym, rate] = curInfo(cur);
  const phpRate = CURS['PHP'][1]; // 58.5
  const converted = cur === 'PHP' ? phpVal : (phpVal / phpRate) * rate;
  const digits = cur === 'JPY' || cur === 'KRW' ? 0 : 2;
  return `${sym}${converted.toLocaleString(undefined, { minimumFractionDigits: digits, maximumFractionDigits: digits })}`;
};

/**
 * Backward compatibility alias for formatFiat
 */
export const peso = (val: number, cur = 'PHP') => {
  return formatFiat(val, cur);
};

/**
 * Calculates and formats the fiat equivalent of an amount of FLWRX in the active currency
 */
export const flwrxEquivalent = (flwrxAmount: number, usdPrice: number, cur = 'PHP'): string => {
  const [sym, rate] = curInfo(cur);
  const converted = flwrxAmount * usdPrice * rate;
  const digits = cur === 'JPY' || cur === 'KRW' ? 0 : 2;
  return `${sym}${converted.toLocaleString(undefined, { minimumFractionDigits: digits, maximumFractionDigits: digits })}`;
};

/**
 * Returns formatted unit price of FLWRX in target currency
 */
export const flwrxUnitPrice = (usdPrice: number, cur = 'PHP'): string => {
  const [sym, rate] = curInfo(cur);
  const converted = usdPrice * rate;
  const digits = cur === 'USD' ? 4 : cur === 'JPY' || cur === 'KRW' ? 2 : 2;
  return `${sym}${converted.toFixed(digits)}`;
};

export const fmtF = (val: number) => {
  if (val && val < 0.001) {
    return val.toFixed(8);
  }
  return (val || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 8 });
};

export const dt = (ts: number) => {
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
};

export const dk = (ts?: number) => {
  const d = ts ? new Date(ts) : new Date();
  return d.toISOString().slice(0, 10);
};

export const weekKey = (ts?: number) => {
  const d = ts ? new Date(ts) : new Date();
  const year = d.getFullYear();
  const onejan = new Date(year, 0, 1);
  const week = Math.ceil(((d.getTime() - onejan.getTime()) / 86400000 + onejan.getDay() + 1) / 7);
  return `${year}-W${String(week).padStart(2, '0')}`;
};

export const hashStr = (s: string): number => {
  let hash = 0;
  for (let i = 0; i < s.length; i++) {
    hash = (hash << 5) - hash + s.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
};

export const copyText = async (txt: string, cb?: () => void) => {
  try {
    if (navigator?.clipboard?.writeText) {
      await navigator.clipboard.writeText(txt);
      if (cb) cb();
      return true;
    }
  } catch {
    // fallback
  }
  if (cb) cb();
  return false;
};

export const triggerFeedback = (type: any = 'click', subtype?: any, fxSettings?: any) => {
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    if (type === 'success' || subtype === 'success') navigator.vibrate([40, 30, 80]);
    else if (type === 'error' || subtype === 'error') navigator.vibrate([100, 50, 100]);
    else navigator.vibrate(25);
  }
};

export const soundEffects = {
  click: (vol = 0.5) => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      gain.gain.setValueAtTime(vol * 0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.05);
    } catch {
      // audio disabled
    }
  },
  success: (vol = 0.5) => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const now = ctx.currentTime;
      [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(freq, now + idx * 0.06);
        gain.gain.setValueAtTime(vol * 0.12, now + idx * 0.06);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.15);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.06);
        osc.stop(now + idx * 0.06 + 0.15);
      });
    } catch {
      // audio disabled
    }
  }
};
