export interface ScanResultDetail {
  code: string;
  isFirstEver: boolean;
  isDailyCapReached: boolean;
  rewardFlrx: number;
  rewardPhp: number;
  companyName: string;
  productName: string;
  category: string;
  bonusMultiplier: number;
  streakBonus: number;
  passkeyHash?: string;
  tier?: number;
  digits?: number;
  nodesVerified?: number;
  nodesTotal?: number;
  consensusPercentage?: number;
  wasteReducedGrams?: number;
  consensusMechanism?: string;
  flwrxAmount?: number;
}

export interface TradeOrder {
  id: string;
  type: 'market' | 'limit' | 'stop';
  side: 'buy' | 'sell';
  amt: number;
  price: number;
  reserved: number;
  created: number;
  status: 'open' | 'filled' | 'cancelled';
  done?: number;
}

export interface StakePosition {
  id: string;
  amount: number;
  start: number;
  lockDays: number;
  d?: number;
  apy: number;
  claimed: number;
  lastClaim: number;
}

export interface PriceAlert {
  id: string;
  dir: 'above' | 'below';
  price: number;
  created: number;
  hit: number;
}

export interface PriceActionItem {
  ts: number;
  type: 'ath' | 'alert' | 'order';
  msg: string;
}

export interface TransactionItem {
  id: string;
  ts: number;
  type: 'scan' | 'reward' | 'deposit' | 'withdraw' | 'trade' | 'send' | 'store';
  label: string;
  php: number;
  flrx: number;
}

export interface ScanHistoryItem {
  id: string;
  ts: number;
  code: string;
  company: string;
  product: string;
  reward: number;
  first: number;
  lv: number;
  sp: number;
  blockIndex?: string;
  nodesConfirmed?: number;
  phpReward?: number;
}

export interface ContactItem {
  name: string;
  address: string;
  phone?: string;
  since: number;
}

export interface VoucherItem {
  id: string;
  name: string;
  code: string;
  ts: number;
}

export interface ReceiptItem {
  day: string;
  store: string;
  amt: number;
  ts: number;
  rw: number;
}

export interface GoalItem {
  id: string;
  type: 'earn' | 'scans' | 'streak';
  target: number;
  base: number;
  wk: string;
  claimed: number;
}

export interface Candle {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
}

export interface AxisState {
  accountId: string;
  address: string;
  php: number;
  flrx: number;
  staked: number;
  stakeAcc: number;
  stakeLast: number;
  stakedEver: boolean;
  avgCost: number;
  realized: number;
  price: number;
  xp: number;
  totalScans: number;
  totalEarned: number;
  scanStreak: number;
  lastScanDay: string | null;
  lastScanTs: number;
  day: {
    key: string;
    scans: number;
    receipts: number;
    missions: string[];
  };
  week: {
    key: string;
    scans: number;
    earned: number;
    byCompany: Record<string, number>;
    missions: string[];
  };
  seen: Record<string, number>;
  everCompanies: Record<string, number>;
  pool: Record<string, { mined: number; total: number }>;
  history: ScanHistoryItem[];
  tx: TransactionItem[];
  trades: Array<{ ts: number; side: 'buy' | 'sell'; amt: number; price: number; php: number }>;
  queue: Array<{ code: string; ts: number }>;
  vouchers: VoucherItem[];
  receipts: ReceiptItem[];
  friends: ContactItem[];
  tickets: Array<{ ts: number; m: string }>;
  claim: {
    streak: number;
    last: string | null;
    total: number;
  };
  ach: Record<string, number>;
  referral: {
    code: string;
    redeemed: boolean;
    count?: number;
    bountyClaimed?: boolean;
    totalEarnedUsd?: number;
  };
  auto: {
    on: boolean;
    today: number;
    dayKey: string;
    acc: number;
  };
  bot: {
    on: boolean;
    amount: number;
    interval: number;
    max: number;
    spent: number;
    last: number;
    count: number;
  };
  settings: {
    lang: 'en' | 'fil';
    currency: string;
    theme: 'auto' | 'manual';
    tone: number;
    fallingLeaves?: boolean;
    fallingLeavesSpeed?: 'slow' | 'medium' | 'fast';
    weatherMode?: 'leaves' | 'autumn' | 'sakura' | 'raining' | 'storming' | 'blackhole';
    relativitySlide?: number;
    autolock: 'now' | '1m' | '5m' | 'never';
    fx: {
      sound: boolean;
      vol: number;
      vib: boolean;
      snd: {
        click: boolean;
        scan: boolean;
        scanning: boolean;
        alert: boolean;
      };
      vbr: {
        click: boolean;
        scan: boolean;
        scanning: boolean;
        alert: boolean;
      };
    };
    notif: {
      all: boolean;
      scan: boolean;
      reward: boolean;
      market: boolean;
      orders: boolean;
      promo: boolean;
      device: boolean;
    };
    apps: {
      gcash: boolean;
      maya: boolean;
      camera: boolean;
    };
  };
  securitySettings?: {
    biometrics: boolean;
    requirePinForTrade: boolean;
    requirePinForTransfer: boolean;
    antiPhishingCode?: string;
  };
  profile: {
    name: string;
    email: string;
    avatar: string;
    kyc: string;
    axisUserId?: string;
  };
  axisUserId?: string;
  goals: GoalItem[];
  spin: {
    ready: number;
    history: Array<{ ts: number; prize: number }>;
  };
  pinHash: string | null;
  pinSalt?: string | null;
  pinLockedUntil?: number | null;
  failedPinAttempts?: number;
  custodyMode?: 'SELF_CUSTODY' | 'AXIS_MANAGED';
  operationalMode?: 'PRODUCTION' | 'FLRXCORE';
  whitelistedAddresses?: Array<{ address: string; label: string; network: string; status: string; addedAt: number }>;
  bridgeRecords?: Array<{ id: string; direction: string; amount: number; state: string; ts: number }>;
  onboarded: boolean;
  firstBonusUsed: boolean;
  ath: number;
  athTs: number;
  lastAthEvt: number;
  pa: PriceActionItem[];
  alerts: PriceAlert[];
  orders: TradeOrder[];
  stakes: StakePosition[];
  identityAnchor?: {
    axisUserId: string;
    axisPublicKey: string;
    axisPrivateKeyHash: string;
    deviceFingerprint: string;
    registeredAt: number;
    protocolVersion: string;
    identityAnchorSignature: string;
  };
  totalWasteReducedGrams?: number;
  flwrxReservePool?: number;
  flwrxCirculatingPool?: number;
  companyReserveWithdrawalCapPercent?: number;
  governanceReserveLocked?: boolean;
  pendingScans?: Array<{
    code: string;
    timestamp: number;
    company: string;
    product: string;
    flrxReward: number;
    phpValue?: number;
    tier?: number;
    digits?: number;
    nodesVerified?: number;
    nodesTotal?: number;
    consensusMechanism?: string;
    wasteReducedGrams?: number;
    verified: boolean;
  }>;
  lowPowerMode?: boolean;
}
