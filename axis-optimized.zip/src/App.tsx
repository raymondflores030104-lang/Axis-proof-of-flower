import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AxisState, Candle, ScanResultDetail, ScanHistoryItem } from './types';
import {
  COMPANIES,
  DEFAULT_STATE,
  FX,
  STORAGE_KEY,
  CANDLES_KEY,
  DAILY_CAP,
  STAKING_TIERS,
  STORE_ITEMS
} from './constants';
import { r2, r4, r6, rnd, fmtF } from './utils';

import { AmbientBackground } from './components/AmbientBackground';
import { Header } from './components/Header';
import { BalanceCard } from './components/BalanceCard';
import { PostScanHud } from './components/PostScanHud';
import {
  TilesGrid,
  NexusScanHeroCard,
  PrimaryFeaturesGrid,
  BottomQuickDock
} from './components/TilesGrid';
import { LoadingScreen } from './components/LoadingScreen';
import { Version10Auth } from './components/Version10Auth';
import { LiquidGlassFilter } from './components/LiquidGlassFilter';
import { useAxisLayout } from './hooks/useAxisLayout';

// Modals
import { ScannerModal } from './components/ScannerModal';
import { TradingModal } from './components/TradingModal';
import { WalletModal } from './components/WalletModal';
import { CompaniesModal } from './components/CompaniesModal';
import { StoreModal } from './components/StoreModal';
import { DailyModal } from './components/DailyModal';
import { MissionsModal } from './components/MissionsModal';
import { AchievementsModal } from './components/AchievementsModal';
import { StakingModal } from './components/StakingModal';
import { SocialModal } from './components/SocialModal';
import { HistoryModal } from './components/HistoryModal';
import { AdvancedModal } from './components/AdvancedModal';
import { SettingsModal } from './components/SettingsModal';
import { ProfileModal } from './components/ProfileModal';
import { PinModal } from './components/PinModal';
import { ReferralModal } from './components/ReferralModal';
import { WhitepaperModal } from './components/WhitepaperModal';

import { SkeletonLoader } from './components/SkeletonLoader';
import { InstantResponseBanner, BackgroundOperation } from './components/InstantResponseBanner';
import { OnboardingModal } from './components/OnboardingModal';
import { SubscriptionModal } from './components/SubscriptionModal';
import { TelemetryDashboardModal } from './components/TelemetryDashboardModal';
import { PrinciplesShowcaseModal } from './components/PrinciplesShowcaseModal';

import {
  verifyFlowerCodePoF,
  getOrCreateAxisIdentityAnchor,
  getBroadcastedPasskeys,
  POF_TOKENOMICS,
  POF_NODE_TIERS,
  notifyYinYangBus
} from './terraPofEngine';

const getModalTitle = (modal: string): string => {
  switch (modal) {
    case 'scanner':
      return 'NexusScan · QR Proof-of-Flower';
    case 'trade':
      return 'Trading · Flurish Exchange';
    case 'wallet':
      return 'Wallet & Treasury';
    case 'companies':
      return 'Verified Eco Companies';
    case 'store':
      return 'Rewards & Treasury Store';
    case 'daily':
      return 'Daily Streak Bonus';
    case 'missions':
      return 'Missions & Tasks';
    case 'achievements':
      return 'Milestones & Badges';
    case 'staking':
      return 'Teraxiom Node Staking';
    case 'social':
      return 'Leaderboard & Social';
    case 'history':
      return 'Audit & Transaction History';
    case 'advanced':
      return 'Network Node Console';
    case 'settings':
      return 'System Settings';
    case 'whitepaper':
      return 'Axis Whitepaper';
    case 'profile':
      return 'Account Profile';
    case 'referral':
      return 'Referral Program';
    case 'principles':
      return 'Architecture Showcase';
    case 'onboarding':
      return 'Onboarding Guide';
    case 'subscription':
      return 'Axis Pro Nodes';
    case 'telemetry':
      return 'Telemetry Hub';
    default:
      return modal.charAt(0).toUpperCase() + modal.slice(1);
  }
};

export default function App() {
  const layout = useAxisLayout();
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      const session = localStorage.getItem('axis_auth_session');
      if (session) {
        const parsed = JSON.parse(session);
        return Boolean(parsed?.isAuthenticated);
      }
    } catch {}
    return false;
  });

  // Global Top-to-Bottom UI Entrance Cascading Wave Controller
  const [entranceStarted, setEntranceStarted] = useState(false);
  const [entranceSettled, setEntranceSettled] = useState(false);
  const hasTriggeredEntranceRef = useRef(false);

  useEffect(() => {
    // Strictly trigger once when loading screen has completed and user is authenticated
    if (!loading && isAuthenticated && !hasTriggeredEntranceRef.current) {
      hasTriggeredEntranceRef.current = true;

      const prefersReduced =
        typeof window !== 'undefined' &&
        typeof window.matchMedia === 'function' &&
        window.matchMedia('(prefers-reduced-motion: reduce)').matches;

      if (prefersReduced) {
        setEntranceStarted(true);
        setEntranceSettled(true);
        return;
      }

      // Small tick ensures the DOM has finished unmounting the loader and painted the dashboard shell
      const startTimer = window.setTimeout(() => {
        setEntranceStarted(true);
      }, 50);

      // Clean up styles and settle will-change after all 5 stages finish (360ms delay + 550ms transition + 190ms buffer = 1100ms)
      const settleTimer = window.setTimeout(() => {
        setEntranceSettled(true);
      }, 1100);

      return () => {
        clearTimeout(startTimer);
        clearTimeout(settleTimer);
      };
    }
  }, [loading, isAuthenticated]);

  const [bgOps, setBgOps] = useState<BackgroundOperation[]>([]);
  const [state, setState] = useState<AxisState>(() => {
    const anchor = getOrCreateAxisIdentityAnchor();
    const today = new Date().toISOString().slice(0, 10);
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        // Automatic daily rollover check: reset daily scans & tasks if calendar date changed
        const currentDay = parsed.day?.key === today ? parsed.day : { key: today, scans: 0, receipts: 0, missions: [] };
        return {
          ...DEFAULT_STATE,
          ...parsed,
          day: currentDay,
          identityAnchor: parsed.identityAnchor || anchor,
          accountId: parsed.accountId || anchor.axisUserId,
          address: parsed.address || (anchor.axisPublicKey.slice(0, 10) + '...' + anchor.axisPublicKey.slice(-6))
        };
      }
    } catch {}
    return {
      ...DEFAULT_STATE,
      day: { key: today, scans: 0, receipts: 0, missions: [] },
      identityAnchor: anchor,
      accountId: anchor.axisUserId,
      address: anchor.axisPublicKey.slice(0, 10) + '...' + anchor.axisPublicKey.slice(-6)
    };
  });

  const [candles, setCandles] = useState<Candle[]>([]);
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [gustTrigger, setGustTrigger] = useState(0);
  const [toasts, setToasts] = useState<Array<{ id: string; msg: string; type?: 'good' | 'err' }>>([]);
  const [pinDialog, setPinDialog] = useState<{
    open: boolean;
    title: string;
    mode: 'verify' | 'setup';
    onVerified: (res?: any) => void;
  } | null>(null);

  const requestPinVerification = (title: string, onVerified: () => void) => {
    if (!state.pinHash || !state.pinSalt) {
      onVerified();
      return;
    }
    setPinDialog({
      open: true,
      title,
      mode: 'verify',
      onVerified: () => {
        setPinDialog(null);
        onVerified();
      }
    });
  };

  const openPinSetup = () => {
    setPinDialog({
      open: true,
      title: 'Setup Master Security PIN',
      mode: 'setup',
      onVerified: (res: any) => {
        setPinDialog(null);
        if (typeof res === 'object' && res.pinHash && res.pinSalt) {
          setState((prev) => ({
            ...prev,
            pinHash: res.pinHash,
            pinSalt: res.pinSalt,
            failedPinAttempts: 0,
            pinLockedUntil: null
          }));
          addToast('Master PIN successfully enrolled with salted PBKDF2 hashing!', 'good');
        }
      }
    });
  };

  const addToast = (msg: string, type?: 'good' | 'err') => {
    const id = rnd(6);
    setToasts((prev) => [...prev, { id, msg, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  };

  // Universal keyboard accessibility: close open modals or dialogs with Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (pinDialog) {
          setPinDialog(null);
        } else if (activeModal) {
          setActiveModal(null);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeModal, pinDialog]);

  const handleAuthSuccess = (userData: { name: string; email: string; isNewUser?: boolean }) => {
    try {
      localStorage.setItem(
        'axis_auth_session',
        JSON.stringify({
          isAuthenticated: true,
          name: userData.name,
          email: userData.email,
          ts: Date.now()
        })
      );
    } catch {}

    setState((prev) => ({
      ...prev,
      profile: {
        ...prev.profile,
        name: userData.name || prev.profile.name,
        email: userData.email || prev.profile.email
      }
    }));

    setIsAuthenticated(true);
    addToast(
      userData.isNewUser
        ? `Account initialized! Welcome to Axis, ${userData.name}.`
        : `Welcome back, ${userData.name}! Node session verified.`,
      'good'
    );
  };

  const handleLogout = () => {
    try {
      localStorage.removeItem('axis_auth_session');
    } catch {}
    setIsAuthenticated(false);
    setActiveModal(null);
    addToast('Signed out of Axis account', 'good');
  };

  // Principle #3: Instant UI Acknowledgement & Background Progress
  const triggerInstantOperation = (label: string) => {
    const id = rnd(6);
    setBgOps((prev) => [...prev, { id, label, progress: 20, status: 'processing' }]);
    
    let p = 20;
    const timer = setInterval(() => {
      p += 25;
      if (p >= 100) {
        clearInterval(timer);
        setBgOps((prev) => prev.map((op) => op.id === id ? { ...op, progress: 100, status: 'completed' } : op));
        setTimeout(() => {
          setBgOps((prev) => prev.filter((op) => op.id !== id));
        }, 900);
      } else {
        setBgOps((prev) => prev.map((op) => op.id === id ? { ...op, progress: p } : op));
      }
    }, 180);
  };

  // Synchronize state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {}
  }, [state]);

  // Apply Theme Tone & Seasonal Color Palettes (Leaves/Green, Sakura/Pink, Ocean/Blue, Autumn/Amber)
  useEffect(() => {
    const root = document.documentElement;
    const toneVal = Math.max(0, Math.min(100, state.settings?.tone ?? 0));
    const t = toneVal / 100;
    const weather = state.settings?.weatherMode ?? 'leaves';

    let bgR = 244, bgG = 250, bgB = 245, darkBgR = 6, darkBgG = 23, darkBgB = 11;
    let tabR = 228, tabG = 245, tabB = 231, darkTabR = 14, darkTabG = 36, darkTabB = 19;
    let clickR = 21, clickG = 109, clickB = 51, darkClickR = 41, darkClickG = 142, darkClickB = 68;

    if (weather === 'sakura') {
      // Calibrated Cherry Blossom Pink Shades
      bgR = 253; bgG = 242; bgB = 248; darkBgR = 32; darkBgG = 12; darkBgB = 22;
      tabR = 252; tabG = 231; tabB = 243; darkTabR = 48; darkTabG = 18; darkTabB = 34;
      clickR = 219; clickG = 39; clickB = 119; darkClickR = 244; darkClickG = 114; darkClickB = 182;
    } else if (weather === 'storming') {
      // Calibrated Ocean Marine Blue Shades
      bgR = 240; bgG = 249; bgB = 255; darkBgR = 8; darkBgG = 22; darkBgB = 36;
      tabR = 224; tabG = 242; tabB = 254; darkTabR = 14; darkTabG = 38; darkTabB = 58;
      clickR = 2; clickG = 132; clickB = 199; darkClickR = 56; darkClickG = 189; darkClickB = 248;
    } else if (weather === 'autumn') {
      // Calibrated Golden Amber Autumn Shades
      bgR = 254; bgG = 252; bgB = 232; darkBgR = 28; darkBgG = 18; darkBgB = 8;
      tabR = 254; tabG = 243; tabB = 199; darkTabR = 48; darkTabG = 32; darkTabB = 14;
      clickR = 217; clickG = 119; clickB = 6; darkClickR = 245; darkClickG = 158; darkClickB = 11;
    }

    const curBgR = Math.round(bgR + (darkBgR - bgR) * t);
    const curBgG = Math.round(bgG + (darkBgG - bgG) * t);
    const curBgB = Math.round(bgB + (darkBgB - bgB) * t);
    const bg = `rgb(${curBgR}, ${curBgG}, ${curBgB})`;

    const curTabR = Math.round(tabR + (darkTabR - tabR) * t);
    const curTabG = Math.round(tabG + (darkTabG - tabG) * t);
    const curTabB = Math.round(tabB + (darkTabB - tabB) * t);
    const tabBg = `rgb(${curTabR}, ${curTabG}, ${curTabB})`;

    const curClickR = Math.round(clickR + (darkClickR - clickR) * t);
    const curClickG = Math.round(clickG + (darkClickG - clickG) * t);
    const curClickB = Math.round(clickB + (darkClickB - clickB) * t);
    const clickBg = `rgb(${curClickR}, ${curClickG}, ${curClickB})`;

    root.style.setProperty('--bg', bg);
    root.style.setProperty('--neu-bg', tabBg);
    root.style.setProperty('--tab-bg', tabBg);
    root.style.setProperty('--c-green-click', clickBg);

    if (weather === 'blackhole') {
      root.style.setProperty('--accent', '#ffffff');
      root.style.setProperty('--c-action-primary', '#ffffff');
      root.style.setProperty('--c-border-focus', 'rgba(255, 255, 255, 0.45)');
    } else if (weather === 'sakura') {
      root.style.setProperty('--accent', 'rgb(219, 39, 119)');
      root.style.setProperty('--c-action-primary', 'rgb(219, 39, 119)');
    } else if (weather === 'storming') {
      root.style.setProperty('--accent', 'rgb(2, 132, 199)');
      root.style.setProperty('--c-action-primary', 'rgb(2, 132, 199)');
    } else if (weather === 'autumn') {
      root.style.setProperty('--accent', 'rgb(217, 119, 6)');
      root.style.setProperty('--c-action-primary', 'rgb(217, 119, 6)');
    } else {
      root.style.setProperty('--accent', '#1C863F');
      root.style.setProperty('--c-action-primary', '#1C863F');
    }

    if (t > 0.5) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [state.settings?.tone, state.settings?.weatherMode]);

  // 1. Yin-Yang Cross-Bus Synchronizer (TERRA Website <-> Axis App)
  useEffect(() => {
    const anchor = getOrCreateAxisIdentityAnchor();
    getBroadcastedPasskeys();

    if (typeof BroadcastChannel !== 'undefined') {
      const channel = new BroadcastChannel('terra_yin_yang_bus');
      channel.onmessage = (event) => {
        const { type } = event.data || {};
        if (type === 'TERRA_PASSKEYS_BROADCAST') {
          addToast('Yin-Yang Sync: Active Passkey batches received from Teraxiom Website', 'good');
        } else if (type === 'REQUEST_AXIS_ANCHOR') {
          channel.postMessage({
            type: 'RESPONSE_AXIS_ANCHOR',
            payload: anchor,
            sender: 'AXIS_APP_YIN',
            timestamp: Date.now()
          });
        }
      };
      return () => {
        channel.close();
      };
    }
  }, []);

  // 2. Handle Proof of Flower (PoF) Consensus Scan Verification Logic
  const handleScanCode = async (code: string): Promise<ScanResultDetail> => {
    const today = new Date().toISOString().slice(0, 10);
    const scansCountToday = state.day?.key === today ? (state.day?.scans || 0) : 0;

    // Enforce 100-scan daily cap
    if (scansCountToday >= DAILY_CAP) {
      addToast(`Daily limit of ${DAILY_CAP} scans reached. Resets tomorrow at midnight!`, 'err');
      return {
        code,
        isFirstEver: false,
        isDailyCapReached: true,
        rewardFlrx: 0,
        rewardPhp: 0,
        companyName: 'N/A',
        productName: 'Daily Scan Limit Reached (100/100)',
        category: 'Daily Cap',
        bonusMultiplier: 1.0,
        streakBonus: 0
      };
    }

    const pof = await verifyFlowerCodePoF(code);

    if (!pof.success) {
      addToast(pof.message, 'err');
      return {
        code,
        isFirstEver: false,
        isDailyCapReached: false,
        rewardFlrx: 0,
        rewardPhp: 0,
        companyName: pof.manufacturer || 'Unknown Packaging',
        productName: pof.productName || 'Unverified Code',
        category: 'Unverified',
        bonusMultiplier: 1.0,
        streakBonus: 0,
        consensusMechanism: 'Proof of Flower (PoF)',
        tier: pof.tier,
        digits: pof.digits,
        nodesVerified: pof.nodesVerified,
        nodesTotal: pof.nodesTotal,
        wasteReducedGrams: pof.wasteReducedGrams
      };
    }

    const {
      phpValue,
      flwrxAmount,
      tier,
      digits,
      nodesVerified,
      nodesTotal,
      consensusPercentage,
      wasteReducedGrams,
      manufacturer,
      productName,
      passkeyHash
    } = pof;

    setState((prev) => {
      const todayKey = new Date().toISOString().slice(0, 10);
      const nextDay = prev.day?.key === todayKey ? { ...prev.day } : { key: todayKey, scans: 0, receipts: 0, missions: [] };
      nextDay.scans += 1;

      const nextSeen = { ...(prev.seen || {}), [code]: (prev.seen?.[code] || 0) + 1 };
      const nextEver = { ...(prev.everCompanies || {}), [manufacturer]: (prev.everCompanies?.[manufacturer] || 0) + 1 };

      const nextPending = [
        {
          code,
          timestamp: Date.now(),
          company: manufacturer,
          product: productName,
          flrxReward: flwrxAmount,
          phpValue: phpValue,
          tier: tier,
          digits: digits,
          nodesVerified: nodesVerified,
          nodesTotal: nodesTotal,
          consensusMechanism: 'Proof of Flower (PoF)',
          wasteReducedGrams: wasteReducedGrams,
          verified: true
        },
        ...(prev.pendingScans || []).slice(0, 4)
      ];

      // Fix BUG-003: Append to state.history so HistoryModal displays the audit records
      const historyItem: ScanHistoryItem = {
        id: rnd(8),
        ts: Date.now(),
        code,
        company: manufacturer,
        product: productName,
        reward: flwrxAmount,
        first: prev.seen?.[code] ? 0 : 0.5,
        lv: tier,
        sp: 1,
        blockIndex: `Block #${Math.floor(100000 + Math.random() * 900000)}`,
        nodesConfirmed: nodesVerified,
        phpReward: phpValue
      };

      return {
        ...prev,
        php: r2(prev.php + phpValue),
        flrx: parseFloat((prev.flrx + flwrxAmount).toFixed(8)),
        totalEarned: parseFloat((prev.totalEarned + flwrxAmount).toFixed(8)),
        totalWasteReducedGrams: parseFloat(((prev.totalWasteReducedGrams || 0) + wasteReducedGrams).toFixed(1)),
        totalScans: prev.totalScans + 1,
        xp: prev.xp + (tier * 15),
        day: nextDay,
        seen: nextSeen,
        everCompanies: nextEver,
        pendingScans: nextPending,
        history: [historyItem, ...(prev.history || [])],
        tx: [
          {
            id: rnd(6),
            ts: Date.now(),
            type: 'scan',
            label: `PoF Tier ${tier}: ${manufacturer} (${nodesVerified.toLocaleString()} Nodes)`,
            php: phpValue,
            flrx: flwrxAmount
          },
          ...prev.tx
        ]
      };
    });

    triggerInstantOperation(
      `✓ Proof of Flower: ${nodesVerified.toLocaleString()} Nodes Confirmed · +₱${phpValue.toFixed(2)} & +${flwrxAmount.toFixed(8)} FLRX`
    );
    addToast(
      `Proof of Flower (PoF) Consensus! ${nodesVerified.toLocaleString()} nodes confirmed Passkey. +₱${phpValue.toFixed(2)}`,
      'good'
    );

    return {
      code,
      isFirstEver: true,
      isDailyCapReached: false,
      rewardFlrx: flwrxAmount,
      rewardPhp: phpValue,
      companyName: manufacturer,
      productName: productName,
      category: 'Recycled Packaging',
      bonusMultiplier: 1.0,
      streakBonus: 0,
      tier,
      digits,
      nodesVerified,
      nodesTotal,
      consensusPercentage,
      wasteReducedGrams,
      consensusMechanism: 'Proof of Flower (PoF)',
      passkeyHash,
      flwrxAmount
    };
  };

  const handleTrade = (side: 'buy' | 'sell', amt: number) => {
    const px = state.price * FX;
    if (side === 'buy') {
      const cost = amt * px * 1.001;
      setState((prev) => ({
        ...prev,
        php: r2(prev.php - cost),
        flrx: r6(prev.flrx + amt),
        trades: [{ ts: Date.now(), side, amt, price: prev.price, php: cost }, ...prev.trades],
        tx: [{ id: rnd(6), ts: Date.now(), type: 'trade', label: `Bought ${amt} FLRX`, php: -cost, flrx: amt }, ...prev.tx]
      }));
      triggerInstantOperation(`✓ Purchased ${amt} FLRX · Updating orderbook`);
      addToast(`Bought ${amt} FLRX!`, 'good');
    } else {
      const proceeds = amt * px * 0.999;
      setState((prev) => ({
        ...prev,
        php: r2(prev.php + proceeds),
        flrx: r6(prev.flrx - amt),
        trades: [{ ts: Date.now(), side, amt, price: prev.price, php: proceeds }, ...prev.trades],
        tx: [{ id: rnd(6), ts: Date.now(), type: 'trade', label: `Sold ${amt} FLRX`, php: proceeds, flrx: -amt }, ...prev.tx]
      }));
      triggerInstantOperation(`✓ Sold ${amt} FLRX · Transferring fiat`);
      addToast(`Sold ${amt} FLRX!`, 'good');
    }
  };

  const currentLevel = 1 + Math.floor(Math.sqrt(state.xp / 40));
  const claimableMissionsCount = 1;

  return (
    <div
      className={`relative min-h-[100dvh] w-full select-none overflow-x-hidden ${state.settings?.weatherMode === 'blackhole' ? 'theme-blackhole' : ''}`}
      data-weather={state.settings?.weatherMode || 'leaves'}
      data-tone={state.settings?.tone ?? 0}
    >
      {/* Principle #3: Instant UI Feedback Banner for Async Background Operations */}
      <InstantResponseBanner operations={bgOps} />

      {/* Background 3D Nature & Cosmic Ambient Atmosphere */}
      <AmbientBackground
        enabled={state.settings?.fallingLeaves ?? true}
        speed={state.settings?.fallingLeavesSpeed ?? 'slow'}
        weatherMode={state.settings?.weatherMode ?? 'leaves'}
        gustTrigger={gustTrigger}
        lowPowerMode={state.lowPowerMode}
        tone={state.settings?.tone ?? 0}
        relativitySlide={state.settings?.relativitySlide ?? 1.0}
      />

      {/* Global Liquid Glass SVG Refraction Filter */}
      <LiquidGlassFilter />

      {/* Growing Tree Logo Loading Screen on App Launch */}
      {loading && (
        <LoadingScreen
          onComplete={() => setLoading(false)}
          isCosmic={state.settings?.weatherMode === 'blackhole'}
        />
      )}

      {/* Replay Loading Screen on demand */}
      {activeModal === 'loading' && (
        <LoadingScreen
          onComplete={() => setActiveModal(null)}
          isCosmic={state.settings?.weatherMode === 'blackhole'}
        />
      )}

      {/* Version 10 Login & Registration UI (Shown after startup loading screen if unauthenticated) */}
      {!loading && !isAuthenticated && (
        <Version10Auth
          onSuccess={handleAuthSuccess}
          defaultEmail={state.profile.email}
          defaultName={state.profile.name}
        />
      )}

      <div className="axis-rotate-lock" role="alert">📱↻<br />Rotate your phone to landscape</div>

      <main
        data-axis-shell
        data-layout={layout}
        className={`relative z-10 w-full max-w-md md:max-w-xl lg:portrait:max-w-2xl landscape:max-w-none xl:max-w-5xl mx-auto px-3.5 sm:px-6 pt-[calc(var(--sat,0px)+0.5rem)] landscape:pt-[calc(var(--sat,0px)+0.35rem)] pb-[calc(var(--sab,0px)+2.5rem)] landscape:pb-[calc(var(--sab,0px)+0.75rem)] pl-[max(0.875rem,var(--sal,0px))] pr-[max(0.875rem,var(--sar,0px))] transition-opacity duration-300 ${!loading && !isAuthenticated ? 'opacity-0 pointer-events-none' : 'opacity-100'} ${entranceStarted ? 'axis-wave-active' : ''} ${entranceSettled ? 'axis-wave-settled' : ''}`}
      >
        {layout === 'portrait' ? (
          <div className="flex flex-col gap-2.5 sm:gap-3.5">
            {/* Stage 1 — Top: Header / Branding / Action Badges / Profile */}
            <div className={`axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`} data-stage="1">
              <Header state={state} onOpenScreen={(s) => setActiveModal(s)} />
            </div>

            {/* Stage 2 — Upper Content: Account Overview (Balances PHP & FLWRX + PoF Consensus HUD) */}
            <div className={`axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`} data-stage="2">
              <BalanceCard state={state} pricePHP={state.price * FX} />
              <div className="mt-2 sm:mt-2.5">
                <PostScanHud
                  pendingScans={state.pendingScans || []}
                  onVerifyComplete={() => {}}
                  onOpenDetails={() => setActiveModal('history')}
                />
              </div>
            </div>

            {/* Stages 3, 4, 5 (Nexus Scan Hero, Primary 2x2, and Secondary Navigation Dock) */}
            <TilesGrid
              state={state}
              chg24={2.45}
              claimableMissionsCount={claimableMissionsCount}
              onOpenScreen={(s) => setActiveModal(s)}
              onGuardScreen={(s) => setActiveModal(s)}
              isLoaded={!loading && isAuthenticated && activeModal !== 'loading'}
              entranceSettled={entranceSettled}
            />
          </div>
        ) : (
          <div className="axis-landscape-dashboard w-full">
            {/* Stage 1 — Top: Compact Full-Width Top Navigation with Price Ticker (grid-area: header) */}
            <div
              className={`axis-area-header axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
              data-stage="1"
              style={{ gridArea: 'header' }}
            >
              <Header
                state={state}
                onOpenScreen={(s) => setActiveModal(s)}
                isLandscape
                pricePHP={state.price * FX}
                chg24={2.45}
              />
            </div>

            {/* Stage 2 — Left Column: Account Overview (grid-area: account) */}
            <div
              className={`axis-area-account flex flex-col justify-between gap-2.5 h-full min-h-0 axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
              data-stage="2"
              style={{ gridArea: 'account' }}
            >
              <div className="flex-1 flex flex-col min-h-0">
                <BalanceCard state={state} pricePHP={state.price * FX} isLandscape />
              </div>
              <div className="h-[60px] min-h-[60px] shrink-0 flex flex-col">
                <PostScanHud
                  pendingScans={state.pendingScans || []}
                  onVerifyComplete={() => {}}
                  onOpenDetails={() => setActiveModal('history')}
                  isLandscape
                />
              </div>
            </div>

            {/* Stage 3 — Center Column: Nexus Scan Primary Action Hero Card (grid-area: nexus) */}
            <div
              className={`axis-area-nexus flex flex-col h-full min-h-0 axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
              data-stage="3"
              style={{ gridArea: 'nexus' }}
            >
              <NexusScanHeroCard
                state={state}
                chg24={2.45}
                onOpenScanner={() => setActiveModal('scanner')}
                onOpenTrade={() => setActiveModal('trade')}
                isLoaded={!loading && isAuthenticated && activeModal !== 'loading'}
              />
            </div>

            {/* Stage 4 — Right Column: Primary Features 2x2 Grid (grid-area: features) */}
            <div
              className={`axis-area-features flex flex-col h-full min-h-0 axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
              data-stage="4"
              style={{ gridArea: 'features' }}
            >
              <PrimaryFeaturesGrid
                claimableMissionsCount={claimableMissionsCount}
                onOpenScreen={(s) => setActiveModal(s)}
                onGuardScreen={(s) => setActiveModal(s)}
              />
            </div>

            {/* Stage 5 — Navigation: Bottom Quick Navigation Dock (grid-area: dock) */}
            <div
              className={`axis-area-dock axis-wave-stage ${entranceSettled ? 'is-settled' : ''}`}
              data-stage="5"
              style={{ gridArea: 'dock' }}
            >
              <BottomQuickDock
                onOpenScreen={(s) => setActiveModal(s)}
                onGuardScreen={(s) => setActiveModal(s)}
              />
            </div>
          </div>
        )}
      </main>

      {/* Toast Notification Container */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-1.5 pointer-events-none w-full max-w-xs px-4">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`px-4 py-2.5 rounded-xl shadow-lg text-xs font-bold font-mono transition-all duration-300 pointer-events-auto border ${
              t.type === 'err'
                ? 'bg-rose-900/90 text-rose-100 border-rose-500/30'
                : 'bg-emerald-900/90 text-emerald-100 border-emerald-500/30'
            }`}
          >
            {t.msg}
          </div>
        ))}
      </div>

      {/* Global Modals Container — Centered Floating Box with Responsive Width & Safe-Area Padding */}
      {activeModal && activeModal !== 'loading' && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-headline"
          className="fixed inset-0 z-40 flex items-center justify-center p-3.5 sm:p-6 bg-black/45 select-none transition-opacity duration-200 axis-modal-container"
          onClick={(e) => {
            if (e.target === e.currentTarget) setActiveModal(null);
          }}
        >
          <div
            className={`relative w-full ${
              ['trade', 'whitepaper', 'telemetry', 'principles', 'history', 'companies', 'advanced', 'staking', 'scanner'].includes(activeModal)
                ? 'max-w-md md:max-w-2xl lg:max-w-3xl'
                : 'max-w-md'
            } max-h-[min(90vh,94dvh)] flex flex-col rounded-3xl neu-sheet overflow-hidden animate-modal-pop shadow-2xl border border-[var(--glass-border-card)] axis-modal`}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Pinned Sticky Header: Stays locked at top across all tabs */}
            <div className="shrink-0 flex items-center justify-between px-4 sm:px-5 py-3.5 border-b border-[var(--neu-border-dark)] bg-[var(--neu-sheet-bg)] z-10 select-none">
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-2.5 h-2.5 rounded-full bg-[var(--c-action-primary)] shadow-[0_0_8px_var(--c-action-glow)] shrink-0" />
                <h2 id="modal-headline" className="text-sm font-extrabold uppercase tracking-wide text-[var(--ink)] truncate">
                  {getModalTitle(activeModal)}
                </h2>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="py-1 px-3 rounded-xl neu-btn text-xs font-bold text-[var(--ink2)] hover:text-[var(--ink)] cursor-pointer transition active:scale-95 shrink-0"
                aria-label="Close dialog"
              >
                ✕ Close
              </button>
            </div>

            {/* Scrollable Modal Body: Content scrolls smoothly while header remains anchored */}
            <div className="flex-1 overflow-y-auto min-h-0 p-4 sm:p-5 overscroll-contain">
              {activeModal === 'scanner' && (
              <ScannerModal
                state={state}
                onScanResult={handleScanCode}
                onClose={() => setActiveModal(null)}
                onToast={addToast}
              />
            )}

            {activeModal === 'trade' && (
              <TradingModal
                state={state}
                candles={candles}
                chg24={2.45}
                onTrade={handleTrade}
                onPlaceOrder={() => {}}
                onCancelOrder={() => {}}
                onAddAlert={() => {}}
                onToast={addToast}
              />
            )}

            {activeModal === 'wallet' && (
              <WalletModal
                state={state}
                onDeposit={(amt: number) => {
                  setState((prev) => ({ ...prev, php: r2(prev.php + amt) }));
                  addToast(`Deposited ₱${amt.toFixed(2)}`, 'good');
                }}
                onWithdraw={(...args: any[]) => {
                  let amt = 0;
                  let fee = 15;
                  let dest = 'GCash / Maya';
                  if (typeof args[0] === 'string' && args.length >= 4) {
                    amt = args[2];
                    fee = args[3];
                    dest = args[4] || args[1];
                  } else {
                    amt = typeof args[0] === 'number' ? args[0] : 0;
                    fee = typeof args[1] === 'number' ? args[1] : 15;
                    dest = args[2] || 'GCash/Bank';
                  }
                  const total = amt + fee;
                  setState((prev) => ({
                    ...prev,
                    php: r2(prev.php - total),
                    tx: [
                      {
                        id: rnd(6),
                        ts: Date.now(),
                        type: 'withdraw',
                        label: `Withdrawal via ${dest}`,
                        php: -total,
                        flrx: 0
                      },
                      ...prev.tx
                    ]
                  }));
                }}
                onSendCrypto={(to: string, amt: number) => {
                  setState((prev) => ({
                    ...prev,
                    flrx: r6(prev.flrx - amt),
                    tx: [
                      {
                        id: rnd(6),
                        ts: Date.now(),
                        type: 'send',
                        label: `Sent ${amt} FLRX to ${to.slice(0, 10)}...`,
                        php: 0,
                        flrx: -amt
                      },
                      ...prev.tx
                    ]
                  }));
                  addToast(`Sent ${amt} FLRX to ${to.slice(0, 8)}...`, 'good');
                }}
                onToast={addToast}
                onRequestPin={(title, fn) => requestPinVerification(title, fn)}
              />
            )}

            {activeModal === 'companies' && (
              <CompaniesModal
                state={state}
                sponsoredCompany={COMPANIES[0]}
                onOpenScanner={() => setActiveModal('scanner')}
                onToast={addToast}
              />
            )}

            {activeModal === 'store' && (
              <StoreModal
                state={state}
                sponsoredCompany={COMPANIES[0]}
                onRedeem={(item) => {
                  setState((prev) => {
                    const currentPool = prev.flwrxReservePool || 1000000;
                    const nextPool = Math.max(0, currentPool - item.cost);
                    return {
                      ...prev,
                      flrx: r6(prev.flrx - item.cost),
                      flwrxReservePool: nextPool,
                      vouchers: [{ id: item.id, name: item.name, code: `AX-${rnd(4)}`, ts: Date.now() }, ...prev.vouchers],
                      tx: [
                        {
                          id: rnd(6),
                          ts: Date.now(),
                          type: 'store',
                          label: `Redeemed ${item.name} · Teraxiom Treasury Dispatched`,
                          php: 0,
                          flrx: -item.cost
                        },
                        ...prev.tx
                      ]
                    };
                  });
                  addToast(`Redeemed ${item.name}! Liquidity provided by Teraxiom Treasury`, 'good');
                }}
                onToast={addToast}
              />
            )}

            {activeModal === 'daily' && (
              <DailyModal
                state={state}
                onClaimDaily={() => {
                  const STREAK_REWARDS = [0.5, 1.0, 1.5, 2.0, 3.0, 4.5, 10.0];
                  const curStreak = state.claim?.streak || 0;
                  const nextStreak = curStreak + 1;
                  const streakDayIndex = (nextStreak - 1) % 7;
                  const rewardAmt = STREAK_REWARDS[streakDayIndex];

                  setState((prev) => ({
                    ...prev,
                    flrx: r6(prev.flrx + rewardAmt),
                    claim: {
                      ...prev.claim,
                      streak: nextStreak,
                      last: new Date().toISOString().slice(0, 10),
                      total: (prev.claim?.total || 0) + rewardAmt
                    },
                    tx: [
                      {
                        id: rnd(6),
                        ts: Date.now(),
                        type: 'reward',
                        label: `Day ${streakDayIndex + 1} Streak Bonus (+${rewardAmt} FLWRX)`,
                        php: 0,
                        flrx: rewardAmt
                      },
                      ...prev.tx
                    ]
                  }));
                  addToast(`Claimed Day ${streakDayIndex + 1} streak bonus: +${rewardAmt} FLWRX!`, 'good');
                }}
                onToast={addToast}
              />
            )}

            {activeModal === 'missions' && (
              <MissionsModal
                state={state}
                onClaimMission={(m) => {
                  setState((prev) => {
                    const missionXp = m.xp || 15;
                    const nextDayMissions = m.t === 'd'
                      ? [...(prev.day?.missions || []), m.id]
                      : (prev.day?.missions || []);
                    const nextWeekMissions = m.t === 'w'
                      ? [...(prev.week?.missions || []), m.id]
                      : (prev.week?.missions || []);

                    return {
                      ...prev,
                      flrx: r6(prev.flrx + m.reward),
                      xp: prev.xp + missionXp,
                      day: { ...prev.day, missions: nextDayMissions },
                      week: { ...(prev.week || { key: 'w1', missions: [] }), missions: nextWeekMissions },
                      tx: [
                        {
                          id: rnd(6),
                          ts: Date.now(),
                          type: 'reward',
                          label: `Mission: ${m.title} (+${m.reward} FLRX)`,
                          php: 0,
                          flrx: m.reward
                        },
                        ...prev.tx
                      ]
                    };
                  });
                  addToast(`Mission claimed: +${m.reward} FLRX & +${m.xp || 15} XP!`, 'good');
                }}
                onToast={addToast}
              />
            )}

            {activeModal === 'achievements' && (
              <AchievementsModal
                state={state}
                level={currentLevel}
                levelMultiplier={1.15}
              />
            )}

            {activeModal === 'staking' && (
              <StakingModal
                state={state}
                onStake={(amount, lockIndex) => {
                  const tier = STAKING_TIERS[lockIndex] || STAKING_TIERS[0];
                  setState((prev) => ({
                    ...prev,
                    flrx: r6(prev.flrx - amount),
                    staked: r6((prev.staked || 0) + amount),
                    stakes: [
                      {
                        id: rnd(6),
                        amount,
                        start: Date.now(),
                        lockDays: tier.days,
                        apy: tier.apy,
                        claimed: 0,
                        lastClaim: Date.now()
                      },
                      ...(prev.stakes || [])
                    ],
                    tx: [
                      {
                        id: rnd(6),
                        ts: Date.now(),
                        type: 'reward',
                        label: `Staked ${amount} FLRX (${tier.label} · ${tier.apyLabel})`,
                        php: 0,
                        flrx: -amount
                      },
                      ...prev.tx
                    ]
                  }));
                  addToast(`Staked ${amount} FLRX in ${tier.label} vault!`, 'good');
                }}
                onUnstake={(id) => {
                  setState((prev) => {
                    const pos = prev.stakes?.find((s) => s.id === id);
                    if (!pos) return prev;
                    const returnAmt = pos.amount;
                    return {
                      ...prev,
                      flrx: r6(prev.flrx + returnAmt),
                      staked: Math.max(0, r6((prev.staked || 0) - returnAmt)),
                      stakes: prev.stakes.filter((s) => s.id !== id),
                      tx: [
                        {
                          id: rnd(6),
                          ts: Date.now(),
                          type: 'reward',
                          label: `Unstaked ${returnAmt} FLRX Vault Return`,
                          php: 0,
                          flrx: returnAmt
                        },
                        ...prev.tx
                      ]
                    };
                  });
                  addToast('Staking position redeemed and principal returned to wallet!', 'good');
                }}
                onClaimYield={(id) => {
                  setState((prev) => {
                    const pos = prev.stakes?.find((s) => s.id === id);
                    if (!pos) return prev;
                    const elapsedDays = Math.max(0.001, (Date.now() - (pos.lastClaim || pos.start)) / (1000 * 60 * 60 * 24));
                    const accruedYield = Math.max(0.000001, r6(pos.amount * pos.apy * (elapsedDays / 365)));
                    return {
                      ...prev,
                      flrx: r6(prev.flrx + accruedYield),
                      stakes: prev.stakes.map((s) => s.id === id ? { ...s, claimed: (s.claimed || 0) + accruedYield, lastClaim: Date.now() } : s),
                      tx: [
                        {
                          id: rnd(6),
                          ts: Date.now(),
                          type: 'reward',
                          label: `Staking Yield Claim (+${accruedYield.toFixed(6)} FLRX)`,
                          php: 0,
                          flrx: accruedYield
                        },
                        ...prev.tx
                      ]
                    };
                  });
                  addToast('Staking yield successfully claimed into liquid FLRX!', 'good');
                }}
                onClaimAll={() => {
                  addToast('All accrued staking yields claimed!', 'good');
                }}
                onToast={addToast}
              />
            )}

            {activeModal === 'social' && (
              <SocialModal
                state={state}
                onRedeemReferral={() => {}}
                onAddContact={(c) => {
                  setState((prev) => ({ ...prev, friends: [...prev.friends, c] }));
                  addToast(`Added contact ${c.name}!`, 'good');
                }}
                onRemoveContact={(idx) => {
                  setState((prev) => ({ ...prev, friends: prev.friends.filter((_, i) => i !== idx) }));
                  addToast('Removed contact', 'good');
                }}
                onSendToContact={() => setActiveModal('wallet')}
                onToast={addToast}
              />
            )}

            {activeModal === 'history' && (
              <HistoryModal
                state={state}
                onSyncQueue={() => {
                  setState((prev) => ({ ...prev, queue: [] }));
                  addToast('Synced offline scans!', 'good');
                }}
                onOpenScanner={() => setActiveModal('scanner')}
              />
            )}

            {activeModal === 'advanced' && (
              <AdvancedModal
                state={state}
                onToggleAutoMining={(on) => {
                  setState((prev) => ({ ...prev, auto: { ...prev.auto, on } }));
                  addToast(on ? 'Auto-mining activated' : 'Auto-mining paused', 'good');
                }}
                onConfigureBot={() => {}}
                onOpenStaking={() => setActiveModal('staking')}
                onOpenGoals={() => setActiveModal('missions')}
                onOpenWhitepaper={() => setActiveModal('whitepaper')}
                onToast={addToast}
              />
            )}

            {activeModal === 'settings' && (
              <SettingsModal
                state={state}
                onUpdateSettings={(updater) => {
                  setState((prev) => ({ ...prev, settings: updater(prev.settings) }));
                }}
                onUpdateSecurity={(updater) => {
                  setState((prev) => ({
                    ...prev,
                    securitySettings: updater(prev.securitySettings || {
                      biometrics: false,
                      requirePinForTrade: false,
                      requirePinForTransfer: false,
                      antiPhishingCode: 'AXIS-SAFE'
                    })
                  }));
                }}
                onToggleLowPower={(enabled) => {
                  setState((prev) => ({ ...prev, lowPowerMode: enabled }));
                }}
                onOpenScreen={(s) => setActiveModal(s)}
                onTogglePin={(enable) => {
                  if (!enable) {
                    setState((prev) => ({ ...prev, pinHash: null, pinSalt: null, failedPinAttempts: 0, pinLockedUntil: null }));
                    addToast('PIN protection disabled', 'good');
                  } else {
                    openPinSetup();
                  }
                }}
                onResetData={() => {
                  localStorage.clear();
                  window.location.reload();
                }}
                onToast={addToast}
                onTriggerGust={() => setGustTrigger((prev) => prev + 1)}
              />
            )}

            {activeModal === 'whitepaper' && (
              <WhitepaperModal onToast={addToast} />
            )}

            {activeModal === 'profile' && (
              <ProfileModal
                state={state}
                onSaveProfile={(name: string, email: string, avatar: string) => {
                  setState((prev) => ({ ...prev, profile: { ...prev.profile, name, email, avatar } }));
                }}
                onLogout={handleLogout}
                onToast={addToast}
              />
            )}

            {activeModal === 'referral' && (
              <ReferralModal
                state={state}
                onRedeem={(code) => {
                  setState((prev) => ({
                    ...prev,
                    flrx: prev.flrx + 10,
                    referral: { ...prev.referral, redeemed: true }
                  }));
                  addToast(`Referral code ${code} redeemed! +10 FLRX`, 'good');
                }}
                onClaimBounty={() => {
                  const bountyUSD = 20;
                  const bountyPHP = bountyUSD * FX; // ₱1,170
                  setState((prev) => ({
                    ...prev,
                    php: r2(prev.php + bountyPHP),
                    referral: {
                      ...prev.referral,
                      bountyClaimed: true,
                      totalEarnedUsd: (prev.referral.totalEarnedUsd || 0) + bountyUSD
                    },
                    tx: [
                      {
                        id: rnd(6),
                        ts: Date.now(),
                        type: 'reward',
                        label: `200-Referral Milestone Bounty Payout ($20 USD / ₱${bountyPHP.toFixed(2)})`,
                        php: bountyPHP,
                        flrx: 0
                      },
                      ...prev.tx
                    ]
                  }));
                  addToast(`Claimed $20 USD (₱${bountyPHP.toFixed(2)}) Referral Milestone Bounty!`, 'good');
                }}
                onSimulateReferral={() => {
                  setState((prev) => {
                    const currentCount = prev.referral?.count || 12;
                    const nextCount = Math.min(200, currentCount + 15);
                    return {
                      ...prev,
                      referral: {
                        ...prev.referral,
                        count: nextCount
                      }
                    };
                  });
                  addToast('Simulated +15 friend referral signups!', 'good');
                }}
                onToast={addToast}
              />
            )}

            {activeModal === 'principles' && (
              <PrinciplesShowcaseModal
                onOpenOnboarding={() => setActiveModal('onboarding')}
                onSimulateBackgroundOp={() => {
                  triggerInstantOperation('✓ Cryptographic Proof-of-Scan Batch Hash (Background Worker)');
                  addToast('Instant tactile response acknowledged at 0ms!', 'good');
                }}
                onToast={addToast}
              />
            )}

            {activeModal === 'onboarding' && (
              <OnboardingModal
                onComplete={() => {
                  setActiveModal(null);
                  addToast('✓ Onboarding completed smoothly!', 'good');
                }}
                onClose={() => setActiveModal(null)}
              />
            )}

            {activeModal === 'subscription' && (
              <SubscriptionModal onToast={addToast} />
            )}

            {activeModal === 'telemetry' && (
              <TelemetryDashboardModal />
            )}
            </div>
          </div>
        </div>
      )}

      {/* Cryptographic Master PIN Dialog */}
      {pinDialog?.open && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-fade-in"
          onClick={() => setPinDialog(null)}
        >
          <div
            className="w-full max-w-sm rounded-3xl neu-sheet p-6 shadow-2xl border border-[var(--glass-border-card)] animate-modal-pop"
            onClick={(e) => e.stopPropagation()}
          >
            <PinModal
              title={pinDialog.title}
              mode={pinDialog.mode}
              currentPinHash={state.pinHash}
              currentPinSalt={state.pinSalt}
              onSuccess={(res) => pinDialog.onVerified(res)}
              onCancel={() => setPinDialog(null)}
              onClose={() => setPinDialog(null)}
              onToast={addToast}
            />
          </div>
        </div>
      )}
    </div>
  );
}
