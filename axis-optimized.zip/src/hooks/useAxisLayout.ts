import { useLayoutEffect, useState, useRef } from 'react';
import { flushSync } from 'react-dom';

const Q = '(orientation: landscape), (min-width: 960px)';
const REDUCE_Q = '(prefers-reduced-motion: reduce)';
const DUR = 480;
const EASE = 'cubic-bezier(.2,.8,.2,1)';

export function useAxisLayout(): 'portrait' | 'landscape' {
  const [layout, setLayout] = useState<'portrait' | 'landscape'>(() => {
    if (typeof window === 'undefined') return 'portrait';
    return window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
  });

  const isInitial = useRef(true);

  useLayoutEffect(() => {
    if (typeof window === 'undefined') return;

    const shell = document.querySelector<HTMLElement>('[data-axis-shell]');
    const mq = window.matchMedia('(orientation: landscape)');
    const reduce = window.matchMedia(REDUCE_Q);

    const zones = () => {
      if (!shell) return [];
      return Array.from(shell.querySelectorAll<HTMLElement>('[data-zone]:not([data-zone="header"])'));
    };

    // Evaluates actual available viewport width vs height to adapt dynamically across phones, tablets, foldables, and desktops
    const layoutOf = (): 'portrait' | 'landscape' => {
      return window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
    };

    const apply = () => {
      const next = layoutOf();
      setLayout(next);
      if (shell) {
        shell.dataset.layout = next;
      }
    };

    function withViewTransition() {
      const els = zones();
      els.forEach((el, i) => {
        el.style.viewTransitionName = 'z' + i;
      });

      const vt = (document as any).startViewTransition(() => {
        flushSync(apply);
      });

      if (vt && vt.finished) {
        vt.finished.finally(() => {
          els.forEach((el) => {
            el.style.viewTransitionName = '';
          });
        });
      } else {
        setTimeout(() => {
          els.forEach((el) => {
            el.style.viewTransitionName = '';
          });
        }, DUR);
      }
    }

    function withFlip() {
      const els = zones();
      const first = new Map(els.map((el) => [el, el.getBoundingClientRect()]));

      flushSync(apply);

      requestAnimationFrame(() => {
        els.forEach((el) => {
          const a = first.get(el);
          if (!a) return;
          const b = el.getBoundingClientRect();
          const dx = a.left - b.left;
          const dy = a.top - b.top;
          const sx = b.width > 0 ? a.width / b.width : 1;
          const sy = b.height > 0 ? a.height / b.height : 1;
          if (!dx && !dy && Math.abs(sx - 1) < 0.01 && Math.abs(sy - 1) < 0.01) return;

          el.animate(
            [
              {
                transformOrigin: 'top left',
                transform: `translate(${dx}px, ${dy}px) scale(${sx}, ${sy})`,
                opacity: 0.6
              },
              {
                transformOrigin: 'top left',
                transform: 'none',
                opacity: 1
              }
            ],
            { duration: DUR, easing: EASE }
          );
        });
      });
    }

    let raf = 0;
    const onChange = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const next = layoutOf();
        const currentAttr = shell?.getAttribute('data-layout');
        if (currentAttr === next) return;

        if (isInitial.current || reduce.matches) {
          apply();
          return;
        }

        if ('startViewTransition' in document && typeof (document as any).startViewTransition === 'function') {
          withViewTransition();
        } else {
          withFlip();
        }
      });
    };

    // First load: set dataset and skip animation
    if (shell) {
      shell.dataset.layout = layoutOf();
    }
    isInitial.current = false;

    mq.addEventListener('change', onChange);
    window.addEventListener('resize', onChange);
    window.addEventListener('orientationchange', onChange);

    return () => {
      cancelAnimationFrame(raf);
      mq.removeEventListener('change', onChange);
      window.removeEventListener('resize', onChange);
      window.removeEventListener('orientationchange', onChange);
    };
  }, []);

  return layout;
}
