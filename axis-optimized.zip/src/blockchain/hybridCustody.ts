/**
 * AXIS HYBRID CUSTODY ARCHITECTURE
 * 
 * Segregates two distinct wallet custody models:
 * Mode A: USER SELF-CUSTODY (User holds cryptographic authority via on-device Keystore / Seed)
 * Mode B: AXIS-MANAGED CUSTODY (Institutional MPC / HSM backed key custody with segregated accounting)
 * 
 * CORE PRINCIPLE:
 * AXIS servers never possess unilateral access to self-custody private keys.
 * Customer custody funds are strictly isolated from Corporate Treasury keys.
 */

import { getSecureRandomBytes, bytesToHex, hashPinWithSalt } from './cryptoUtils';

export type CustodyMode = 'SELF_CUSTODY' | 'AXIS_MANAGED';

export interface WhitelistAddressEntry {
  address: string;
  label: string;
  network: 'FLRXCORE_INTERNAL' | 'ETHEREUM_L1' | 'ARBITRUM_ONE' | 'POLYGON_POS';
  addedAt: number;
  activeAfterTimestamp: number; // 24-hour security delay before address becomes spendable
  status: 'PENDING_COOLDOWN' | 'ACTIVE' | 'REVOKED';
}

export interface CustodyPolicy {
  mode: CustodyMode;
  accountAddress: string;
  publicKey: string;
  hardwareKeystoreBacked: boolean;
  biometricSigningEnforced: boolean;
  dailyWithdrawalLimitPhp: number;
  singleTransactionLimitPhp: number;
  withdrawalCooldownMinutes: number;
  lastWithdrawalTimestamp: number;
  whitelistedAddresses: WhitelistAddressEntry[];
  custodyTermsAccepted: boolean;
  custodyDisclaimer: string;
}

export interface CustodyTransferRequest {
  id: string;
  sourceMode: CustodyMode;
  senderAddress: string;
  destinationAddress: string;
  asset: 'FLRX' | 'PHP_LIQUID';
  amount: number;
  estimatedFee: number;
  network: 'FLRXCORE' | 'PUBLIC_BRIDGE';
  nonce: number;
  timestamp: number;
  userSignature?: string;
  mpcApprovalToken?: string;
}

export const CUSTODY_DISCLAIMERS = {
  SELF_CUSTODY: 
    'SELF-CUSTODY MODE: You control your private cryptographic keys. AXIS servers never hold or transmit your keys. If you lose your recovery credentials, AXIS cannot recover your funds. You are solely responsible for transaction confirmation and signing.',
  AXIS_MANAGED: 
    'AXIS-MANAGED CUSTODY: Your funds are protected in an institutional MPC/HSM segregated custody cluster with address whitelisting, daily velocity limits, and 24-hour withdrawal cooldowns. Customer assets are legally segregated from the Corporate Treasury.'
};

/**
 * Initialize Default Custody Policy for User
 */
export function initializeCustodyPolicy(mode: CustodyMode, userAddress: string, pubKey: string): CustodyPolicy {
  return {
    mode,
    accountAddress: userAddress,
    publicKey: pubKey,
    hardwareKeystoreBacked: typeof window !== 'undefined' && Boolean(window.PublicKeyCredential),
    biometricSigningEnforced: false,
    dailyWithdrawalLimitPhp: mode === 'SELF_CUSTODY' ? 50000.0 : 25000.0,
    singleTransactionLimitPhp: mode === 'SELF_CUSTODY' ? 20000.0 : 10000.0,
    withdrawalCooldownMinutes: mode === 'SELF_CUSTODY' ? 0 : 30, // 30-min cooldown between withdrawals for managed
    lastWithdrawalTimestamp: 0,
    whitelistedAddresses: [],
    custodyTermsAccepted: true,
    custodyDisclaimer: CUSTODY_DISCLAIMERS[mode]
  };
}

/**
 * Validate a transfer request against custody risk rules
 */
export function validateCustodyTransfer(
  request: CustodyTransferRequest,
  policy: CustodyPolicy,
  currentBalance: number
): { allowed: boolean; reason?: string; requiresPin?: boolean; requiresBiometrics?: boolean } {
  // 1. Balance Check
  const totalCost = request.amount + request.estimatedFee;
  if (currentBalance < totalCost) {
    return { allowed: false, reason: 'INSUFFICIENT_FUNDS: Requested amount exceeds available spendable balance.' };
  }

  // 2. Single Transaction Limit
  const phpEquivalent = request.asset === 'PHP_LIQUID' ? request.amount : request.amount * 58.5 * 0.524;
  if (phpEquivalent > policy.singleTransactionLimitPhp) {
    return {
      allowed: false,
      reason: `LIMIT_EXCEEDED: Single transaction ceiling is ₱${policy.singleTransactionLimitPhp.toLocaleString()}.`
    };
  }

  // 3. Withdrawal Cooldown Check for Managed Custody
  if (policy.mode === 'AXIS_MANAGED' && policy.withdrawalCooldownMinutes > 0) {
    const elapsedMinutes = (Date.now() - policy.lastWithdrawalTimestamp) / 60000;
    if (elapsedMinutes < policy.withdrawalCooldownMinutes) {
      const waitMinutes = Math.ceil(policy.withdrawalCooldownMinutes - elapsedMinutes);
      return {
        allowed: false,
        reason: `COOLDOWN_ACTIVE: Anti-drain security cooldown active. Please wait ${waitMinutes} minute(s).`
      };
    }
  }

  // 4. Address Whitelist Enforcement for High-Value Transfers
  if (phpEquivalent > 5000) {
    const matchingWhitelist = policy.whitelistedAddresses.find(
      (w) => w.address.toLowerCase() === request.destinationAddress.toLowerCase() && w.status === 'ACTIVE'
    );
    if (!matchingWhitelist) {
      return {
        allowed: false,
        reason: 'WHITELIST_REQUIRED: High-value transfers (>₱5,000) must send to an active whitelisted destination address.'
      };
    }
  }

  return {
    allowed: true,
    requiresPin: true,
    requiresBiometrics: policy.biometricSigningEnforced
  };
}
