/**
 * TERRA BLOCKCHAIN - PROOF OF FLOWER (PoF) ENGINE & YIN-YANG CONSENSUS BRIDGE
 * 
 * System Architecture:
 * - White Side (Yang): TERRA Website broadcasts Passkeys / Target Flower Code Hashes
 * - Black Side (Yin): Axis App & Decentralized Nodes find, match, and verify Flower Codes
 * 
 * Core Doctrines:
 * 1. Axis-First Registration Doctrine: User must register in Axis App first (uaYYYYNNNNN).
 * 2. Proof of Flower (PoF) Consensus: ₱1.00 = 1 Code, 51% User (₱0.51 / 0.001 FLWRX) & 49% Treasury.
 * 3. Dynamic 11-Tier Code Scanner: 28 to 98 digits (step +7) with scaling node quorum (>=50%).
 * 4. 1,000,000-Block Sovereign Ledger with Era Halving & Block Capacity Scaling.
 * 5. 2-Year (730-day) Batch Expiration with 50/50 Forfeiture Rule.
 * 6. Anti-Bot, Anti-Cloning & 24h Sequential Brute-Force Locking.
 * 7. Eternal 10% Reserve Lock with 100% Unanimous User Governance.
 */

export interface NodeTierConfig {
  tier: number;
  length: number;
  totalNodes: number;
  minConfirmationThreshold: number; // 50%
}

export const NODE_TIERS: Record<number, NodeTierConfig> = {
  28: { tier: 1, length: 28, totalNodes: 100, minConfirmationThreshold: 50 },
  35: { tier: 2, length: 35, totalNodes: 350, minConfirmationThreshold: 175 },
  42: { tier: 3, length: 42, totalNodes: 1200, minConfirmationThreshold: 600 },
  49: { tier: 4, length: 49, totalNodes: 4500, minConfirmationThreshold: 2250 },
  56: { tier: 5, length: 56, totalNodes: 15000, minConfirmationThreshold: 7500 },
  63: { tier: 6, length: 63, totalNodes: 55000, minConfirmationThreshold: 27500 },
  70: { tier: 7, length: 70, totalNodes: 200000, minConfirmationThreshold: 100000 },
  77: { tier: 8, length: 77, totalNodes: 700000, minConfirmationThreshold: 350000 },
  84: { tier: 9, length: 84, totalNodes: 2500000, minConfirmationThreshold: 1250000 },
  91: { tier: 10, length: 91, totalNodes: 5000000, minConfirmationThreshold: 2500000 },
  98: { tier: 11, length: 98, totalNodes: 500000000, minConfirmationThreshold: 250000000 }
};

export interface TerraManufacturingBatch {
  batchId: string;
  manufacturerName: string;
  companyId: string;
  activatedTs: number;
  expiresTs: number;
  totalCodes: number;
  blockIndex: number;
  targetPasskeys: string[]; // Active passkeys broadcasted from TERRA Website
}

export interface VerificationResult {
  valid: boolean;
  code: string;
  normalizedCode: string;
  error?: string;
  errorCode?: 'ALREADY_CLAIMED' | 'EXPIRED' | 'INVALID_CODE' | 'LOCKED_OUT' | 'RATE_LIMITED' | 'EMULATOR_BLOCKED';
  tier?: NodeTierConfig;
  nodesConfirmed?: number;
  totalNodes?: number;
  blockIndexStr?: string;
  batchId?: string;
  manufacturerName?: string;
  companyId?: string;
  passkeyHash?: string;
  rewardPhp?: number;
  rewardFlwrx?: number;
  treasuryPhp?: number;
  consensusName: 'Proof of Flower (PoF)';
  details?: string;
}

// Global Blockchain Constants
export const TOTAL_SUPPLY_CAP = 10_000_000; // 10M FLWRXCOIN
export const CIRCULATING_USER_POOL = 9_000_000; // 9M FLWRXCOIN
export const TERRA_RESERVE_POOL = 1_000_000; // 1M FLWRXCOIN (10%)
export const LEDGER_TOTAL_BLOCKS = 1_000_000; // Blocks #000000 to #999999
export const GENESIS_TIMESTAMP = 1640995200000; // 2022-01-01T00:00:00.000Z
export const HALVING_CYCLE_MS = 1460 * 86400 * 1000; // 4 Years (1,460 days)
export const BATCH_VALIDITY_WINDOW_MS = 730 * 86400 * 1000; // 2 Years (730 days)

// Rate Limiting & Brute-force Security Keys
const STORAGE_CLAIMED_PASSKEYS = 'terra.claimed_passkeys.v1';
const STORAGE_ACTIVE_BATCHES = 'terra.active_batches.v1';
const STORAGE_SECURITY_STATE = 'terra.security_state.v1';
const STORAGE_USER_ID = 'axis.user_id';
const STORAGE_ACCESS_KEY = 'axis.access_key';

/**
 * Standard FIPS 180-4 Synchronous SHA-256 for instant cryptographic verification
 */
export function sha256Sync(ascii: string): string {
  function rightRotate(value: number, amount: number) {
    return (value >>> amount) | (value << (32 - amount));
  }
  let i = 0, j = 0;
  let result = '';
  const words: number[] = [];
  const asciiBitLength = ascii.length * 8;
  let hash = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
  ];
  const k = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ];

  const asciiLength = ascii.length;
  for (i = 0; i < asciiLength; i++) {
    const code = ascii.charCodeAt(i);
    words[i >> 2] |= (code & 0xff) << ((3 - (i % 4)) * 8);
  }
  words[asciiLength >> 2] |= 0x80 << ((3 - (asciiLength % 4)) * 8);
  words[(((asciiLength + 8) >> 6) + 1) * 16 - 1] = asciiBitLength;

  for (i = 0; i < words.length; i += 16) {
    const w = words.slice(i, i + 16);
    const oldHash = hash.slice(0);

    for (j = 0; j < 64; j++) {
      if (j >= 16) {
        const s0 = rightRotate(w[j - 15], 7) ^ rightRotate(w[j - 15], 18) ^ (w[j - 15] >>> 3);
        const s1 = rightRotate(w[j - 2], 17) ^ rightRotate(w[j - 2], 19) ^ (w[j - 2] >>> 10);
        w[j] = (w[j - 16] + s0 + w[j - 7] + s1) | 0;
      }
      const ch = (hash[4] & hash[5]) ^ (~hash[4] & hash[6]);
      const maj = (hash[0] & hash[1]) ^ (hash[0] & hash[2]) ^ (hash[1] & hash[2]);
      const temp1 = (hash[7] + (rightRotate(hash[4], 6) ^ rightRotate(hash[4], 11) ^ rightRotate(hash[4], 25)) + ch + k[j] + (w[j] || 0)) | 0;
      const temp2 = ((rightRotate(hash[0], 2) ^ rightRotate(hash[0], 13) ^ rightRotate(hash[0], 22)) + maj) | 0;

      hash = [(temp1 + temp2) | 0, hash[0], hash[1], hash[2], (hash[3] + temp1) | 0, hash[4], hash[5], hash[6]];
    }

    for (j = 0; j < 8; j++) {
      hash[j] = (hash[j] + oldHash[j]) | 0;
    }
  }

  for (i = 0; i < 8; i++) {
    result += (hash[i] >>> 0).toString(16).padStart(8, '0');
  }
  return result;
}

// In-memory / localStorage cache helpers
function getClaimedPasskeys(): Set<string> {
  try {
    const raw = localStorage.getItem(STORAGE_CLAIMED_PASSKEYS);
    if (raw) return new Set(JSON.parse(raw));
  } catch {
    // fallback
  }
  return new Set<string>();
}

function saveClaimedPasskey(hash: string): void {
  try {
    const current = getClaimedPasskeys();
    current.add(hash);
    localStorage.setItem(STORAGE_CLAIMED_PASSKEYS, JSON.stringify([...current]));
  } catch {
    // ignore
  }
}

interface SecurityState {
  failedAttempts: number;
  lockedUntil: number;
  recentScanTimes: number[];
  deviceFingerprint: string;
}

function getSecurityState(): SecurityState {
  try {
    const raw = localStorage.getItem(STORAGE_SECURITY_STATE);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return {
    failedAttempts: 0,
    lockedUntil: 0,
    recentScanTimes: [],
    deviceFingerprint: 'AXIS-HW-' + Math.random().toString(36).slice(2, 10).toUpperCase()
  };
}

function saveSecurityState(sec: SecurityState): void {
  try {
    localStorage.setItem(STORAGE_SECURITY_STATE, JSON.stringify(sec));
  } catch {
    // ignore
  }
}

/**
 * APPLICATION-FIRST REGISTRATION DOCTRINE:
 * Format: 'ua' + 4-digit year + 5-digit sequence (e.g. ua202600001)
 */
export function generateAxisUserId(year?: number, sequence?: number): { userId: string; accessKey: string } {
  const currentYear = year || new Date().getFullYear();
  let seq = sequence;
  if (!seq) {
    const storedSeq = localStorage.getItem('axis.user_seq');
    const nextSeq = storedSeq ? parseInt(storedSeq, 10) + 1 : 1;
    localStorage.setItem('axis.user_seq', nextSeq.toString());
    seq = nextSeq;
  }
  const paddedSeq = seq.toString().padStart(5, '0');
  const userId = `ua${currentYear}${paddedSeq}`;

  // Generate cryptographic Axis Access Key for TERRA Website authentication
  const randomBytes = Array.from({ length: 32 }, () =>
    Math.floor(Math.random() * 256).toString(16).padStart(2, '0')
  ).join('');
  const accessKey = `ak_${userId}_${randomBytes.slice(0, 24)}`;

  try {
    localStorage.setItem(STORAGE_USER_ID, userId);
    localStorage.setItem(STORAGE_ACCESS_KEY, accessKey);
  } catch {
    // ignore
  }

  return { userId, accessKey };
}

export function getOrRegisterAxisIdentity(): { userId: string; accessKey: string } {
  try {
    const existingId = localStorage.getItem(STORAGE_USER_ID);
    const existingKey = localStorage.getItem(STORAGE_ACCESS_KEY);
    if (existingId && existingId.startsWith('ua') && existingKey) {
      return { userId: existingId, accessKey: existingKey };
    }
  } catch {
    // fallback to generate
  }
  return generateAxisUserId();
}

/**
 * 1,000,000-Block Capacity Halving & Scaling Schedule:
 * - Years 1–4: 5,000,000 codes per block
 * - Years 5–8: 25,000,000 codes per block
 * - Years 9–12: 50,000,000 codes per block
 * - Years 13–16: 100,000,000 codes per block
 * - Years 17–20: 250,000,000 codes per block
 * - Year 21+: 500,000,000 codes per block
 */
export function getBlockCapacityForTimestamp(ts: number = Date.now()): number {
  const yearsSinceGenesis = Math.max(0, (ts - GENESIS_TIMESTAMP) / (365.25 * 86400 * 1000));
  if (yearsSinceGenesis <= 4) return 5_000_000;
  if (yearsSinceGenesis <= 8) return 25_000_000;
  if (yearsSinceGenesis <= 12) return 50_000_000;
  if (yearsSinceGenesis <= 16) return 100_000_000;
  if (yearsSinceGenesis <= 20) return 250_000_000;
  return 500_000_000;
}

/**
 * Calculate Halving for FLWRXCOIN (4-Year / 1,460-day cycle).
 * Genesis: 0.001 FLWRXCOIN per verified code.
 * Exact PHP value (₱0.51) never halves.
 */
export function calculatePoFRewards(ts: number = Date.now()): { userPhp: number; userFlwrx: number; treasuryPhp: number } {
  const userPhp = 0.51; // Fixed 51% of ₱1.00
  const treasuryPhp = 0.49; // Fixed 49% of ₱1.00

  const timeElapsed = Math.max(0, ts - GENESIS_TIMESTAMP);
  const halvingEra = Math.floor(timeElapsed / HALVING_CYCLE_MS);
  const halvingFactor = Math.pow(2, halvingEra);

  // Genesis reward is 0.001 FLWRXCOIN, halved every 4 years
  const baseFlwrx = 0.001;
  const userFlwrx = Number((baseFlwrx / halvingFactor).toFixed(8));

  return { userPhp, userFlwrx, treasuryPhp };
}

/**
 * Checks if code fits the 11-tier dynamic length specification:
 * Length must be between 28 and 98 characters and (length - 28) % 7 === 0.
 */
export function getTierConfig(len: number): NodeTierConfig | null {
  if (len < 28 || len > 98 || (len - 28) % 7 !== 0) {
    return null;
  }
  return NODE_TIERS[len] || null;
}

/**
 * Pre-seeded Active Batches broadcasted from the TERRA Website (Yang)
 * Each batch has a 2-Year (730-day) validity window from activation.
 */
export function getActiveBatches(): TerraManufacturingBatch[] {
  try {
    const raw = localStorage.getItem(STORAGE_ACTIVE_BATCHES);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }

  const now = Date.now();
  // Default seeded batches from TERRA Website
  const defaultBatches: TerraManufacturingBatch[] = [
    {
      batchId: 'TERRA-MFG-B2026-001',
      manufacturerName: 'Coca-Cola Eco-Bottling Line 1',
      companyId: 'coca-cola',
      activatedTs: now - 30 * 86400 * 1000,
      expiresTs: now + (730 - 30) * 86400 * 1000, // Valid 700 days remaining
      totalCodes: 5000000,
      blockIndex: 42,
      targetPasskeys: [
        'CC2026FLWRXPOF001A89421876543', // 28 digits (Tier 1)
        'CC2026FLWRXPOF002B984218765432109876543', // 35 digits (Tier 2)
        'CC2026FLWRXPOF003C9842187654321098765432109876' // 42 digits (Tier 3)
      ]
    },
    {
      batchId: 'TERRA-MFG-B2026-002',
      manufacturerName: 'Nestlé Zero-Waste Packaging Plant',
      companyId: 'nestle',
      activatedTs: now - 15 * 86400 * 1000,
      expiresTs: now + (730 - 15) * 86400 * 1000,
      totalCodes: 5000000,
      blockIndex: 43,
      targetPasskeys: [
        'NS2026FLWRXPOF001A77421876543', // 28 digits
        'NS2026FLWRXPOF002B774218765432109876543' // 35 digits
      ]
    },
    {
      batchId: 'TERRA-MFG-B2026-003',
      manufacturerName: 'PepsiCo Sustainable Biopolymers',
      companyId: 'pepsico',
      activatedTs: now - 5 * 86400 * 1000,
      expiresTs: now + (730 - 5) * 86400 * 1000,
      totalCodes: 5000000,
      blockIndex: 44,
      targetPasskeys: [
        'PP2026FLWRXPOF001A66421876543' // 28 digits
      ]
    },
    {
      batchId: 'TERRA-MFG-B2026-004',
      manufacturerName: 'Jollibee Recycled Box Cartons',
      companyId: 'jollibee',
      activatedTs: now - 2 * 86400 * 1000,
      expiresTs: now + (730 - 2) * 86400 * 1000,
      totalCodes: 5000000,
      blockIndex: 45,
      targetPasskeys: [
        'JB2026FLWRXPOF001A55421876543' // 28 digits
      ]
    },
    {
      batchId: 'TERRA-MFG-B2023-EXPIRED',
      manufacturerName: 'Mondelēz Legacy Batch 2023',
      companyId: 'mondelez',
      activatedTs: now - 800 * 86400 * 1000, // 800 days ago (past 730 days)
      expiresTs: now - 70 * 86400 * 1000, // Expired 70 days ago
      totalCodes: 500000,
      blockIndex: 12,
      targetPasskeys: [
        'MD2023EXPIREDFLWRX00198765432' // Expired passkey test
      ]
    }
  ];

  try {
    localStorage.setItem(STORAGE_ACTIVE_BATCHES, JSON.stringify(defaultBatches));
  } catch {
    // ignore
  }

  return defaultBatches;
}

/**
 * Synchronize Active Batches / Target Passkeys broadcasted from TERRA Website
 */
export function syncBatchesFromWebsite(batches: TerraManufacturingBatch[]): void {
  try {
    localStorage.setItem(STORAGE_ACTIVE_BATCHES, JSON.stringify(batches));
  } catch {
    // ignore
  }
}

/**
 * Format block index to '#000000' format
 */
export function formatBlockIndex(blockIndex: number): string {
  const bounded = Math.max(0, Math.min(LEDGER_TOTAL_BLOCKS - 1, blockIndex));
  return `#${bounded.toString().padStart(6, '0')}`;
}

/**
 * Core Proof of Flower (PoF) Scanning & Verification Function
 * 
 * Rules Enforced:
 * 1. Sequential Brute-Force Lock: 5 failed attempts -> 24-hour lockout.
 * 2. Rate Limiting: Max 5 scans / 60 seconds per device.
 * 3. 28 to 98 digits (+7 step) validation.
 * 4. Deterministic mapping for real-world retail packaging barcodes (Yin-Yang duality).
 * 5. Batch Expiration (730-day rule). Expired -> 50% split to Manufacturer & TERRA.
 * 6. Single-Claim Finality: Re-scans rejected as ALREADY CLAIMED.
 * 7. >=50% Decentralized Node Quorum Confirmation.
 * 8. 51% / 49% Value Split (₱0.51 + 0.001 FLWRXCOIN).
 */
export function verifyFlowerCodePoF(rawCode: string): VerificationResult {
  const now = Date.now();
  const sec = getSecurityState();

  // 1. Check Brute-force 24-hour Lockout
  if (sec.lockedUntil > now) {
    const remainingHours = Math.ceil((sec.lockedUntil - now) / 3600000);
    return {
      valid: false,
      code: rawCode,
      normalizedCode: rawCode,
      error: `Security Lock: Device locked for 24 hours after 5 invalid attempts. Try again in ${remainingHours}h.`,
      errorCode: 'LOCKED_OUT',
      consensusName: 'Proof of Flower (PoF)'
    };
  }

  // 2. Check 5 Scans/Minute Rate Limiting
  const recentWithinOneMin = (sec.recentScanTimes || []).filter((t) => now - t < 60000);
  if (recentWithinOneMin.length >= 5) {
    return {
      valid: false,
      code: rawCode,
      normalizedCode: rawCode,
      error: 'Rate Limit: Max 5 scans per minute per device. Please wait a moment before scanning.',
      errorCode: 'RATE_LIMITED',
      consensusName: 'Proof of Flower (PoF)'
    };
  }

  // Record this scan attempt time for rate limiting
  sec.recentScanTimes = [...recentWithinOneMin, now];
  saveSecurityState(sec);

  const cleanCode = rawCode.trim().toUpperCase();
  const claimedPasskeys = getClaimedPasskeys();
  const batches = getActiveBatches();

  // Check if raw code is directly an active passkey or needs normalization
  let matchedBatch: TerraManufacturingBatch | null = null;
  let activePasskey: string | null = null;
  let isExpired = false;

  // Case A: Direct TERRA 28-to-98 char manufacturing Flower Code
  const directTier = getTierConfig(cleanCode.length);
  if (directTier) {
    for (const b of batches) {
      if (b.targetPasskeys.includes(cleanCode)) {
        matchedBatch = b;
        activePasskey = cleanCode;
        if (now > b.expiresTs) {
          isExpired = true;
        }
        break;
      }
    }
  }

  // Case B: Real-world retail packaging barcode (UPC-A, EAN-13, QR or custom packaging)
  // Per Yin-Yang System Architecture: The Axis App & decentralized nodes exist to FIND, MATCH,
  // and VERIFY the broadcasted Flower Codes when users scan recycled packaging!
  if (!activePasskey) {
    // Generate deterministic Flower Code Passkey (28 digits, Tier 1) mapped to active batches
    let hashNum = 0;
    for (let i = 0; i < cleanCode.length; i++) {
      hashNum = (hashNum * 31 + cleanCode.charCodeAt(i)) >>> 0;
    }
    const chosenBatch = batches[hashNum % batches.length];
    const generatedPasskey = chosenBatch.targetPasskeys[hashNum % chosenBatch.targetPasskeys.length] ||
      `TERRA2026POF${hashNum.toString(36).toUpperCase().padStart(16, '0').slice(-16)}`;

    matchedBatch = chosenBatch;
    activePasskey = generatedPasskey;
    if (now > chosenBatch.expiresTs) {
      isExpired = true;
    }
  }

  const passkeyHash = sha256Sync(activePasskey);

  // 3. Check Single-Claim Finality (Already Claimed / Duplicate)
  if (claimedPasskeys.has(passkeyHash) || claimedPasskeys.has(activePasskey)) {
    return {
      valid: false,
      code: rawCode,
      normalizedCode: activePasskey,
      error: 'ALREADY CLAIMED: This manufacturing Flower Code has already reached consensus and been permanently redeemed.',
      errorCode: 'ALREADY_CLAIMED',
      passkeyHash,
      consensusName: 'Proof of Flower (PoF)'
    };
  }

  // 4. Check 2-Year (730-day) Batch Expiration
  if (isExpired || !matchedBatch) {
    // 50/50 Forfeiture Rule: Split between manufacturer and TERRA system
    sec.failedAttempts += 1;
    if (sec.failedAttempts >= 5) {
      sec.lockedUntil = now + 86400 * 1000; // 24-hour lockout
    }
    saveSecurityState(sec);

    return {
      valid: false,
      code: rawCode,
      normalizedCode: activePasskey,
      error: 'EXPIRED CODE: Manufacturing batch expired (past 730-day window). Value forfeited (50% Manufacturer / 50% TERRA Treasury).',
      errorCode: 'EXPIRED',
      batchId: matchedBatch?.batchId,
      passkeyHash,
      consensusName: 'Proof of Flower (PoF)'
    };
  }

  // 5. Dynamic Tier & Decentralized Node Confirmation Quorum (>= 50%)
  const tier = getTierConfig(activePasskey.length) || NODE_TIERS[28];
  // Calculate simulated node quorum meeting the >=50% threshold
  const minRequiredNodes = tier.minConfirmationThreshold;
  // Confirmed nodes will range between 51% and 98% of total nodes
  const quorumPercentage = 0.52 + ((passkeyHash.charCodeAt(0) % 40) / 100);
  const nodesConfirmed = Math.max(minRequiredNodes, Math.floor(tier.totalNodes * quorumPercentage));

  // 6. Calculate 51% / 49% Split & Tokenomics Rewards
  const { userPhp, userFlwrx, treasuryPhp } = calculatePoFRewards(now);

  // 7. Permanently Burn Passkey in Storage (Single-Claim Finality)
  saveClaimedPasskey(passkeyHash);
  saveClaimedPasskey(activePasskey);

  // Reset failed attempts on valid scan
  sec.failedAttempts = 0;
  saveSecurityState(sec);

  return {
    valid: true,
    code: rawCode,
    normalizedCode: activePasskey,
    tier,
    nodesConfirmed,
    totalNodes: tier.totalNodes,
    blockIndexStr: formatBlockIndex(matchedBatch.blockIndex),
    batchId: matchedBatch.batchId,
    manufacturerName: matchedBatch.manufacturerName,
    companyId: matchedBatch.companyId,
    passkeyHash,
    rewardPhp: userPhp,
    rewardFlwrx: userFlwrx,
    treasuryPhp,
    consensusName: 'Proof of Flower (PoF)',
    details: `Proof of Flower (PoF) consensus verified by ${nodesConfirmed.toLocaleString()}/${tier.totalNodes.toLocaleString()} nodes on Block ${formatBlockIndex(matchedBatch.blockIndex)}.`
  };
}

/**
 * 100% Unanimous Axis User Governance Vote (10% Reserve Lock):
 * The 10% company reserve lock can never be raised unless 100% of all registered Axis users vote YES.
 * A single NO vote triggers an automatic permanent veto and removes the proposing executive.
 */
export interface GovernanceState {
  reserveCap: number; // 0.10 (10%)
  activeProposal: {
    id: string;
    proposedCap: number;
    title: string;
    proposingExecutive: string;
    totalRegisteredUsers: number;
    yesVotes: number;
    noVotes: number;
    isPermanentlyVetoed: boolean;
    removalNotice?: string;
  } | null;
}

export function evaluateGovernanceVote(userVote: 'YES' | 'NO'): GovernanceState {
  const base: GovernanceState = {
    reserveCap: 0.10,
    activeProposal: {
      id: 'PROP-RESERVE-2026-01',
      proposedCap: 0.11,
      title: 'Company Withdrawal Cap Increase Proposal to 11%',
      proposingExecutive: 'CFO / Corporate Treasury Seat 04',
      totalRegisteredUsers: 142850,
      yesVotes: 142849,
      noVotes: 0,
      isPermanentlyVetoed: false
    }
  };

  if (userVote === 'NO') {
    // Single NO vote triggers AUTOMATIC PERMANENT VETO and removes executive
    base.activeProposal = {
      ...base.activeProposal!,
      noVotes: 1,
      isPermanentlyVetoed: true,
      removalNotice: 'PERMANENT VETO: 1 Axis User voted NO. Proposal permanently terminated and proposing executive removed.'
    };
  } else {
    base.activeProposal = {
      ...base.activeProposal!,
      yesVotes: base.activeProposal!.yesVotes + 1
    };
  }

  return base;
}
