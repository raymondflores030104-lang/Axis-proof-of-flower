import { AxisState } from './types';

export const FX = 58.5; // PHP per USD
export const DAILY_CAP = 100; // 100 scans maximum daily
export const FREE_SCANS_LIMIT = 3; // First 3 scans everyday are 100% free; scans 4-100 require 60s sponsored ad
export const REFERRAL_MILESTONE = 200; // 200 person referral milestone = $20 reward
export const FEE = 0.001; // 0.1% fee
export const STORAGE_KEY = 'axis_app_state_v3';
export const CANDLES_KEY = 'axis_candles_history_v3';

export const STAKING_TIERS = [
  { label: 'Flexible', days: 0, apy: 0.05, apyLabel: '5% APY' },
  { label: '7 Days', days: 7, apy: 0.09, apyLabel: '9% APY' },
  { label: '30 Days', days: 30, apy: 0.14, apyLabel: '14% APY' },
  { label: '90 Days', days: 90, apy: 0.20, apyLabel: '20% APY' }
];

export interface Company {
  id: string;
  name: string;
  cat: string;
  flrxPerScan: number;
  total: number;
  mined0: number;
  prefixes: string[];
  banner: string;
}

export const COMPANIES: Company[] = [
  {
    id: 'coca_cola',
    name: 'Coca-Cola Beverages',
    cat: 'Beverages',
    flrxPerScan: 1.25,
    total: 250000,
    mined0: 142300,
    prefixes: ['490', '544', '049'],
    banner: '🥤 Refresh the world · Scan cans & bottles for instant FLRX'
  },
  {
    id: 'nestle',
    name: 'Nestlé Nutrition',
    cat: 'Food & Dairy',
    flrxPerScan: 1.1,
    total: 300000,
    mined0: 198450,
    prefixes: ['761', '480', '899'],
    banner: '🥛 Good Food, Good Life · Milo, Bear Brand, Nescafé'
  },
  {
    id: 'unilever',
    name: 'Unilever CPG',
    cat: 'Personal Care',
    flrxPerScan: 1.35,
    total: 200000,
    mined0: 95400,
    prefixes: ['871', '500', '087'],
    banner: '✨ Dove, Lifebuoy, Sunsilk, Knorr · Sustainable rewards'
  },
  {
    id: 'monde_nissin',
    name: 'Monde Nissin',
    cat: 'Noodles & Snacks',
    flrxPerScan: 0.95,
    total: 180000,
    mined0: 112000,
    prefixes: ['4800016', '4800017'],
    banner: '🍜 Lucky Me! & Voice · The staple snack mining bridge'
  },
  {
    id: 'san_miguel',
    name: 'San Miguel Foods',
    cat: 'Beverages & Meats',
    flrxPerScan: 1.4,
    total: 220000,
    mined0: 135000,
    prefixes: ['4800025', '4800026'],
    banner: '🍺 Purefoods & Magnolia · World-class beverage rewards'
  },
  {
    id: 'universal_robina',
    name: 'Universal Robina (URC)',
    cat: 'Snacks & Tea',
    flrxPerScan: 1.05,
    total: 210000,
    mined0: 89000,
    prefixes: ['4800010', '4800011'],
    banner: '🍵 C2 Green Tea & Piattos · Daily snacking utility'
  }
];

export const MISSIONS = [
  {
    id: 'd1',
    t: 'd',
    title: 'Morning Miner',
    desc: 'Complete at least 3 verified scans today',
    reward: 2.5,
    xp: 15,
    goal: 3,
    prog: (s: AxisState) => s.day?.scans || 0
  },
  {
    id: 'd2',
    t: 'd',
    title: 'Brand Diversity',
    desc: 'Scan products from 2 different companies today',
    reward: 3.0,
    xp: 20,
    goal: 2,
    prog: (s: AxisState) => Object.keys(s.seen || {}).length
  },
  {
    id: 'd3',
    t: 'd',
    title: 'Market Observer',
    desc: 'Execute 1 trade or place 1 limit order today',
    reward: 2.0,
    xp: 10,
    goal: 1,
    prog: (s: AxisState) => (s.trades?.length || 0) + (s.orders?.length || 0)
  },
  {
    id: 'w1',
    t: 'w',
    title: 'Weekly Power Scanner',
    desc: 'Accumulate 25 total verified scans this week',
    reward: 15.0,
    xp: 80,
    goal: 25,
    prog: (s: AxisState) => s.week?.scans || 0
  },
  {
    id: 'w2',
    t: 'w',
    title: 'Ecosystem Staker',
    desc: 'Maintain at least 1 active stake in the FLRX vault',
    reward: 10.0,
    xp: 50,
    goal: 1,
    prog: (s: AxisState) => (s.stakes?.length || 0)
  }
];

export const CURS: Record<string, [string, number, string]> = {
  PHP: ['₱', 58.5, 'Philippine Peso'],
  USD: ['$', 1.0, 'US Dollar'],
  EUR: ['€', 0.92, 'Euro'],
  JPY: ['¥', 152.0, 'Japanese Yen'],
  KRW: ['₩', 1380.0, 'South Korean Won']
};

export const DEP: Record<string, { label: string; icon: string }> = {
  ewallet: { label: 'GCash / Maya', icon: '📱' },
  bank: { label: 'BDO / BPI / UnionBank', icon: '🏦' },
  otc: { label: '7-Eleven / Cliqq', icon: '🏪' }
};

export const WFEE: Record<string, number> = {
  ewallet: 15,
  bank: 25,
  otc: 30
};

export const STORE_ITEMS = [
  { id: 'gc100', name: '₱100 GCash Credits', cat: 'cash', cost: 15, stock: 450, icon: '📱', partner: 'GCash' },
  { id: 'maya100', name: '₱100 Maya Credits', cat: 'cash', cost: 15, stock: 320, icon: '💳', partner: 'Maya' },
  { id: 'coke50', name: 'Coke 1.5L Free Voucher', cat: 'food', cost: 8, stock: 890, icon: '🥤', partner: 'Coca-Cola' },
  { id: 'milo50', name: 'Milo 300g Reward Voucher', cat: 'food', cost: 9, stock: 540, icon: '🥛', partner: 'Nestlé' },
  { id: 'cliqq50', name: '₱50 7-Eleven Cliqq QR Code', cat: 'cash', cost: 7.5, stock: 1200, icon: '🏪', partner: '7-Eleven' },
  { id: 'load100', name: '₱100 Smart / Globe Prepaid Load', cat: 'telecom', cost: 14.5, stock: 990, icon: '📶', partner: 'Telco' }
];

export const DEFAULT_STATE: AxisState = {
  accountId: 'AXIS-94812',
  address: '0x71C...4e89',
  php: 94.50,
  flrx: 17.5002,
  staked: 0.0,
  stakeAcc: 0.0,
  stakeLast: Date.now(),
  stakedEver: false,
  avgCost: 0.45,
  realized: 0.0,
  price: 0.524,
  xp: 120,
  totalScans: 8,
  totalEarned: 25.0,
  scanStreak: 3,
  lastScanDay: new Date().toISOString().slice(0, 10),
  lastScanTs: Date.now(),
  day: {
    key: new Date().toISOString().slice(0, 10),
    scans: 2,
    receipts: 0,
    missions: []
  },
  week: {
    key: '2026-W41',
    scans: 6,
    earned: 12.5,
    byCompany: { coca_cola: 3, nestle: 2, unilever: 1 },
    missions: []
  },
  seen: { '490123456789': 1, '761987654321': 1 },
  everCompanies: { coca_cola: 1, nestle: 1, unilever: 1 },
  pool: {},
  history: [],
  tx: [
    { id: 'tx-init', ts: Date.now() - 3600000, type: 'reward', label: 'Welcome Airdrop', php: 0, flrx: 25.0 }
  ],
  trades: [],
  queue: [],
  vouchers: [],
  receipts: [],
  friends: [],
  tickets: [],
  claim: {
    streak: 1,
    last: null,
    total: 1
  },
  ach: { first_scan: 1 },
  referral: {
    code: 'AXIS-7749',
    redeemed: false
  },
  auto: {
    on: false,
    today: 0,
    dayKey: new Date().toISOString().slice(0, 10),
    acc: 0
  },
  bot: {
    on: false,
    amount: 5,
    interval: 30,
    max: 50,
    spent: 0,
    last: 0,
    count: 0
  },
  settings: {
    lang: 'en',
    currency: 'PHP',
    theme: 'manual',
    tone: 0,
    fallingLeaves: true,
    fallingLeavesSpeed: 'slow',
    weatherMode: 'blackhole',
    autolock: 'never',
    fx: {
      sound: true,
      vol: 0.7,
      vib: true,
      snd: { click: true, scan: true, scanning: true, alert: true },
      vbr: { click: true, scan: true, scanning: true, alert: true }
    },
    notif: {
      all: true,
      scan: true,
      reward: true,
      market: true,
      orders: true,
      promo: true,
      device: true
    },
    apps: { gcash: true, maya: true, camera: true }
  },
  securitySettings: {
    biometrics: false,
    requirePinForTrade: false,
    requirePinForTransfer: false,
    antiPhishingCode: 'AXIS-SAFE'
  },
  profile: {
    name: 'Citizen Miner',
    email: 'miner@axis.network',
    avatar: '',
    kyc: 'Tier 1 Verified'
  },
  goals: [],
  spin: {
    ready: Date.now(),
    history: []
  },
  pinHash: null,
  pinSalt: null,
  pinLockedUntil: null,
  failedPinAttempts: 0,
  custodyMode: 'SELF_CUSTODY',
  operationalMode: 'PRODUCTION',
  whitelistedAddresses: [],
  bridgeRecords: [],
  onboarded: true,
  firstBonusUsed: true,
  ath: 0.58,
  athTs: Date.now() - 86400000,
  lastAthEvt: 0,
  pa: [],
  alerts: [],
  orders: [],
  stakes: [],
  totalWasteReducedGrams: 320.5,
  flwrxReservePool: 1000000.0,
  flwrxCirculatingPool: 9000000.0,
  companyReserveWithdrawalCapPercent: 10.0,
  governanceReserveLocked: true,
  pendingScans: [],
  lowPowerMode: false
};
