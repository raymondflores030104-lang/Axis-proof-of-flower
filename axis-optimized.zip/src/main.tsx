import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';
import { ErrorBoundary } from './components/ErrorBoundary';

// Global guard for third-party Web3 extension injection / inpage disconnect events
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const msg = String(reason?.message || reason || '');
    const stack = String(reason?.stack || '');
    if (
      msg.includes('MetaMask') ||
      msg.includes('Failed to connect to MetaMask') ||
      stack.includes('chrome-extension://') ||
      stack.includes('inpage.js')
    ) {
      event.preventDefault();
      event.stopImmediatePropagation?.();
      console.warn('[Axis Guard] Caught and handled external MetaMask extension disconnect event safely.');
    }
  });

  const eth = (window as any).ethereum;
  if (eth && typeof eth.on === 'function') {
    try {
      eth.on('disconnect', () => {
        console.warn('[Axis Guard] Web3 provider disconnected.');
      });
      eth.on('error', (err: any) => {
        console.warn('[Axis Guard] Web3 provider error handled safely:', err);
      });
    } catch {
      // safe fallback
    }
  }
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>
);
