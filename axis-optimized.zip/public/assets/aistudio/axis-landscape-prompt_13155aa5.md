# Axis landscape layout: paste-ready prompt

Copy everything inside the box below into your coding AI, together with your current portrait frontend code.

---

````text
ROLE
You are a senior frontend engineer. Add a LANDSCAPE layout to my existing mobile web app "Axis: Proof of Flower" and animate the switch between portrait and landscape.

HARD RULES (do not break)
1. Do NOT change the existing portrait layout, markup order, copy, colors, shadows, or logic.
2. KEEP the app's current background exactly as it is (canvas color, texture, glow, any ambient layers). Do not add or replace backgrounds.
3. KEEP every Liquid Glass component exactly as it is (tabs, dock, pills, header buttons, modals): same blur, border, specular highlight, radius, tokens. Reuse the existing classes. Do not restyle them.
4. Only PLACEMENT changes in landscape. That means CSS grid areas, sizes, and gaps. No new visual styles.
5. Landscape must have ZERO vertical scrolling on the main screen (target 667x375 up to 915x412, and tablets up to 1024x768).
6. Respect safe areas: padding with env(safe-area-inset-left/right/top/bottom).

HOW TO DETECT LANDSCAPE
Use one source of truth: a data attribute on the shell, `data-layout="portrait|landscape"`, set from this media query in JS:
(orientation: landscape) and (max-height: 820px) and (max-width: 1100px)
CSS must key off the attribute (NOT a raw @media), so the animation can measure the old layout before the new one applies.

ZONE MAP
Add `data-zone="..."` to the existing elements (do not rewrap them; the portrait tile grid wrapper gets `display: contents` in landscape so tiles become direct grid items):
- header        existing top bar (4 action buttons, branding, avatar)
- balance       dual-asset balance card
- activity      recent activity / HUD bar
- hero          Nexus Scan hero card (with ticker pill and scans-left counter)
- actions       the 4 square header action buttons, regrouped into a 2x2 block (Achievements, Referral, Daily check-in with pip, Node bot)
- streak        daily streak card (or the check-in shortcut)
- tile          each of the 8 tiles: Wallet, Trade, Companies, Missions, Rewards, Social, History, Settings

LANDSCAPE PLACEMENT (24-column grid)
- Row 1: header, full width (slim, 40px).
- Left 6 cols: balance on top, activity below.
- Center 12 cols: hero, spanning rows 2 and 3 (full height, both thumbs can reach it).
- Right 6 cols: actions (2x2) on top, streak below.
- Last row: the 8 tiles in ONE row, 3 cols each, as the liquid glass dock.
- Modals and sheets (Scanner, Trading, Staking, Referral, Streak): become a RIGHT-SIDE glass drawer, width min(46%, 400px), slide in from the right. They keep their current styles. Inside them use two-column forms so nothing needs vertical scrolling.

ANIMATION (portrait <-> landscape)
Goal: when the phone rotates, every zone glides from its old position and size to the new one in about 480ms, with no jump or flash.
- Primary: the View Transitions API (document.startViewTransition) with a unique view-transition-name per zone.
- Fallback: a FLIP animation (First, Last, Invert, Play) with the Web Animations API.
- Skip the animation on first load.
- If prefers-reduced-motion is set, switch instantly.
- Animate only transform and opacity. Never animate blur, backdrop-filter, or box-shadow.
- Easing: cubic-bezier(.2, .8, .2, 1). Duration: 480ms.
- Open drawers should stay open and re-dock during the switch.

DELIVERABLES
1. The CSS block (landscape rules only, appended after my existing CSS).
2. The JS (or React hook) that sets data-layout and runs the animation.
3. A list of the data-zone attributes you added and where.
4. Confirm that portrait is pixel-identical to before.

ACCEPTANCE CHECKS
- 667x375, 812x375, 915x412, 1024x768 landscape: no vertical scroll, all 8 tiles visible, hero is the largest element.
- Rotating back and forth repeatedly never leaves a zone in the wrong place.
- Background and glass tabs look identical to portrait.
````

---

## Code the AI should produce (reference)

### 1. CSS: landscape placement only

```css
:root { --ease: cubic-bezier(.2, .8, .2, 1); --dur: 480ms; }

/* names for the View Transitions API */
[data-zone="header"]   { view-transition-name: z-header; }
[data-zone="balance"]  { view-transition-name: z-balance; }
[data-zone="activity"] { view-transition-name: z-activity; }
[data-zone="hero"]     { view-transition-name: z-hero; }
[data-zone="actions"]  { view-transition-name: z-actions; }
[data-zone="streak"]   { view-transition-name: z-streak; }
[data-zone="tile"]:nth-of-type(1) { view-transition-name: t1; }
[data-zone="tile"]:nth-of-type(2) { view-transition-name: t2; }
[data-zone="tile"]:nth-of-type(3) { view-transition-name: t3; }
[data-zone="tile"]:nth-of-type(4) { view-transition-name: t4; }
[data-zone="tile"]:nth-of-type(5) { view-transition-name: t5; }
[data-zone="tile"]:nth-of-type(6) { view-transition-name: t6; }
[data-zone="tile"]:nth-of-type(7) { view-transition-name: t7; }
[data-zone="tile"]:nth-of-type(8) { view-transition-name: t8; }

::view-transition-group(*) {
  animation-duration: var(--dur);
  animation-timing-function: var(--ease);
}

/* LANDSCAPE: placement only. Colors, glass and shadows are untouched. */
[data-axis-shell][data-layout="landscape"] {
  max-width: none;
  height: 100dvh;
  padding: env(safe-area-inset-top) env(safe-area-inset-right)
           env(safe-area-inset-bottom) env(safe-area-inset-left);
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(24, minmax(0, 1fr));
  grid-template-rows: auto auto minmax(0, 1fr) auto;
  overflow: hidden;
}
[data-layout="landscape"] .tiles-grid { display: contents; } /* your existing tile wrapper */

[data-layout="landscape"] [data-zone="header"]   { grid-column: 1 / -1; grid-row: 1; }
[data-layout="landscape"] [data-zone="balance"]  { grid-column: 1 / 7;  grid-row: 2; }
[data-layout="landscape"] [data-zone="activity"] { grid-column: 1 / 7;  grid-row: 3; min-height: 0; }
[data-layout="landscape"] [data-zone="hero"]     { grid-column: 7 / 19; grid-row: 2 / 4; min-height: 0; }
[data-layout="landscape"] [data-zone="actions"]  { grid-column: 19 / -1; grid-row: 2;
                                                   display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
[data-layout="landscape"] [data-zone="streak"]   { grid-column: 19 / -1; grid-row: 3; min-height: 0; }
[data-layout="landscape"] [data-zone="tile"]     { grid-column: span 3; grid-row: 4; height: 54px; }

/* drawers for Scanner, Trade, Staking, Referral, Streak */
[data-layout="landscape"] .axis-modal {
  position: fixed; top: 10px; bottom: 10px; right: 10px;
  width: min(46%, 400px); max-height: none; border-radius: 22px;
  transform: translateX(0);
}

@media (max-height: 400px) {
  [data-layout="landscape"] [data-zone="tile"] { height: 46px; }
}
@media (prefers-reduced-motion: reduce) {
  ::view-transition-group(*) { animation-duration: 0.01ms; }
}
```

### 2. JS: detect landscape and animate the switch

```js
const shell = document.querySelector('[data-axis-shell]');
const mq = matchMedia('(orientation: landscape) and (max-height: 820px) and (max-width: 1100px)');
const reduce = matchMedia('(prefers-reduced-motion: reduce)');
const DUR = 480, EASE = 'cubic-bezier(.2,.8,.2,1)';

const layoutOf = () => (mq.matches ? 'landscape' : 'portrait');
const setLayout = () => { shell.dataset.layout = layoutOf(); };

/* FLIP fallback for browsers without View Transitions */
function flip() {
  const els = [...shell.querySelectorAll('[data-zone]')];
  const first = new Map(els.map(e => [e, e.getBoundingClientRect()]));
  setLayout();
  els.forEach(e => {
    const a = first.get(e), b = e.getBoundingClientRect();
    const dx = a.left - b.left, dy = a.top - b.top;
    const sx = a.width / b.width, sy = a.height / b.height;
    if (!dx && !dy && sx === 1 && sy === 1) return;
    e.animate(
      [
        { transformOrigin: 'top left', transform: `translate(${dx}px,${dy}px) scale(${sx},${sy})`, opacity: .7 },
        { transformOrigin: 'top left', transform: 'none', opacity: 1 }
      ],
      { duration: DUR, easing: EASE }
    );
  });
}

let raf = 0;
function onChange() {
  cancelAnimationFrame(raf);
  raf = requestAnimationFrame(() => {
    if (shell.dataset.layout === layoutOf()) return;
    if (reduce.matches) return setLayout();
    if (document.startViewTransition) document.startViewTransition(setLayout);
    else flip();
  });
}

setLayout();                               // first load: no animation
mq.addEventListener('change', onChange);   // rotation
addEventListener('resize', onChange);      // tablet / split-screen
```

### 3. React version of the same hook

```jsx
import { useLayoutEffect, useState } from 'react';

const Q = '(orientation: landscape) and (max-height: 820px) and (max-width: 1100px)';

export function useAxisLayout() {
  const [layout, setLayout] = useState(() => (matchMedia(Q).matches ? 'landscape' : 'portrait'));

  useLayoutEffect(() => {
    const mq = matchMedia(Q);
    const reduce = matchMedia('(prefers-reduced-motion: reduce)');
    const apply = () => setLayout(mq.matches ? 'landscape' : 'portrait');
    const onChange = () => {
      if (reduce.matches || !document.startViewTransition) return apply();
      document.startViewTransition(() => {
        // flushSync makes React commit the new layout inside the transition
        import('react-dom').then(({ flushSync }) => flushSync(apply));
      });
    };
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  return layout; // <div data-axis-shell data-layout={layout}>
}
```

---

## Notes

- Switch on `data-layout` and not on a raw `@media` rule. The animation has to measure the old position first, and that only works if the browser has not already moved things.
- The View Transitions API is supported in current Chrome, Edge, Safari, and Android WebView. Firefox falls back to the FLIP code.
- If text looks stretched mid-animation in the FLIP fallback, change the opacity keyframe to start at `.4` so the scale is less visible.
